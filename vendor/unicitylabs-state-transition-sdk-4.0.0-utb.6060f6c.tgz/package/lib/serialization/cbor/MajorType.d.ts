/**
 * CBOR major type bits (RFC 8949 §3.1), packed into the high 3 bits of the
 * initial byte. Used by the serializer/deserializer to tag and recognize
 * values.
 */
export declare enum MajorType {
    UNSIGNED_INTEGER = 0,
    NEGATIVE_INTEGER = 32,
    BYTE_STRING = 64,
    TEXT_STRING = 96,
    ARRAY = 128,
    MAP = 160,
    TAG = 192,
    FLOAT_SIMPLE_BREAK = 224
}
