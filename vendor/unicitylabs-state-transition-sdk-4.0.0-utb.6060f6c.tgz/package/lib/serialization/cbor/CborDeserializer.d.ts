import { CborMapEntry } from './CborMapEntry.js';
/**
 * Static helpers that decode canonical CBOR bytes into TypeScript values.
 * Every method consumes the entire input and asserts there are no trailing
 * bytes.
 */
export declare class CborDeserializer {
    private static readonly FALSE_CBOR;
    private static readonly NULL_CBOR;
    private static readonly TRUE_CBOR;
    /**
     * Decode a CBOR array.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @param {number|null} expectedLength If set, throws when the array has a different length.
     * @returns {Uint8Array[]} CBOR bytes of each element.
     * @throws {CborError} On wrong length or trailing bytes.
     */
    static decodeArray(data: Uint8Array, expectedLength?: number | null): Uint8Array[];
    /**
     * Decode a minimally encoded big-endian CBOR byte string into a non-negative big integer.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @param {number} [maxByteLength] Optional maximum byte-string length.
     * @returns {bigint} Decoded integer.
     * @throws {CborError} If the encoding is non-minimal (leading zero byte) or exceeds `maxByteLength`.
     */
    static decodeBigInteger(data: Uint8Array, maxByteLength?: number): bigint;
    /**
     * Decode a CBOR boolean.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @returns {boolean} Boolean value.
     * @throws {CborError} If the input encodes anything other than `true` or `false`.
     */
    static decodeBoolean(data: Uint8Array): boolean;
    /**
     * Decode a CBOR byte string.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @returns {Uint8Array} Decoded payload bytes.
     */
    static decodeByteString(data: Uint8Array): Uint8Array;
    /**
     * Decode a CBOR map, enforcing canonical key ordering and rejecting
     * duplicate keys.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @returns {CborMapEntry[]} Decoded entries.
     * @throws {CborError} On duplicate or out-of-order keys.
     */
    static decodeMap(data: Uint8Array): CborMapEntry[];
    /**
     * Decode a CBOR negative integer.
     *
     * @returns {bigint} Decoded integer.
     * @throws {CborError} Always; not yet implemented.
     */
    static decodeNegativeInteger(): bigint;
    /**
     * Decode `data` with `decode`, or return `null` if the input is CBOR `null`.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @param {(data: Uint8Array) => T} decode Decoder for the inner value.
     * @returns {T|null} Decoded value or `null`.
     */
    static decodeNullable<T>(data: Uint8Array, decode: (data: Uint8Array) => T): T | null;
    /**
     * Decode a CBOR tag.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @returns {{data: Uint8Array, tag: bigint}} Tag number and CBOR bytes of the tagged value.
     */
    static decodeTag(data: Uint8Array): {
        data: Uint8Array;
        tag: bigint;
    };
    /**
     * Decode a CBOR text string.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @returns {string} UTF-8 decoded string.
     */
    static decodeTextString(data: Uint8Array): string;
    /**
     * Decode a CBOR unsigned integer.
     *
     * @param {Uint8Array} data CBOR bytes.
     * @returns {bigint} Decoded integer.
     */
    static decodeUnsignedInteger(data: Uint8Array): bigint;
}
