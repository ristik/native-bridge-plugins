import { MajorType } from './MajorType.js';
/**
 * Low-level cursor over a CBOR byte buffer. Tracks a read position and
 * provides primitives used by {@link CborDeserializer} to parse canonical
 * CBOR. Indefinite-length encodings are rejected.
 */
export declare class CborReader {
    private readonly data;
    private static ADDITIONAL_INFORMATION_MASK;
    private static MAJOR_TYPE_MASK;
    private position;
    constructor(data: Uint8Array);
    /**
     * Throw if the reader has not consumed every byte of the buffer.
     *
     * @throws {CborError} If unread bytes remain.
     */
    assertExhausted(): void;
    /**
     * Read exactly `length` bytes and advance the cursor.
     *
     * @param {number} length Number of bytes to read.
     * @returns {Uint8Array} Bytes read.
     * @throws {CborError} If fewer than `length` bytes remain.
     */
    read(length: number): Uint8Array;
    /**
     * Read a single byte and advance the cursor.
     *
     * @returns {number} Byte read.
     * @throws {CborError} If no bytes remain.
     */
    readByte(): number;
    /**
     * Read the initial byte and any extended length bytes for the given major
     * type, returning the encoded length/value. Enforces canonical
     * minimum-byte encoding.
     *
     * @param {MajorType} majorType Expected major type.
     * @returns {bigint} Decoded length/value.
     * @throws {CborError} On major-type mismatch, indefinite-length encoding,
     *   reserved additional info, or non-canonical length.
     */
    readLength(majorType: MajorType): bigint;
    /**
     * Read a single complete CBOR data item (including nested arrays, maps,
     * and tags) without decoding it.
     *
     * Parsed iteratively: CBOR serializes items contiguously in depth-first
     * pre-order, so a flat counter of items still to consume replaces the call
     * stack — deeply nested input cannot overflow the stack.
     *
     * @returns {Uint8Array} CBOR bytes of the data item.
     */
    readRawCbor(): Uint8Array;
}
