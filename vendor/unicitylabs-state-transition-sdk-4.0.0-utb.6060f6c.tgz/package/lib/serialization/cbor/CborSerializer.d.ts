import { CborMap } from './CborMap.js';
/**
 * Static helpers that encode TypeScript values to canonical CBOR bytes
 * (RFC 8949 §4.2).
 */
export declare class CborSerializer {
    /**
     * Encode an array of already-encoded CBOR items as a CBOR array.
     *
     * @param {...Uint8Array} input Encoded CBOR items.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeArray(...input: Uint8Array[]): Uint8Array;
    /**
     * Encode a non-negative big integer as a minimally encoded big-endian CBOR byte string.
     *
     * @param {bigint} value Non-negative integer.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeBigInteger(value: bigint): Uint8Array;
    /**
     * Encode a boolean as the CBOR simple values `true` (0xf5) or `false` (0xf4).
     *
     * @param {boolean} data Boolean value.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeBoolean(data: boolean): Uint8Array;
    /**
     * Encode raw bytes as a CBOR byte string.
     *
     * @param {Uint8Array} input Raw bytes.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeByteString(input: Uint8Array): Uint8Array;
    /**
     * Encode a {@link CborMap} as a canonical CBOR map.
     *
     * @param {CborMap} input Canonical CBOR map.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeMap(input: CborMap): Uint8Array;
    /**
     * Encode the CBOR `null` simple value (0xf6).
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeNull(): Uint8Array;
    /**
     * Encode `data` with `encoder`, or return CBOR `null` if `data` is
     * `null`/`undefined`.
     *
     * @param {T|null|undefined} data Value to encode.
     * @param {(data: T) => Uint8Array} encoder Encoder for the inner value.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeNullable<T>(data: T | null | undefined, encoder: (data: T) => Uint8Array): Uint8Array;
    /**
     * Wrap already-encoded CBOR bytes in a CBOR tag.
     *
     * @param {number|bigint} tag Tag number.
     * @param {Uint8Array} input Encoded CBOR bytes to tag.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeTag(tag: number | bigint, input: Uint8Array): Uint8Array;
    /**
     * Encode a UTF-8 string as a CBOR text string.
     *
     * @param {string} input Text value.
     * @returns {Uint8Array} CBOR bytes.
     */
    static encodeTextString(input: string): Uint8Array;
    /**
     * Encode a non-negative integer as a CBOR unsigned integer.
     *
     * @param {bigint|number} input Non-negative integer.
     * @returns {Uint8Array} CBOR bytes.
     * @throws {CborError} If `input` is negative.
     */
    static encodeUnsignedInteger(input: bigint | number): Uint8Array;
    private static getAdditionalInformationBits;
    private static getUnsignedIntegerAsPaddedBytes;
}
