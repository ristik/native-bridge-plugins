import { CborMapEntry } from './CborMapEntry.js';
/**
 * Canonical CBOR map: entries are kept sorted by encoded key bytes and
 * duplicate keys are rejected, matching the canonical ordering rules in
 * RFC 8949 §4.2.
 */
export declare class CborMap {
    private readonly _entries;
    constructor(entries: CborMapEntry[]);
    /**
     * @returns {CborMapEntry[]} Copy of the entry list.
     */
    get entries(): CborMapEntry[];
    /**
     * Canonical CBOR map entry ordering.
     *
     * @param {CborMapEntry} a First entry.
     * @param {CborMapEntry} b Second entry.
     * @returns {number} Negative if `a` sorts before `b`, positive if after, zero if equal.
     */
    static compareEntries(a: CborMapEntry, b: CborMapEntry): number;
}
