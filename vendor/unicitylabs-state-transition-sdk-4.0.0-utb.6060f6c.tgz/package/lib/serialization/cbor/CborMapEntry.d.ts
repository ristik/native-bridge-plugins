/**
 * Single key/value pair inside a {@link CborMap}. Both key and value are
 * stored as already-encoded canonical CBOR byte slices.
 */
export declare class CborMapEntry {
    private readonly _key;
    private readonly _value;
    constructor(_key: Uint8Array, _value: Uint8Array);
    /**
     * @returns {Uint8Array} Copy of the encoded key bytes.
     */
    get key(): Uint8Array;
    /**
     * @returns {Uint8Array} Copy of the encoded value bytes.
     */
    get value(): Uint8Array;
}
