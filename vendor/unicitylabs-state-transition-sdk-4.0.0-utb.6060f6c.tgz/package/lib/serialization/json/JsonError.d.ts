/**
 * Thrown when a value cannot be deserialized from JSON because it fails a
 * semantic validity check (unsupported version, broken invariants, out-of-range
 * values, etc.).
 */
export declare class JsonError extends Error {
}
