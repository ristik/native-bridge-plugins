import { CertifiedMintTransaction } from './CertifiedMintTransaction.js';
import { IMintOptions } from './IMintOptions.js';
import { ITransaction } from './ITransaction.js';
import { MintTransactionState } from './MintTransactionState.js';
import { StateMask } from './StateMask.js';
import { TokenId } from './TokenId.js';
import { TokenSalt } from './TokenSalt.js';
import { TokenType } from './TokenType.js';
import { ITrustBaseAuthority } from '../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateVerifier } from '../api/bft/verification/UnicityCertificateVerifier.js';
import { InclusionProof } from '../api/InclusionProof.js';
import { NetworkId } from '../api/NetworkId.js';
import { DataHash } from '../crypto/hash/DataHash.js';
import { EncodedPredicate } from '../predicate/EncodedPredicate.js';
import { IPredicate } from '../predicate/IPredicate.js';
import { PredicateVerifierService } from '../predicate/verification/PredicateVerifierService.js';
/**
 * Token mint transaction.
 */
export declare class MintTransaction implements ITransaction {
    readonly sourceStateHash: MintTransactionState;
    readonly lockScript: EncodedPredicate;
    readonly networkId: NetworkId;
    readonly recipient: EncodedPredicate;
    readonly salt: TokenSalt;
    readonly tokenType: TokenType;
    readonly tokenId: TokenId;
    readonly expiresAt: bigint | null;
    private readonly _justification;
    private readonly _data;
    static readonly CBOR_TAG = 39041n;
    /** The only accepted wire version. One version, one element count. */
    static readonly VERSION = 2n;
    private static readonly FIELD_COUNT;
    private readonly _brand;
    private constructor();
    /**
     * @returns {Uint8Array|null} Copy of the data payload, or `null` if absent.
     */
    get data(): Uint8Array | null;
    /**
     * @returns {Uint8Array|null} Copy of the mint justification bytes, or `null` if absent.
     */
    get justification(): Uint8Array | null;
    /**
     * @returns {StateMask} State mask used when computing the resulting state hash (the token identifier).
     */
    get stateMask(): StateMask;
    /**
     * @returns {bigint} Wire-format version of this mint transaction.
     */
    get version(): bigint;
    /**
     * Create a MintTransaction for a fresh token.
     *
     * @param {NetworkId} networkId Network identifier.
     * @param {IPredicate} recipient Predicate that will lock the minted state.
     * @param {IMintOptions} options Optional data, token type, salt, justification and request deadline.
     * @returns {Promise<MintTransaction>} New mint transaction.
     */
    static create(networkId: NetworkId, recipient: IPredicate, options?: IMintOptions): Promise<MintTransaction>;
    /**
     * Create MintTransaction from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {Promise<MintTransaction>} Decoded transaction.
     * @throws {CborError} On wrong tag or unsupported version.
     */
    static fromCBOR(bytes: Uint8Array): Promise<MintTransaction>;
    /**
     * @inheritDoc
     */
    calculateStateHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    calculateTransactionHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    toCBOR(): Uint8Array;
    /**
     * Bundle this transaction with its inclusion proof into a CertifiedMintTransaction.
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
     * @param {PredicateVerifierService} predicateVerifier Verifier for any predicates.
     * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
     * @param {InclusionProof} inclusionProof Inclusion proof for this transaction.
     * @returns {Promise<CertifiedMintTransaction>} Verified certified transaction.
     */
    toCertifiedTransaction(trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, inclusionProof: InclusionProof): Promise<CertifiedMintTransaction>;
    /**
     * @returns {string} String representation of the transaction.
     */
    toString(): string;
}
