import { ShardTreeCertificate } from '../../../api/bft/ShardTreeCertificate.js';
import { StateId } from '../../../api/StateId.js';
import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
/**
 * Verifies that a state id falls under the shard identified by a shard tree
 * certificate.
 */
export declare class ShardIdMatchesStateIdRule {
    /**
     * Verify that the certificate has one sibling per shard id bit and that `stateId` is prefixed by its shard id.
     *
     * @param {StateId} stateId State id under verification.
     * @param {ShardTreeCertificate} shardTreeCertificate Shard tree certificate carrying the expected shard.
     * @returns {VerificationResult<VerificationStatus>} OK if the sibling count equals the shard length and the shard is empty or a prefix, FAIL otherwise.
     */
    static verify(stateId: StateId, shardTreeCertificate: ShardTreeCertificate): VerificationResult<VerificationStatus>;
}
