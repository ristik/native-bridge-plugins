import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import { CertifiedMintTransaction } from '../../CertifiedMintTransaction.js';
import type { Token } from '../../Token.js';
import { IVerificationContext } from '../IVerificationContext.js';
/**
 * Genesis verification rule.
 */
export declare class CertifiedMintTransactionVerificationRule {
    /**
     * Verify a certified mint genesis.
     *
     * @param {CertifiedMintTransaction} genesis Certified mint transaction to verify.
     * @param {IVerificationContext} verificationContext Shared verification context (trust base + registries).
     * @param {(token: Token) => void} nestedTokenCollector Receives tokens embedded in the mint justification that the caller must verify.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     */
    static verify(genesis: CertifiedMintTransaction, verificationContext: IVerificationContext, nestedTokenCollector: (token: Token) => void): Promise<VerificationResult<VerificationStatus>>;
}
