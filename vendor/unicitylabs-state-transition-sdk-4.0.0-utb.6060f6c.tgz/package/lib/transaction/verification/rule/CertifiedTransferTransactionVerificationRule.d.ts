import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import { CertifiedTransferTransaction } from '../../CertifiedTransferTransaction.js';
import { ITransactionVerificationContext } from '../IVerificationContext.js';
/**
 * Transfer transaction verification rule.
 */
export declare class CertifiedTransferTransactionVerificationRule {
    /**
     * Verify a certified transfer transaction.
     *
     * @param {CertifiedTransferTransaction} transaction Transfer transaction to verify.
     * @param {ITransactionVerificationContext} verificationContext Shared verification context (trust base + registries).
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     */
    static verify(transaction: CertifiedTransferTransaction, verificationContext: ITransactionVerificationContext): Promise<VerificationResult<VerificationStatus>>;
}
