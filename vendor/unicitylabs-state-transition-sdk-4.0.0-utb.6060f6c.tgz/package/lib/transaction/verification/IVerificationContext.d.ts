import { MintJustificationVerifierService } from './MintJustificationVerifierService.js';
import { TokenIssuanceVerifierService } from './TokenIssuanceVerifierService.js';
import { ITrustBaseAuthority } from '../../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateVerifier } from '../../api/bft/verification/UnicityCertificateVerifier.js';
import { PredicateVerifierService } from '../../predicate/verification/PredicateVerifierService.js';
/**
 * Immutable bundle of the dependencies shared across a (possibly recursive) token
 * verification: the single root of trust, the predicate verifier, and the
 * mint-justification and token-issuance registries. It holds no mutable state, so
 * a nested (e.g. burned source) token is always verified under the same root of
 * trust and registries as the outer token.
 */
export interface IVerificationContext {
    readonly mintJustificationVerifier: MintJustificationVerifierService;
    readonly predicateVerifier: PredicateVerifierService;
    readonly tokenIssuanceVerifier: TokenIssuanceVerifierService;
    readonly trustBase: ITrustBaseAuthority;
    readonly unicityCertificateVerifier: UnicityCertificateVerifier;
}
/**
 * The part of the context a rule needs to verify one transaction in isolation.
 *
 * A rule that verifies a single transaction has no use for the mint-justification or
 * token-issuance registries, and asking for them would oblige a caller that has no token — the
 * worker verifying one transfer, for instance — to invent them.
 */
export type ITransactionVerificationContext = Pick<IVerificationContext, 'predicateVerifier' | 'trustBase' | 'unicityCertificateVerifier'>;
