import { IMintJustificationVerifier } from './IMintJustificationVerifier.js';
import { VerificationResult } from '../../verification/VerificationResult.js';
import { VerificationStatus } from '../../verification/VerificationStatus.js';
import { CertifiedMintTransaction } from '../CertifiedMintTransaction.js';
import type { Token } from '../Token.js';
/**
 * Registry that dispatches mint justification verification to the right
 * {@link IMintJustificationVerifier} based on the justification's CBOR tag.
 */
export declare class MintJustificationVerifierService {
    private readonly verifiers;
    /**
     * Register a verifier for its declared tag.
     *
     * @param {IMintJustificationVerifier} verifier Verifier to register.
     * @returns {MintJustificationVerifierService} This service for chaining.
     * @throws {Error} If a verifier is already registered for the tag.
     */
    register(verifier: IMintJustificationVerifier): this;
    /**
     * Verify the given mint justification with the registered verifier for its tag.
     *
     * @param {CertifiedMintTransaction} transaction Certified mint transaction whose justification to verify.
     * @param {(token: Token) => void} nestedTokenCollector Receives tokens embedded in the justification that the caller must verify.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     */
    verify(transaction: CertifiedMintTransaction, nestedTokenCollector: (token: Token) => void): Promise<VerificationResult<VerificationStatus>>;
}
