import { CertifiedMintTransaction } from '../CertifiedMintTransaction.js';
import { ITokenIssuanceVerifier } from './ITokenIssuanceVerifier.js';
import { VerificationResult } from '../../verification/VerificationResult.js';
import { VerificationStatus } from '../../verification/VerificationStatus.js';
/**
 * Registry that dispatches token verification to the right
 * {@link ITokenIssuanceVerifier} based on the token's type. A token type with no
 * registered verifier is rejected by default, and only accepted when
 * `rejectUnregisteredTypes` is explicitly set to `false`.
 */
export declare class TokenIssuanceVerifierService {
    private readonly rejectUnregisteredTypes;
    private readonly verifiers;
    /**
     * Create a token issuance verifier registry.
     *
     * @param {boolean} rejectUnregisteredTypes When true, reject any token whose type has no registered issuance verifier.
     */
    constructor(rejectUnregisteredTypes?: boolean);
    /**
     * Register a policy for its declared token type.
     *
     * @param {ITokenIssuanceVerifier} verifier Verifier to register.
     * @returns {TokenIssuanceVerifierService} This service for chaining.
     * @throws {Error} If a policy is already registered for the token type.
     */
    register(verifier: ITokenIssuanceVerifier): this;
    /**
     * Verify a token's genesis against the policy registered for its type.
     *
     * @param {CertifiedMintTransaction} transaction Genesis mint transaction whose token data to verify.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     */
    verify(transaction: CertifiedMintTransaction): Promise<VerificationResult<VerificationStatus>>;
}
