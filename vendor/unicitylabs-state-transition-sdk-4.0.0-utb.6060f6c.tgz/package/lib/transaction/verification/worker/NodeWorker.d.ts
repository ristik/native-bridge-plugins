import { Worker } from 'node:worker_threads';
import { IWorker } from './IWorker.js';
import { ITransferTransactionVerificationRequest, TransferTransactionVerificationResponse } from './WorkerTokenVerifier.js';
/**
 * Adapts a Node `worker_threads.Worker` to the web {@link IWorker} shape, for use in a
 * {@link WorkerTokenVerifier} subclass's `createWorker`:
 * `new NodeWorker(new Worker(new URL('./MyWorker.js', import.meta.url)))`.
 */
export declare class NodeWorker implements IWorker {
    private readonly worker;
    onerror: ((event: {
        message: string;
    }) => void) | null;
    onmessage: ((event: {
        data: TransferTransactionVerificationResponse;
    }) => void) | null;
    constructor(worker: Worker);
    postMessage(message: ITransferTransactionVerificationRequest): void;
    terminate(): void;
}
