import { TransferTransactionVerifier } from './WorkerTokenVerifier.js';
/**
 * Base for Node.js worker entry scripts: a {@link TransferTransactionVerifier} that runs
 * itself in the worker thread. A consumer entry script extends it with its predicate
 * verifier, instantiates it and calls {@link bootstrap}; a
 * {@link WorkerTokenVerifier} subclass's `createWorker` spawns that script.
 */
export declare abstract class NodeTransferTransactionVerifierWorker extends TransferTransactionVerifier {
    /**
     * Verify every transfer batch posted on the parent port with this verifier. No-op when
     * called outside a worker thread.
     */
    bootstrap(): void;
}
