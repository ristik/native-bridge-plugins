import { TransferTransactionVerifier } from './WorkerTokenVerifier.js';
/**
 * Base for browser worker entry scripts: a {@link TransferTransactionVerifier} that runs
 * itself in the Web Worker. A consumer entry script extends it with its predicate
 * verifier, instantiates it and calls {@link bootstrap}; a {@link WorkerTokenVerifier}
 * subclass's `createWorker` spawns that script.
 */
export declare abstract class BrowserTransferTransactionVerifierWorker extends TransferTransactionVerifier {
    /**
     * Verify every transfer batch posted to the worker with this verifier. No-op on the
     * main thread, where `WorkerGlobalScope` is not exposed.
     */
    bootstrap(): void;
}
