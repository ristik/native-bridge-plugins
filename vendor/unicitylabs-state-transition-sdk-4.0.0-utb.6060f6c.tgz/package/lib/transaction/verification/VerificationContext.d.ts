import { IVerificationContext } from './IVerificationContext.js';
import { MintJustificationVerifierService } from './MintJustificationVerifierService.js';
import { TokenIssuanceVerifierService } from './TokenIssuanceVerifierService.js';
import { ITrustBaseAuthority } from '../../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateVerifier } from '../../api/bft/verification/UnicityCertificateVerifier.js';
import { PredicateVerifierService } from '../../predicate/verification/PredicateVerifierService.js';
/**
 * Default {@link IVerificationContext} implementation. All verifiers must be supplied
 * explicitly: a defaulted token-issuance verifier would be an empty fail-closed registry
 * that rejects every token, so there is no sensible default. Build and populate the
 * verifiers before constructing the context and pass them in — the context itself is immutable.
 */
export declare class VerificationContext implements IVerificationContext {
    readonly trustBase: ITrustBaseAuthority;
    readonly predicateVerifier: PredicateVerifierService;
    readonly unicityCertificateVerifier: UnicityCertificateVerifier;
    readonly mintJustificationVerifier: MintJustificationVerifierService;
    readonly tokenIssuanceVerifier: TokenIssuanceVerifierService;
    /**
     * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
     * @param {PredicateVerifierService} predicateVerifier Predicate verifier.
     * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
     * @param {MintJustificationVerifierService} mintJustificationVerifier Mint justification registry.
     * @param {TokenIssuanceVerifierService} tokenIssuanceVerifier Token issuance registry.
     */
    constructor(trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, mintJustificationVerifier: MintJustificationVerifierService, tokenIssuanceVerifier: TokenIssuanceVerifierService);
}
