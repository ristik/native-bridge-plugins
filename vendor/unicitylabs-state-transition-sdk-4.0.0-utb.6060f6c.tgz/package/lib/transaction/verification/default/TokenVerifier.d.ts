import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import type { Token } from '../../Token.js';
import { ITokenVerifier } from '../ITokenVerifier.js';
import { IVerificationContext } from '../IVerificationContext.js';
/**
 * Default {@link ITokenVerifier}: verifies the genesis and every transfer of a token
 * sequentially, on any platform. This is the implementation behind {@link Token.verify}
 * and the baseline the worker verifiers must match.
 *
 * Tokens embedded in a mint justification (such as the burned source token of a split)
 * are collected during verification and verified iteratively from a worklist rather than
 * recursively, so an arbitrarily long provenance chain is walked without recursion.
 */
export declare class TokenVerifier implements ITokenVerifier {
    /**
     * @inheritDoc
     */
    verify(token: Token, outer: IVerificationContext): Promise<VerificationResult<VerificationStatus>>;
}
