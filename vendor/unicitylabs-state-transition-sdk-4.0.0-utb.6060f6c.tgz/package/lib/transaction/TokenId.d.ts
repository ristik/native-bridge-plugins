import { TokenSalt } from './TokenSalt.js';
import { NetworkId } from '../api/NetworkId.js';
import { BitString } from '../util/BitString.js';
/**
 * Globally unique identifier of a token.
 */
export declare class TokenId {
    private readonly _bytes;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the identifier bytes.
     */
    get bytes(): Uint8Array;
    /**
     * Create TokenId from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {TokenId} Decoded token id.
     */
    static fromCBOR(bytes: Uint8Array): TokenId;
    /**
     * Derive a TokenId from a salt and network identifier.
     *
     * @param {NetworkId} networkId Network identifier.
     * @param {TokenSalt} salt Mint-transaction salt.
     * @returns {Promise<TokenId>} Derived token id.
     */
    static fromSalt(networkId: NetworkId, salt: TokenSalt): Promise<TokenId>;
    /**
     * Equality check against another value.
     *
     * @param {unknown} o Other value.
     * @returns {boolean} True if `o` is a TokenId with the same bytes.
     */
    equals(o: unknown): boolean;
    /**
     * Convert the TokenId to a bit-string representation.
     *
     * @returns {BitString} Bit-string view of the identifier bytes.
     */
    toBitString(): BitString;
    /**
     * Convert TokenId to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} Human-readable representation of the token id.
     */
    toString(): string;
}
