import { ITransaction } from './ITransaction.js';
import { MintTransaction } from './MintTransaction.js';
import { StateMask } from './StateMask.js';
import { TokenId } from './TokenId.js';
import { TokenSalt } from './TokenSalt.js';
import { TokenType } from './TokenType.js';
import { ITrustBaseAuthority } from '../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateInterner } from '../api/bft/UnicityCertificateInterner.js';
import { UnicityCertificateVerifier } from '../api/bft/verification/UnicityCertificateVerifier.js';
import { InclusionProof } from '../api/InclusionProof.js';
import { NetworkId } from '../api/NetworkId.js';
import { DataHash } from '../crypto/hash/DataHash.js';
import { EncodedPredicate } from '../predicate/EncodedPredicate.js';
import { PredicateVerifierService } from '../predicate/verification/PredicateVerifierService.js';
/**
 * Mint transaction bundled with a verified inclusion proof.
 */
export declare class CertifiedMintTransaction implements ITransaction {
    private readonly transaction;
    readonly inclusionProof: InclusionProof;
    private readonly _brand;
    private constructor();
    /**
     * @returns {Uint8Array|null} Data payload of the inner transaction.
     */
    get data(): Uint8Array | null;
    /**
     * @returns {bigint|null} Exclusive request deadline of the inner transaction, in Unix seconds.
     */
    get expiresAt(): bigint | null;
    /**
     * @returns {Uint8Array|null} Mint justification bytes of the inner transaction.
     */
    get justification(): Uint8Array | null;
    /**
     * @returns {EncodedPredicate} Lock script of the inner transaction.
     */
    get lockScript(): EncodedPredicate;
    /**
     * @returns {NetworkId} Network identifier of the inner transaction.
     */
    get networkId(): NetworkId;
    /**
     * @returns {EncodedPredicate} Recipient predicate of the inner transaction.
     */
    get recipient(): EncodedPredicate;
    /**
     * @returns {bigint} Reference time of the round the leaf was created in, in Unix seconds.
     *
     * Read from the inclusion proof rather than stored beside it: the service
     * records the leaf's creation time on the record itself and serves that same
     * value for every proof of the leaf, and the leaf value binds it, so the
     * proof is the authenticated source for it.
     */
    get referenceTime(): bigint;
    /**
     * @returns {TokenSalt} Mint-transaction salt of the inner transaction.
     */
    get salt(): TokenSalt;
    /**
     * @returns {DataHash} Source state hash of the inner transaction.
     */
    get sourceStateHash(): DataHash;
    /**
     * @returns {StateMask} State mask of the inner transaction.
     */
    get stateMask(): StateMask;
    /**
     * @returns {TokenId} Token id of the inner transaction (derived from networkId and salt).
     */
    get tokenId(): TokenId;
    /**
     * @returns {TokenType} Token type of the inner transaction.
     */
    get tokenType(): TokenType;
    /**
     * Create CertifiedMintTransaction from CBOR bytes within a decoding operation sharing identical wire certificates.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @param {UnicityCertificateInterner} [interner] Decoding operation, or none to parse every certificate.
     * @returns {Promise<CertifiedMintTransaction>} Decoded certified transaction.
     */
    static decodeWith(bytes: Uint8Array, interner?: UnicityCertificateInterner): Promise<CertifiedMintTransaction>;
    /**
     * Create CertifiedMintTransaction from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {Promise<CertifiedMintTransaction>} Decoded certified transaction.
     */
    static fromCBOR(bytes: Uint8Array): Promise<CertifiedMintTransaction>;
    /**
     * Create CertifiedMintTransaction from mint transaction and inclusion proof.
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
     * @param {PredicateVerifierService} predicateVerifier Verifier for any embedded predicates.
     * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
     * @param {MintTransaction} transaction Transaction to certify.
     * @param {InclusionProof} inclusionProof Inclusion proof for the transaction.
     * @returns {Promise<CertifiedMintTransaction>} Verified certified transaction.
     * @throws {VerificationError} If the inclusion proof does not verify.
     */
    static fromTransaction(trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, transaction: MintTransaction, inclusionProof: InclusionProof): Promise<CertifiedMintTransaction>;
    /**
     * @inheritDoc
     */
    calculateStateHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    calculateTransactionHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} String representation of the certified transaction.
     */
    toString(): string;
}
