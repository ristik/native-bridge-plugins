import { TokenId } from './TokenId.js';
import { DataHash } from '../crypto/hash/DataHash.js';
/**
 * Token mint state.
 */
export declare class MintTransactionState extends DataHash {
    /**
     * Constant suffix used when deriving the mint initial state.
     * "TOKENID" SHA-256 hash
     */
    private static readonly MINT_SUFFIX;
    private constructor();
    /**
     * Create token initial state from token id.
     *
     * @param {TokenId} tokenId Token id.
     * @returns {Promise<MintTransactionState>} Mint state.
     */
    static create(tokenId: TokenId): Promise<MintTransactionState>;
}
