import { ITransaction } from './ITransaction.js';
import { StateMask } from './StateMask.js';
import { TransferTransaction } from './TransferTransaction.js';
import { ITrustBaseAuthority } from '../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateInterner } from '../api/bft/UnicityCertificateInterner.js';
import { UnicityCertificateVerifier } from '../api/bft/verification/UnicityCertificateVerifier.js';
import { InclusionProof } from '../api/InclusionProof.js';
import { DataHash } from '../crypto/hash/DataHash.js';
import { EncodedPredicate } from '../predicate/EncodedPredicate.js';
import { PredicateVerifierService } from '../predicate/verification/PredicateVerifierService.js';
/**
 * Transfer transaction bundled with a verified inclusion proof.
 */
export declare class CertifiedTransferTransaction implements ITransaction {
    private readonly transaction;
    readonly inclusionProof: InclusionProof;
    private constructor();
    /**
     * @returns {Uint8Array|null} Data payload of the inner transaction.
     */
    get data(): Uint8Array | null;
    /**
     * @returns {bigint|null} Exclusive request deadline of the inner transaction, in Unix seconds.
     */
    get expiresAt(): bigint | null;
    /**
     * @returns {EncodedPredicate} Lock script of the inner transaction.
     */
    get lockScript(): EncodedPredicate;
    /**
     * @returns {EncodedPredicate} Recipient predicate of the inner transaction.
     */
    get recipient(): EncodedPredicate;
    /**
     * @returns {bigint} Reference time of the round the leaf was created in, in Unix seconds.
     *
     * Read from the inclusion proof rather than stored beside it: the service
     * records the leaf's creation time on the record itself and serves that same
     * value for every proof of the leaf, and the leaf value binds it, so the
     * proof is the authenticated source for it.
     */
    get referenceTime(): bigint;
    /**
     * @returns {DataHash} Source state hash of the inner transaction.
     */
    get sourceStateHash(): DataHash;
    /**
     * @returns {StateMask} State mask of the inner transaction.
     */
    get stateMask(): StateMask;
    /**
     * Create CertifiedTransferTransaction from CBOR bytes within a decoding operation sharing identical wire
     * certificates.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @param {DataHash} sourceStateHash Hash of the state the transfer spends.
     * @param {EncodedPredicate} lockScript Lock script the transfer unlocks.
     * @param {UnicityCertificateInterner} [interner] Decoding operation, or none to parse every certificate.
     * @returns {CertifiedTransferTransaction} Decoded certified transaction.
     */
    static decodeWith(bytes: Uint8Array, sourceStateHash: DataHash, lockScript: EncodedPredicate, interner?: UnicityCertificateInterner): CertifiedTransferTransaction;
    /**
     * Create CertifiedTransferTransaction from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @param {DataHash} sourceStateHash Hash of the state the transfer spends.
     * @param {EncodedPredicate} lockScript Lock script the transfer unlocks.
     * @returns {CertifiedTransferTransaction} Decoded certified transaction.
     */
    static fromCBOR(bytes: Uint8Array, sourceStateHash: DataHash, lockScript: EncodedPredicate): CertifiedTransferTransaction;
    /**
     * Create CertifiedTransferTransaction from mint transaction and inclusion proof.
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
     * @param {PredicateVerifierService} predicateVerifier Verifier for any embedded predicates.
     * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
     * @param {TransferTransaction} transaction Transaction to certify.
     * @param {InclusionProof} inclusionProof Inclusion proof for the transaction.
     * @returns {Promise<CertifiedTransferTransaction>} Verified certified transaction.
     * @throws {VerificationError} If the inclusion proof does not verify.
     */
    static fromTransaction(trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, transaction: TransferTransaction, inclusionProof: InclusionProof): Promise<CertifiedTransferTransaction>;
    /**
     * @inheritDoc
     */
    calculateStateHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    calculateTransactionHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} String representation of the certified transaction.
     */
    toString(): string;
}
