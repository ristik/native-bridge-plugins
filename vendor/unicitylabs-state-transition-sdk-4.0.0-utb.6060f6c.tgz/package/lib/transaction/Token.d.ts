import { CertifiedMintTransaction } from './CertifiedMintTransaction.js';
import { CertifiedTransferTransaction } from './CertifiedTransferTransaction.js';
import { ITransaction } from './ITransaction.js';
import { TokenId } from './TokenId.js';
import { TokenType } from './TokenType.js';
import { IVerificationContext } from './verification/IVerificationContext.js';
import { UnicityCertificateInterner } from '../api/bft/UnicityCertificateInterner.js';
import { NetworkId } from '../api/NetworkId.js';
import { VerificationResult } from '../verification/VerificationResult.js';
import { VerificationStatus } from '../verification/VerificationStatus.js';
/**
 * Token representation.
 */
export declare class Token {
    readonly genesis: CertifiedMintTransaction;
    private readonly _transactions;
    static readonly CBOR_TAG = 39040n;
    /**
     * The only accepted wire version. Bumped with the certified-transaction
     * element counts and the transaction encodings below them: without it a token
     * written by an older SDK passes the version check here and then dies deeper
     * down on a CBOR array-length error that never mentions versioning.
     */
    private static readonly VERSION;
    private constructor();
    /**
     * @returns {TokenId} Token id from the genesis transaction.
     */
    get id(): TokenId;
    /**
     * @returns {ITransaction} Latest transaction, or the genesis if there are no transfers.
     */
    get latestTransaction(): ITransaction;
    /**
     * @returns {NetworkId} Network identifier from the genesis transaction.
     */
    get networkId(): NetworkId;
    /**
     * @returns {CertifiedTransferTransaction[]} Copy of the transfer history.
     */
    get transactions(): CertifiedTransferTransaction[];
    /**
     * @returns {TokenType} Token type from the genesis transaction.
     */
    get type(): TokenType;
    /**
     * @returns {bigint} Wire-format version of this token.
     */
    get version(): bigint;
    /**
     * Create Token from CBOR bytes within the given decoding operation, e.g. to share it with other decodes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @param {UnicityCertificateInterner} interner Decoding operation sharing identical wire certificates.
     * @returns {Promise<Token>} Decoded token.
     * @throws {CborError} On wrong tag or unsupported version.
     */
    static decodeWith(bytes: Uint8Array, interner: UnicityCertificateInterner): Promise<Token>;
    /**
     * Create Token from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {Promise<Token>} Decoded token. Identical wire certificates of its proofs are parsed once.
     * @throws {CborError} On wrong tag or unsupported version.
     */
    static fromCBOR(bytes: Uint8Array): Promise<Token>;
    /**
     * Create a Token from a verified genesis mint transaction.
     *
     * @param {CertifiedMintTransaction} genesis Genesis mint transaction.
     * @param {IVerificationContext} verificationContext Shared verification context (trust base + registries).
     * @returns {Promise<Token>} New token.
     * @throws {VerificationError} If the genesis does not verify.
     */
    static mint(genesis: CertifiedMintTransaction, verificationContext: IVerificationContext): Promise<Token>;
    /**
     * Convert Token to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} String representation of the token.
     */
    toString(): string;
    /**
     * Append token with certified transfer transaction.
     *
     * @param {CertifiedTransferTransaction} transaction Transfer transaction to apply.
     * @param {IVerificationContext} verificationContext Shared verification context (trust base + registries).
     * @returns {Promise<Token>} Updated token including the new transaction.
     * @throws {VerificationError} If the transfer transaction does not verify.
     */
    transfer(transaction: CertifiedTransferTransaction, verificationContext: IVerificationContext): Promise<Token>;
    /**
     * Verify the genesis and every transfer in this token using the default
     * {@link TokenVerifier}. Kept for convenience and backwards compatibility; the
     * verification logic itself lives in {@link TokenVerifier} and can be swapped
     * for a platform-specific {@link ITokenVerifier}.
     *
     * @param {IVerificationContext} verificationContext Shared verification context (trust base + registries).
     * @returns {Promise<VerificationResult<VerificationStatus>>} Aggregated verification result.
     */
    verify(verificationContext: IVerificationContext): Promise<VerificationResult<VerificationStatus>>;
}
