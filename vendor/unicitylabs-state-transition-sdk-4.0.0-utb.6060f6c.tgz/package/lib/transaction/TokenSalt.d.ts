/**
 * Variable-length salt mixed with a network identifier to derive a
 * {@link TokenId}. The minter chooses the length within
 * `[{@link TokenSalt.MIN_LENGTH}, {@link TokenSalt.MAX_LENGTH}]` bytes: at least
 * 128 bits of entropy, and an upper bound so untrusted token blobs cannot carry
 * an arbitrarily large salt.
 */
export declare class TokenSalt {
    private readonly _bytes;
    static readonly LENGTH = 32;
    static readonly MAX_LENGTH = 64;
    static readonly MIN_LENGTH = 16;
    private constructor();
    /**
     * Wrap an existing salt. The salt is variable-length but must carry at least
     * 128 bits of entropy and stay within the upper bound, so it must be between
     * {@link TokenSalt.MIN_LENGTH} and {@link TokenSalt.MAX_LENGTH} bytes.
     *
     * @param {Uint8Array} bytes Salt bytes; must be 16 to 64 bytes.
     * @returns {TokenSalt} New salt.
     * @throws {Error} If `bytes` is outside `[{@link TokenSalt.MIN_LENGTH}, {@link TokenSalt.MAX_LENGTH}]`.
     */
    static fromBytes(bytes: Uint8Array): TokenSalt;
    /**
     * Create TokenSalt from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {TokenSalt} Decoded salt.
     */
    static fromCBOR(bytes: Uint8Array): TokenSalt;
    /**
     * Generate a fresh random 32-byte TokenSalt.
     *
     * @returns {TokenSalt} New random salt.
     */
    static generate(): TokenSalt;
    /**
     * Equality check against another value.
     *
     * @param {unknown} o Other value.
     * @returns {boolean} True if `o` is a TokenSalt with the same bytes.
     */
    equals(o: unknown): boolean;
    /**
     * @returns {Uint8Array} Copy of the salt bytes.
     */
    toBytes(): Uint8Array;
    /**
     * Convert TokenSalt to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} Hex representation of the salt.
     */
    toString(): string;
}
