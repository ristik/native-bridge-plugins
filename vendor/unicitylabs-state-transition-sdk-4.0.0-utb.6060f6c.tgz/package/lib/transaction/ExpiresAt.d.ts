/**
 * Validate an exclusive request deadline at the boundary that accepts it.
 *
 * Without this the range errors surface much later and far from the mistake:
 * a negative or oversized value encodes nowhere and fails inside
 * {@link CborSerializer} while the transaction hash is being computed, and `0n`
 * encodes fine but produces a request that is expired by construction, since
 * every reference time is at or past it.
 *
 * @param {bigint|null} expiresAt Deadline in Unix seconds, or `null` to let the service assign one.
 * @returns {bigint|null} The validated deadline, unchanged.
 * @throws {CborError} If the deadline cannot be encoded or is already unusable.
 */
export declare function validateExpiresAt(expiresAt: bigint | null): bigint | null;
