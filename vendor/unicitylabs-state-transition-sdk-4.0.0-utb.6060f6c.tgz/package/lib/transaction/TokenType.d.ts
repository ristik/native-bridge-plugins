/** Unique identifier describing the type/category of a token. */
export declare class TokenType {
    private readonly _bytes;
    static readonly MAX_LENGTH = 64;
    static readonly MIN_LENGTH = 1;
    constructor(_bytes: Uint8Array);
    /**
     * @returns {Uint8Array} Copy of the token type bytes.
     */
    get bytes(): Uint8Array;
    /**
     * Create TokenType from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {TokenType} Decoded token type.
     */
    static fromCBOR(bytes: Uint8Array): TokenType;
    /**
     * Generate a fresh random TokenType.
     *
     * @returns {TokenType} New token type with random 32-byte payload.
     */
    static generate(): TokenType;
    /**
     * Convert TokenType to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} Human-readable representation of the token type.
     */
    toString(): string;
}
