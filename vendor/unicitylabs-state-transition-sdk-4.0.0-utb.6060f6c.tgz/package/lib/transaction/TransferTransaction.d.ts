import { CertifiedTransferTransaction } from './CertifiedTransferTransaction.js';
import { ITransaction } from './ITransaction.js';
import { ITransferOptions } from './ITransferOptions.js';
import { StateMask } from './StateMask.js';
import { Token } from './Token.js';
import { ITrustBaseAuthority } from '../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateVerifier } from '../api/bft/verification/UnicityCertificateVerifier.js';
import { InclusionProof } from '../api/InclusionProof.js';
import { DataHash } from '../crypto/hash/DataHash.js';
import { EncodedPredicate } from '../predicate/EncodedPredicate.js';
import { IPredicate } from '../predicate/IPredicate.js';
import { PredicateVerifierService } from '../predicate/verification/PredicateVerifierService.js';
/**
 * Token transfer transaction.
 */
export declare class TransferTransaction implements ITransaction {
    readonly sourceStateHash: DataHash;
    readonly lockScript: EncodedPredicate;
    readonly recipient: EncodedPredicate;
    readonly expiresAt: bigint | null;
    private readonly _stateMask;
    private readonly _data;
    static readonly CBOR_TAG = 39045n;
    /** The only accepted wire version. One version, one element count. */
    static readonly VERSION = 2n;
    private static readonly FIELD_COUNT;
    private constructor();
    /**
     * @returns {Uint8Array|null} Copy of the data payload, or `null` if absent.
     */
    get data(): Uint8Array | null;
    /**
     * @returns {StateMask} The state mask.
     */
    get stateMask(): StateMask;
    /**
     * @returns {bigint} Wire-format version of this transfer transaction.
     */
    get version(): bigint;
    /**
     * Create a TransferTransaction for the given token.
     *
     * @param {Token} token Token being transferred (last transaction is used as the source).
     * @param {IPredicate} recipient Predicate that will lock the new state.
     * @param {StateMask} stateMask State mask mixed into the new state hash.
     * @param {ITransferOptions} options Optional data payload and request deadline.
     * @returns {Promise<TransferTransaction>} New transfer transaction.
     */
    static create(token: Token, recipient: IPredicate, stateMask: StateMask, options?: ITransferOptions): Promise<TransferTransaction>;
    /**
     * Create TransferTransaction from CBOR bytes.
     *
     * The state being spent and the lock script over it are chain context rather than part of the
     * encoded transfer, so the caller supplies them. Both are checked against the certification data
     * during verification, so a wrong value fails there rather than yielding a transaction that
     * looks valid.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @param {DataHash} sourceStateHash Hash of the state the transaction spends.
     * @param {EncodedPredicate} lockScript Lock script the transaction unlocks.
     * @returns {TransferTransaction} Decoded transaction.
     * @throws {CborError} On wrong tag or unsupported version.
     */
    static fromCBOR(bytes: Uint8Array, sourceStateHash: DataHash, lockScript: EncodedPredicate): TransferTransaction;
    /**
     * @inheritDoc
     */
    calculateStateHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    calculateTransactionHash(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    toCBOR(): Uint8Array;
    /**
     * Bundle this transaction with its inclusion proof into a CertifiedTransferTransaction.
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
     * @param {PredicateVerifierService} predicateVerifier Verifier for any embedded predicates.
     * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
     * @param {InclusionProof} inclusionProof Inclusion proof for this transaction.
     * @returns {Promise<CertifiedTransferTransaction>} Verified certified transaction.
     */
    toCertifiedTransaction(trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, inclusionProof: InclusionProof): Promise<CertifiedTransferTransaction>;
    /**
     * @returns {string} String representation of the transaction.
     */
    toString(): string;
}
