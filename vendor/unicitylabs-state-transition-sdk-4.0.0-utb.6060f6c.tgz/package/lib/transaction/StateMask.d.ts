/**
 * Variable-length random value mixed into a transfer's next state hash. Its
 * randomness makes the next state identifier unpredictable, preventing the
 * Unicity Service from linking consecutive states of the same token. Per the
 * yellowpaper it MUST be sampled with at least 128 bits of min-entropy, so it is
 * between {@link StateMask.MIN_LENGTH} and {@link StateMask.MAX_LENGTH} bytes.
 */
export declare class StateMask {
    private readonly _bytes;
    static readonly LENGTH = 32;
    static readonly MAX_LENGTH = 64;
    static readonly MIN_LENGTH = 16;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the state mask bytes.
     */
    get bytes(): Uint8Array;
    /**
     * Wrap an existing state mask. It must carry at least 128 bits of entropy and
     * stay within the upper bound, so it must be between {@link StateMask.MIN_LENGTH}
     * and {@link StateMask.MAX_LENGTH} bytes.
     *
     * @param {Uint8Array} bytes State mask bytes; must be 16 to 64 bytes.
     * @returns {StateMask} New state mask.
     * @throws {Error} If `bytes` is outside `[{@link StateMask.MIN_LENGTH}, {@link StateMask.MAX_LENGTH}]`.
     */
    static fromBytes(bytes: Uint8Array): StateMask;
    /**
     * Create StateMask from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {StateMask} Decoded state mask.
     */
    static fromCBOR(bytes: Uint8Array): StateMask;
    /**
     * Generate a fresh random 32-byte StateMask.
     *
     * @returns {StateMask} New random state mask.
     */
    static generate(): StateMask;
    /**
     * Equality check against another value.
     *
     * @param {unknown} o Other value.
     * @returns {boolean} True if `o` is a StateMask with the same bytes.
     */
    equals(o: unknown): boolean;
    /**
     * Convert StateMask to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} Hex representation of the state mask.
     */
    toString(): string;
}
