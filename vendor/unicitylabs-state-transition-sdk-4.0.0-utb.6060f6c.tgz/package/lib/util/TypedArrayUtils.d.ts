/**
 * Returns true if both arrays are the same reference, both nullish, or contain
 * the same bytes in the same order.
 *
 * @param {Uint8Array|null|undefined} a First array.
 * @param {Uint8Array|null|undefined} b Second array.
 * @returns {boolean} True if the arrays are equal.
 */
export declare function areUint8ArraysEqual(a: Uint8Array | null | undefined, b: Uint8Array | null | undefined): boolean;
/**
 * Lexicographic comparison of two byte arrays. Arrays of different lengths
 * are ordered by length.
 *
 * @param {Uint8Array} a First array.
 * @param {Uint8Array} b Second array.
 * @returns {number} Negative if `a` sorts before `b`, positive if after, zero if equal.
 */
export declare function compareUint8Arrays(a: Uint8Array, b: Uint8Array): number;
