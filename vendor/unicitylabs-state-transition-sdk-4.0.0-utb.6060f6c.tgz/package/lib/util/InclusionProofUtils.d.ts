import { ITrustBaseAuthority } from '../api/bft/trustbase/TrustBaseAuthority.js';
import { UnicityCertificateVerifier } from '../api/bft/verification/UnicityCertificateVerifier.js';
import { ILongPollOptions } from '../api/ILongPollOptions.js';
import { InclusionProof } from '../api/InclusionProof.js';
import { ITrustBaseSource } from '../api/ITrustBaseSource.js';
import { SleepError } from '../internal/abortable.js';
import { PredicateVerifierService } from '../predicate/verification/PredicateVerifierService.js';
import { StateTransitionClient } from '../StateTransitionClient.js';
import { ITransaction } from '../transaction/ITransaction.js';
/**
 * Options of {@link waitInclusionProof}.
 */
export interface IWaitInclusionProofOptions {
    /** Delay between polls in milliseconds. Defaults to 1000. */
    readonly intervalMs?: number;
    /**
     * Ask the aggregator to hold each poll while the state is pending (long poll, `waitMs`) instead of answering at once.
     * Defaults to `true`: the wait is then bounded by `timeoutMs` (or the signal), never by this option. `false` polls exactly as
     * SDK 3.0 did, no `waitMs` is sent. An object tunes the long poll, see {@link ILongPollOptions}.
     *
     * A server without the feature ignores the request, the wait then falls back to normal polling for the rest of this
     * call (nothing is cached across calls). The positional form never long polls.
     */
    readonly longPoll?: boolean | ILongPollOptions;
    /**
     * Abort signal that terminates polling. Defaults to a 15s timeout unless `timeoutMs` is given. To bound the wait in
     * time prefer `timeoutMs`: a bare signal cannot be read as a deadline, so each poll asks for the full 20s window.
     */
    readonly signal?: AbortSignal;
    /**
     * Ask the aggregator for its (unauthenticated) status hint and stop early on `expired` and `unknown`. Defaults to
     * `true`. `false` restores the behavior of SDK 3.0: nothing but the proof decides, the wait ends with a proof, an
     * error, or the signal.
     */
    readonly statusHints?: boolean;
    /**
     * Total time budget of the wait in milliseconds, counted from the call on a monotonic clock. With it the wait knows
     * how much time is left and sizes every long poll to fit (`min(window, left - margin)`), so it never asks for more than
     * the budget leaves; it applies together with `signal`, whichever ends first. Without `timeoutMs` and without `signal`
     * the budget is 15s. A caller `signal` alone says nothing about the time left (an `AbortSignal` is not a readable
     * deadline): the wait then asks for the preferred window and stops when the signal fires.
     */
    readonly timeoutMs?: number;
    /**
     * Where newer trust-base entries come from (usually the same `AggregatorClient`). With it, a freshly certified proof whose seal is of an epoch the
     * held history does not have yet (`NO_ENTRY_FOR_EPOCH`) does not fail the wait: the entries after the latest held one are fetched, authenticated
     * and appended (see {@link verifyWithTrustBaseUpdate}, same bounds, within this wait's budget), and the same proof is verified again. Needs the
     * trust base to be a `TrustBaseHistory`. Without it such a proof fails the wait as before.
     */
    readonly trustBaseSource?: ITrustBaseSource;
    /**
     * How long an `unknown` hint is tolerated, counted from the start of the wait, before the wait fails with
     * {@link InclusionProofUnknownError}. Defaults to two poll intervals; `0` fails at the first `unknown`. Ignored
     * without `statusHints`.
     */
    readonly unknownGraceMs?: number;
}
/**
 * Poll the aggregator until a valid inclusion proof for the given transaction
 * is available, or the abort signal fires.
 *
 * The returned promise always settles: once the signal has fired the wait
 * rejects, regardless of whether the deadline was reached while requesting,
 * while verifying, or while sleeping between polls.
 *
 * Unless `statusHints` is `false`, the wait asks the aggregator for its status hint. `pending` keeps waiting. The hint is
 * **unauthenticated**: it only decides when to stop waiting, it never makes a proof valid or invalid (a proof that is
 * present is verified exactly as before whatever the hint says), and `unknown`/`expired` is not a proof of absence. A
 * server that does not send a hint, or an unrecognized one, behaves as before. `unknown` is rechecked for a grace
 * period, because the wait normally starts right after submission and an HA instance that has not seen the request yet
 * answers `unknown`.
 *
 * @param {StateTransitionClient} client Client used to fetch inclusion proofs.
 * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
 * @param {PredicateVerifierService} predicateVerifier Verifier used to check the transaction predicate.
 * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
 * @param {ITransaction} transaction Transaction whose inclusion is being awaited.
 * @param {IWaitInclusionProofOptions} [options] Signal, interval and hint handling.
 * @returns {Promise<InclusionProof>} Verified inclusion proof.
 * @throws {SleepError} If the abort signal fires before a proof is available.
 * @throws {InclusionProofExpiredError} If the aggregator hints the request as expired (and has no proof): it was dropped
 *   before inclusion. Resubmittable.
 * @throws {InclusionProofUnknownError} If the aggregator keeps hinting the request as unknown (and has no proof) for
 *   longer than `unknownGraceMs` since the wait began. Resubmittable.
 * @throws {InclusionProofConflictError} If the proof served for the state id certifies another request than the
 *   transaction (a conflicting submission was queued first); the proof is not yet authenticated. Not resubmittable.
 */
export declare function waitInclusionProof(client: StateTransitionClient, trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, transaction: ITransaction, options?: IWaitInclusionProofOptions): Promise<InclusionProof>;
/**
 * @deprecated Positional form, kept (default budget 15 s, no status hints, they need the options form): pass
 *   `{ signal, intervalMs }` instead.
 * @param {StateTransitionClient} client Client used to fetch inclusion proofs.
 * @param {ITrustBaseAuthority} trustBase Held trust-base history (verifies each certificate against its own epoch's committee).
 * @param {PredicateVerifierService} predicateVerifier Verifier used to check the transaction predicate.
 * @param {UnicityCertificateVerifier} unicityCertificateVerifier Unicity certificate verifier.
 * @param {ITransaction} transaction Transaction whose inclusion is being awaited.
 * @param {AbortSignal} signal Abort signal that terminates polling. Defaults to a 15s timeout.
 * @param {number} interval Delay between polls in milliseconds. Defaults to 1000.
 * @returns {Promise<InclusionProof>} Verified inclusion proof.
 */
export declare function waitInclusionProof(client: StateTransitionClient, trustBase: ITrustBaseAuthority, predicateVerifier: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, transaction: ITransaction, signal?: AbortSignal, interval?: number): Promise<InclusionProof>;
export type { ILongPollOptions };
export { SleepError };
