/**
 * String dedent function, calculates distance which has to be removed from second line string
 * @param {TemplateStringsArray} strings - Template strings array
 * @param {unknown[]} data - Data to be inserted
 * @returns {string} - Dedented string
 */
export declare function dedent(strings: TemplateStringsArray, ...data: unknown[]): string;
