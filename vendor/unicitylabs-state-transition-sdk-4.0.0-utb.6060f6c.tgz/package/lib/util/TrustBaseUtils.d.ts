import { TrustBaseHistory } from '../api/bft/trustbase/TrustBaseHistory.js';
import { ITrustBaseSource } from '../api/ITrustBaseSource.js';
import { VerificationResult } from '../verification/VerificationResult.js';
/**
 * Bounds of a trust-base update. The defaults are shared with the Rust SDK: a fetch every 2 s at most, 5 fetches, 10 s overall, 64 entries per fetch.
 */
export interface ITrustBaseUpdateOptions {
    /** Fetches at most. Defaults to 5. */
    readonly attempts?: number;
    /** Pause after a fetch that brought nothing new, in milliseconds. Defaults to 2000. */
    readonly intervalMs?: number;
    /** Entries asked for per fetch, 1..64. Defaults to 64. */
    readonly maxEntries?: number;
    /** Caller cancellation; aborting it throws. */
    readonly signal?: AbortSignal;
    /** Overall budget in milliseconds; when it runs out the last result is returned, not thrown. Defaults to 10000. */
    readonly timeoutMs?: number;
}
/**
 * Fetch the entries after the latest held one (from held epoch + 1, at most `maxEntries`) and append them through the history's single append
 * path, which authenticates each entry from the one before it. Concurrent calls for one history share one fetch.
 *
 * @param {TrustBaseHistory} history Held history; appended to in place.
 * @param {ITrustBaseSource} source Untrusted source (e.g. the aggregator client).
 * @param {object} [options] Options.
 * @param {number} [options.maxEntries] Entries asked for, 1..64. Defaults to 64.
 * @param {AbortSignal} [options.signal] Cancellation.
 * @returns {Promise<number>} Entries appended; 0 when the source has nothing newer yet.
 * @throws {TrustBaseUpdateError} When the response is malformed, of another network, refused, or carries an entry that does not authenticate.
 */
export declare function fetchTrustBaseEntries(history: TrustBaseHistory, source: ITrustBaseSource, options?: {
    readonly maxEntries?: number;
    readonly signal?: AbortSignal;
}): Promise<number>;
/**
 * Verify, and when the verification reports "no entry for epoch e" (a certificate of an epoch newer than the latest held trust-base entry), fetch
 * the newer entries from `source`, append them (each authenticated from the one before) and verify again: the trust-base analogue of
 * {@link waitInclusionProof}.
 *
 * Every fetch asks for the entries after the latest held one. A fetch that brings nothing new (the source does not have epoch e yet) is followed by
 * a pause; one that appends entries but stops short of e (the per-fetch cap) is followed at once by the next. The loop ends with the first result
 * that is not "no entry for epoch", or after `attempts` fetches, or when `timeoutMs` runs out; it then returns the last result, which still names
 * the missing epoch, so the caller can retry later. Other results (`ok`, invalid, malformed) are returned at once and never retried. Held entries are
 * never replaced: a fetched entry that conflicts with one is refused.
 *
 * @param {Function} verify Verification against the history, e.g. `(trustBase) => token.verify(contextWith(trustBase))`.
 * @param {TrustBaseHistory} history Held history; appended to in place (persist it with `exportBundle`).
 * @param {ITrustBaseSource} source Untrusted source, e.g. the `AggregatorClient`.
 * @param {ITrustBaseUpdateOptions} [options] Bounds.
 * @returns {Promise<R>} The last verification result.
 * @throws {TrustBaseUpdateError} When the source misbehaves (see the reasons); entries appended before stay held.
 * @throws {SleepError} When the caller's `signal` aborts.
 */
export declare function verifyWithTrustBaseUpdate<R extends VerificationResult<unknown>>(verify: (trustBase: TrustBaseHistory) => Promise<R>, history: TrustBaseHistory, source: ITrustBaseSource, options?: ITrustBaseUpdateOptions): Promise<R>;
