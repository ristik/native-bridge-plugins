/**
 * Big-endian conversion between {@link bigint} values and byte arrays.
 */
export declare class BigintConverter {
    /**
     * Convert bytes to unsigned long
     * @param {Uint8Array} data byte array
     * @param {Number} offset read offset
     * @param {Number} length read length
     * @returns {bigint} long value
     */
    static decode(data: Uint8Array, offset?: number, length?: number): bigint;
    /**
     * Convert long to byte array.
     * @param {bigint} value long value
     * @param {number} [length] Optional fixed output length; the result is left-padded with zero bytes.
     * @returns {Uint8Array} Big-endian byte array, minimal or padded to `length`.
     * @throws {RangeError} If `value` does not fit in `length` bytes.
     */
    static encode(value: bigint, length?: number): Uint8Array;
}
