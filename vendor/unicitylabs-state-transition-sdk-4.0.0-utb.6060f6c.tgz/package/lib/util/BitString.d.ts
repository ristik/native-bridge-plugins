/**
 * Bit string backed by a {@link bigint} with a leading sentinel bit, so that
 * leading zero bits are preserved across conversions. Provides byte-order and
 * bit-order helpers used by sparse Merkle tree routing.
 */
export declare class BitString {
    /**
     * Represents a bit string as a bigint.
     */
    private readonly value;
    private constructor();
    /**
     * Create a BitString from raw bytes with no bit reordering.
     * Bigint bit 0 is the LSB of the last byte.
     *
     * @param {Uint8Array} data Input bytes.
     * @returns {BitString} New bit string.
     */
    static fromBytes(data: Uint8Array): BitString;
    /**
     * Create a BitString for spec-compliant big-endian tree routing, where bigint
     * bit `i` is the big-endian bit at depth `i` (depth 0 = `data[0] & 0x80`).
     *
     * @param {Uint8Array} data Input bytes.
     * @returns {BitString} New bit string.
     */
    static fromBytesBigEndian(data: Uint8Array): BitString;
    /**
     * Convert BitString to bigint by adding a leading byte 1 to input byte array.
     * This is to ensure that the bigint will retain the leading zero bits.
     *
     * @returns {bigint} Bigint representation of the bit string.
     */
    toBigInt(): bigint;
    /**
     * Convert bit string to Uint8Array.
     *
     * @returns {Uint8Array} Byte representation of the bit string.
     */
    toBytes(): Uint8Array;
    /**
     * Convert bit string to string.
     *
     * @returns {string} Binary string representation of the bit string.
     */
    toString(): string;
}
