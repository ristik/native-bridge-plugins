import { VerificationResult } from './VerificationResult.js';
/**
 * Exception thrown when a verification fails.
 */
export declare class VerificationError extends Error {
    readonly verificationResult: VerificationResult<unknown>;
    constructor(message: string, verificationResult: VerificationResult<unknown>);
}
