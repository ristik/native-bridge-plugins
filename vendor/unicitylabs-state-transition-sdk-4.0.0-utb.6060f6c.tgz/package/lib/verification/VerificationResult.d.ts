import { VerificationStatus } from './VerificationStatus.js';
/**
 * Outcome of one verification rule. Carries the rule name, a status of any
 * type `S`, an optional message, and child results from nested rules so that
 * a full verification trace can be rendered.
 *
 * @typeParam S Status type produced by the rule.
 */
export declare class VerificationResult<S> {
    readonly rule: string;
    readonly status: S;
    readonly message: string;
    readonly results: VerificationResult<unknown>[];
    constructor(rule: string, status: S, message?: string, results?: VerificationResult<unknown>[]);
    /**
     * Aggregate child results into a single {@link VerificationStatus} result: OK
     * when every child is OK, otherwise FAIL. The children are retained as the
     * verification trace.
     *
     * @param {string} rule Rule name for the aggregate result.
     * @param {VerificationResult<VerificationStatus>[]} results Child results to aggregate.
     * @param {string} [message] Optional message for the aggregate result.
     * @returns {VerificationResult<VerificationStatus>} Aggregated result.
     */
    static fromResults(rule: string, results: VerificationResult<VerificationStatus>[], message?: string): VerificationResult<VerificationStatus>;
    /**
     * @returns {string} String representation of the verification result.
     */
    toString(): string;
}
