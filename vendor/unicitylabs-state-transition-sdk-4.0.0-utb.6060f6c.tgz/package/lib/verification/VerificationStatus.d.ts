/**
 * Result code for verification.
 */
export declare enum VerificationStatus {
    OK = "OK",
    FAIL = "FAIL"
}
