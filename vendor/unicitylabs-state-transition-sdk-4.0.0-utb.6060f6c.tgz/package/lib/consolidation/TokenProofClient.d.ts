import { ConsolidationResult } from './ConsolidationResult.js';
import { ShardRouting } from './ShardRouting.js';
import { ShardId } from '../api/bft/ShardId.js';
import { ILongPollOptions } from '../api/ILongPollOptions.js';
import { Token } from '../transaction/Token.js';
import { IVerificationContext } from '../transaction/verification/IVerificationContext.js';
/**
 * Configuration of a {@link TokenProofClient}.
 */
export interface ITokenProofClientOptions {
    /** Maximum number of completed seal checks one operation remembers. Default 64. */
    readonly maxSealCacheEntries?: number;
    /** Trusted shard routing, configured once. Endpoints and credentials come from here only. */
    readonly routing: ShardRouting;
    /**
     * The existing verification context: its trust base is the anchored authority and its predicate, issuance and
     * certificate verification are what decide, as injected (custom signature verifiers, rules and caches included). A
     * stock verifier is shared through an operation scoped seal session whose misses its own quorum rule decides; a
     * customized verifier or rule verifies every proof by itself.
     */
    readonly verificationContext: IVerificationContext;
}
/**
 * Options of one {@link TokenProofClient.consolidate} call.
 */
export interface ITokenConsolidationOptions {
    /**
     * Diagnostics and special cases. Ordinary callers never need them: the master is chosen for you (the shard of the
     * newest original proof, which is the one that can cover the history).
     */
    readonly advanced?: {
        /** Master shard to use instead; it must take part in the token's outer history. */
        readonly master?: ShardId;
    };
    /**
     * Opt in to one long poll on the master shard's latest request (`true`, or `{ windowMs, marginMs }`); see
     * {@link IConsolidationOptions.masterLongPoll}. The other shards' exact-root requests never wait and the attempt is not
     * repeated.
     */
    readonly masterLongPoll?: boolean | ILongPollOptions;
    /** Upper bound on concurrent exact-root requests of the second wave. Default 4. */
    readonly maxParallel?: number;
    /**
     * Cancels the attempt and every outstanding request. The error is `cancelled` with `cause === signal.reason`; a
     * signal that aborts with a `TimeoutError` (`AbortSignal.timeout`) is reported as `timeout`.
     */
    readonly signal?: AbortSignal;
    /** Total deadline of the whole operation in milliseconds, 1..2^31-1. Default 10 000. */
    readonly timeoutMs?: number;
}
/**
 * Explicit preparation of a token for verification by an EVM contract (including internal bridge back) or a zkVM:
 * returns an ordinary token whose replaceable outer-history proofs all share one unicity seal, so that the target
 * verifier authenticates that seal once.
 *
 * Consolidation is optional and never automatic: nothing in the SDK calls this class. It needs no signing key, never
 * submits anything and never modifies its input. Proofs inside signed mint justifications, split/burn dependencies
 * and opaque predicate data are not replaceable and stay byte-for-byte unchanged, so a token with nested proofs can
 * still need other seals; the one-seal claim is about the outer history only. The token's size does not shrink.
 */
export declare class TokenProofClient {
    private readonly options;
    /**
     * @param {ITokenProofClientOptions} options Configuration. The network is the one of the verification context's
     *   trust base, the routing carries none.
     */
    constructor(options: ITokenProofClientOptions);
    private static distinctSeals;
    /**
     * Token bytes with the proofs of the outer history swapped. Every other byte (signed transactions, mint
     * justifications and their nested proofs, predicates) is copied verbatim; the result is only ever used by decoding
     * it into a token that is then fully verified.
     */
    private static replaceOuterProofs;
    /**
     * Rebuild the token's outer-history proofs under one master seal.
     *
     * One attempt makes one `latest` request to the master shard and one exact-root request to every other
     * participating shard (in parallel, bounded), under one total deadline. If the proofs already share a seal the
     * verified token is returned without any request.
     *
     * @param {Token} token Token to prepare, unchanged on every outcome.
     * @param {ITokenConsolidationOptions} [options] Deadline, cancellation and bounds.
     * @returns {Promise<ConsolidationResult>} `consolidated` with a fully verified immutable token, or `unavailable`
     *   with a stable reason when the service cannot provide the material.
     * @throws {ConsolidationError} Typed cancellation, deadline, transport, server, response or integrity failure.
     */
    consolidate(token: Token, options?: ITokenConsolidationOptions): Promise<ConsolidationResult>;
    /** Verification context of one operation: the caller's, with a stock verifier scoped to the operation and session. */
    private operationContext;
    private run;
}
