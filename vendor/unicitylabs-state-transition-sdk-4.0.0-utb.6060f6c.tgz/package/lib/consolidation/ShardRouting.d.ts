import { IShardConfigurationPin } from '../api/bft/PartitionView.js';
import { ShardId } from '../api/bft/ShardId.js';
import { IBatchAggregatorClient } from '../api/IBatchAggregatorClient.js';
import { StateId } from '../api/StateId.js';
/**
 * Aggregator of one shard, configured by the application. URLs and credentials live in the client the application
 * built; nothing a token or a response says can add or replace an endpoint.
 *
 * The client must have the batch capability: consolidation cannot work without it, and a routing is static trusted
 * configuration, so this is checked when the routing is built (types for TypeScript callers, a runtime check for
 * JavaScript ones), not when a token is consolidated.
 */
export interface IShardEndpoint {
    readonly client: IBatchAggregatorClient;
    readonly shard: ShardId;
}
/**
 * Trusted routing configuration of one partition. The network is the one of the verification context's trust base.
 */
export interface IShardRoutingOptions {
    /** Endpoints of the shards that may take part. Their ids must be shards of the scheme. */
    readonly endpoints: readonly IShardEndpoint[];
    /** Complete sharding scheme of the partition: empty for a single shard partition. */
    readonly scheme: readonly ShardId[];
    /**
     * Optional pinned configuration hash per shard, a stricter policy. Every shard must be in the scheme, at most once,
     * every hash 32 bytes; anything else is rejected when the routing is built, never silently ignored.
     */
    readonly shardConfigurationPins?: readonly IShardConfigurationPin[];
}
/**
 * Immutable routing from a state id to its shard endpoint, from the admitted shard prefix topology. No modulo rule,
 * no inference from timestamps. Invalid configurations (incomplete or overlapping scheme, endpoints without the batch
 * capability or outside the scheme, duplicates, malformed pins) are rejected at construction.
 */
export declare class ShardRouting {
    private readonly _order;
    private readonly _pins;
    private readonly _scheme;
    private readonly endpoints;
    /**
     * @param {IShardRoutingOptions} options Routing configuration.
     * @throws {ConsolidationError} `input` if the configuration is invalid.
     */
    constructor(options: IShardRoutingOptions);
    /**
     * @returns {ShardId[]} The shards of the scheme in canonical (left to right) order; one root shard if unsharded.
     */
    get order(): ShardId[];
    /**
     * @returns {bigint} The aggregation partition, {@link AGGREGATION_PARTITION_ID}: read-only and not configurable.
     */
    get partitionId(): bigint;
    /**
     * @returns {ShardId[]} Copy of the configured scheme.
     */
    get scheme(): ShardId[];
    /**
     * @returns {IShardConfigurationPin[]|undefined} Copies of the pinned configuration hashes, if configured.
     */
    get shardConfigurationPins(): IShardConfigurationPin[] | undefined;
    /**
     * Routing of a single shard partition served by one endpoint.
     *
     * @param {IBatchAggregatorClient} client Client of the shard aggregator.
     * @returns {ShardRouting} Routing.
     */
    static single(client: IBatchAggregatorClient): ShardRouting;
    /**
     * @param {StateId} stateId State id.
     * @returns {IShardEndpoint} Endpoint serving the state's shard.
     * @throws {ConsolidationError} `input` if no configured endpoint serves the state.
     */
    route(stateId: StateId): IShardEndpoint;
}
