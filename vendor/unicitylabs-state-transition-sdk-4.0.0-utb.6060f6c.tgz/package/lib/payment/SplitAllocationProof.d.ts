import { DataHash } from '../crypto/hash/DataHash.js';
import { SparseMerkleSumTreeRootNode } from '../smt/radixsum/SparseMerkleSumTreeRootNode.js';
/** Reconstructed RSMST root: digest and total sum. */
export interface ISplitAllocationRoot {
    readonly hash: DataHash;
    readonly sum: bigint;
}
/**
 * Split allocation inclusion proof for one output asset: the explicit-depth
 * inclusion proof of a radix sparse Merkle sum tree — a leaf-to-root sequence of
 * sibling entries `(depth, hash, sum)` with strictly decreasing depths. The asset
 * identifier, output identifier, leaf data, leaf amount and root hash are not
 * carried; the verifier supplies them. The empty proof is valid only when the
 * allocation tree holds a single output leaf.
 */
export declare class SplitAllocationProof {
    private readonly siblings;
    private constructor();
    /**
     * @returns {number} Number of sibling entries in the proof.
     */
    get length(): number;
    /**
     * Build a split allocation proof for the leaf with the given key by walking
     * the radix sum tree from the root to the leaf.
     *
     * @param {SparseMerkleSumTreeRootNode} root Root of the asset's radix sum tree.
     * @param {Uint8Array} key 32-byte output token identifier.
     * @returns {SplitAllocationProof} Inclusion proof for the key.
     * @throws {Error} If the key is not present in the tree.
     */
    static create(root: SparseMerkleSumTreeRootNode, key: Uint8Array): SplitAllocationProof;
    /**
     * Create SplitAllocationProof from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes (an array of sibling entries).
     * @returns {SplitAllocationProof} Decoded proof.
     * @throws {CborError} On too many entries, an out-of-range or non-decreasing depth, or a non-positive or non-minimal sum.
     */
    static fromCBOR(bytes: Uint8Array): SplitAllocationProof;
    /**
     * Reconstruct the root digest and sum for this proof by hashing from the leaf
     * upward.
     *
     * @param {Uint8Array} key 32-byte output token identifier.
     * @param {Uint8Array} data 32-byte output commitment.
     * @param {bigint} value Strictly positive output amount for the asset.
     * @returns {Promise<ISplitAllocationRoot>} Reconstructed root digest and sum.
     * @throws {Error} If the inputs or proof are structurally invalid.
     */
    calculateRoot(key: Uint8Array, data: Uint8Array, value: bigint): Promise<ISplitAllocationRoot>;
    /**
     * Convert SplitAllocationProof to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} String representation of the proof.
     */
    toString(): string;
    /**
     * Verify this proof by reconstructing the root from the leaf upward and
     * checking it against the expected root digest and target sum.
     *
     * @param {Uint8Array} key 32-byte output token identifier.
     * @param {Uint8Array} data 32-byte output commitment.
     * @param {bigint} value Strictly positive output amount for the asset.
     * @param {DataHash} expectedRootHash Expected RSMST root digest from the manifest.
     * @param {bigint} expectedSum Expected reconstructed root sum.
     * @returns {Promise<boolean>} True if the proof reconstructs to the root and target sum.
     */
    verify(key: Uint8Array, data: Uint8Array, value: bigint, expectedRootHash: DataHash, expectedSum: bigint): Promise<boolean>;
}
