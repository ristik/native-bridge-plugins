import { AssetId } from '../asset/AssetId.js';
/**
 * Thrown when a token split references an asset id that does not exist in
 * the source token's payment data.
 */
export declare class TokenAssetMissingError extends Error {
    constructor(assetId: AssetId);
}
