/**
 * Thrown when two split requests derive the same token id, which would
 * collide in the sum trees.
 */
export declare class DuplicateSplitTokenIdError extends Error {
    constructor(tokenId: string);
}
