/**
 * Thrown when a token split has a different number of assets than the
 * source token's payment data.
 */
export declare class TokenAssetCountMismatchError extends Error {
    constructor();
}
