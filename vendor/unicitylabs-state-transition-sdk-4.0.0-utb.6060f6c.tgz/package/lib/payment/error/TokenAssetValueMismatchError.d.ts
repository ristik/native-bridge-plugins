import { AssetId } from '../asset/AssetId.js';
/**
 * Thrown when a token split's asset sum tree root value does not match the
 * source token's recorded value for that asset.
 */
export declare class TokenAssetValueMismatchError extends Error {
    constructor(assetId: AssetId, value: bigint, splitValue: bigint);
}
