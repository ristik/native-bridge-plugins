/**
 * Thrown when a split output's payment data does not decode, with the decoder
 * passed to the split, to exactly the assets it declares.
 */
export declare class SplitPayloadMismatchError extends Error {
    constructor(reason: string, options?: {
        cause?: unknown;
    });
}
