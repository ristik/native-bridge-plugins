import { IPaymentData } from './IPaymentData.js';
import { ISplitOptions } from './ISplitOptions.js';
import { SplitToken } from './SplitToken.js';
import { SplitTokenRequest } from './SplitTokenRequest.js';
import { BurnPredicate } from '../predicate/builtin/BurnPredicate.js';
import { Token } from '../transaction/Token.js';
import { TransferTransaction } from '../transaction/TransferTransaction.js';
/**
 * Result of splitting a token.
 */
export interface ISplit {
    readonly burn: {
        readonly ownerPredicate: BurnPredicate;
        readonly transaction: TransferTransaction;
    };
    readonly tokens: SplitToken[];
}
/**
 * Token splitting. Burns the source token and prepares value-conserving output
 * mints, building one radix sparse Merkle sum tree per source asset so that, for
 * each asset, the outputs provably sum to the source amount.
 */
export declare class TokenSplit {
    /**
     * Split a token into new outputs.
     *
     * @param {Token} token Source token to split (the token being burned).
     * @param {(bytes: Uint8Array) => Promise<IPaymentData>} decodePaymentData Decoder for the source token's payment data.
     * @param {SplitTokenRequest[]} requests Per-output mint requests; each carries its own payment data, which must
     *   decode with `decodePaymentData` to exactly its declared assets.
     * @param {ISplitOptions} options Optional burn state mask and request deadline.
     * @returns {Promise<ISplit>} Burn transaction and split tokens ready to mint; each token carries frozen
     *   payment data whose `encode()` returns a copy of the committed bytes.
     * @throws {SplitPayloadMismatchError} If an output's payment data does not decode to its declared assets;
     *   no burn is built.
     */
    static split(token: Token, decodePaymentData: (bytes: Uint8Array) => Promise<IPaymentData>, requests: SplitTokenRequest[], options?: ISplitOptions): Promise<ISplit>;
}
