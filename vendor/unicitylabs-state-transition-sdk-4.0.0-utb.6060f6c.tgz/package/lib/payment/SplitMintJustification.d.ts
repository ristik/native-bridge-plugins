import { SplitAllocationProof } from './SplitAllocationProof.js';
import { EncodedPredicate } from '../predicate/EncodedPredicate.js';
import { Token } from '../transaction/Token.js';
import { TokenId } from '../transaction/TokenId.js';
import { TokenSalt } from '../transaction/TokenSalt.js';
/**
 * Split mint reason: CBOR semantic tag 39044 applied to the two-element array
 * `[burned source token, split allocation proofs]`, where the proofs appear in
 * canonical output-asset order, one per asset the minted output carries.
 */
export declare class SplitMintJustification {
    readonly token: Token;
    private readonly _proofs;
    static readonly CBOR_TAG = 39044n;
    private constructor();
    /**
     * @returns {SplitAllocationProof[]} Copy of the allocation proofs.
     */
    get proofs(): SplitAllocationProof[];
    /**
     * Calculate the sum-tree leaf data `d_j` for a split output: a commitment that binds
     * an allocation leaf to its output mint transaction. Every term is a CBOR byte string
     * except the network identifier, which is an unsigned integer. The mint reason is
     * deliberately excluded — it embeds the proofs, which are derived from this value.
     *
     * @param {Token} token Token which is going to be burnt; its identifier, network and token type are bound
     *   into the commitment (a split preserves the source network and token type, so the output's equal them).
     * @param {EncodedPredicate} recipient Output recipient predicate.
     * @param {TokenSalt} salt Output mint salt.
     * @param {TokenId} tokenId Output token identifier.
     * @param {Uint8Array} data Exact output auxiliary-payload byte string.
     * @returns {Promise<Uint8Array>} Raw 32-byte commitment digest.
     */
    static calculateLeafData(token: Token, recipient: EncodedPredicate, salt: TokenSalt, tokenId: TokenId, data: Uint8Array | null): Promise<Uint8Array>;
    /**
     * Create a SplitMintJustification.
     *
     * @param {Token} token Burned source token (including its certified burn transfer).
     * @param {SplitAllocationProof[]} proofs Allocation proofs in canonical output-asset order.
     * @returns {SplitMintJustification} New justification.
     * @throws {Error} If `proofs` is empty.
     */
    static create(token: Token, proofs: SplitAllocationProof[]): SplitMintJustification;
    /**
     * Create SplitMintJustification from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {Promise<SplitMintJustification>} Decoded justification.
     * @throws {CborError} On wrong tag.
     */
    static fromCBOR(bytes: Uint8Array): Promise<SplitMintJustification>;
    /**
     * Convert SplitMintJustification to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
}
