import { DataHash } from '../crypto/hash/DataHash.js';
/**
 * Split manifest: CBOR semantic tag 39046 applied directly to an array of
 * per-asset sum-tree root hashes, positionally aligned with the source token's
 * assets in canonical order. The certified burn transfer carries the manifest as
 * its auxiliary data, and the burn reason is the SHA-256 of its canonical encoding.
 *
 * Roots are exposed as {@link DataHash} instances, so the digest length is
 * enforced by the hash type. On the wire each root is encoded as its raw digest
 * bytes (no algorithm imprint); decoding reconstructs SHA-256 hashes.
 */
export declare class SplitManifest {
    private readonly _roots;
    static readonly CBOR_TAG = 39046n;
    private constructor();
    /**
     * @returns {DataHash[]} Copy of the per-asset RSMST root hashes.
     */
    get roots(): DataHash[];
    /**
     * Create a SplitManifest from per-asset root hashes.
     *
     * @param {DataHash[]} roots RSMST root hashes in canonical source-asset order.
     * @returns {SplitManifest} New manifest.
     * @throws {Error} If `roots` is empty.
     */
    static create(roots: DataHash[]): SplitManifest;
    /**
     * Create SplitManifest from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {SplitManifest} Decoded manifest.
     * @throws {CborError} On wrong tag or malformed roots.
     */
    static fromCBOR(bytes: Uint8Array): SplitManifest;
    /**
     * Convert SplitManifest to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
}
