import { IPaymentData } from './IPaymentData.js';
import { CertifiedMintTransaction } from '../transaction/CertifiedMintTransaction.js';
import type { Token } from '../transaction/Token.js';
import { IMintJustificationVerifier } from '../transaction/verification/IMintJustificationVerifier.js';
import { VerificationResult } from '../verification/VerificationResult.js';
import { VerificationStatus } from '../verification/VerificationStatus.js';
/**
 * Verifier for {@link SplitMintJustification} mint justifications. It reports the
 * burned source token for caller verification, binds the burn to the split
 * manifest, recomputes the output's leaf data, and verifies every output asset
 * against its allocation proof — requiring each asset's reconstructed total to
 * equal the source amount (value conservation).
 */
export declare class SplitMintJustificationVerifier implements IMintJustificationVerifier {
    private readonly decodePaymentData;
    constructor(decodePaymentData: (bytes: Uint8Array) => Promise<IPaymentData>);
    /**
     * @returns {bigint} CBOR tag this verifier handles.
     */
    get tag(): bigint;
    private static fail;
    /**
     * @inheritDoc
     */
    verify(transaction: CertifiedMintTransaction, nestedTokenCollector: (token: Token) => void): Promise<VerificationResult<VerificationStatus>>;
}
