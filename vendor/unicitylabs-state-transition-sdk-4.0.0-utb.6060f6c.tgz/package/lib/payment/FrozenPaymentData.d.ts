import { PaymentAssetCollection } from './asset/PaymentAssetCollection.js';
import { IPaymentData } from './IPaymentData.js';
/**
 * Immutable payment data whose encoding is a fixed byte string. Obtained by
 * {@link FrozenPaymentData.freeze}, which guarantees that the bytes decode, with the
 * caller's decoder, to exactly the assets held here.
 */
export declare class FrozenPaymentData implements IPaymentData {
    readonly assets: PaymentAssetCollection;
    private readonly _bytes;
    private constructor();
    /**
     * Encode `paymentData` once, copy the bytes, decode a copy with `decode` and require the
     * decoded assets to equal the declared assets. `paymentData` is not consulted again.
     *
     * @param {IPaymentData} paymentData Declared payment data.
     * @param {(bytes: Uint8Array) => Promise<IPaymentData>} decode Decoder the verifier will use.
     * @returns {Promise<FrozenPaymentData>} Frozen payload over the exact encoded bytes.
     * @throws {SplitPayloadMismatchError} If the bytes do not decode to the declared assets.
     */
    static freeze(paymentData: IPaymentData, decode: (bytes: Uint8Array) => Promise<IPaymentData>): Promise<FrozenPaymentData>;
    /**
     * @returns {Promise<Uint8Array>} Copy of the frozen encoded bytes.
     */
    encode(): Promise<Uint8Array>;
}
