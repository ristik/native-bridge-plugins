import { Asset } from './Asset.js';
import { AssetId } from './AssetId.js';
/**
 * Asset-id-keyed collection of {@link Asset} values used in a payment. Assets are
 * held in canonical asset-id order — the order the split protocol requires — so
 * {@link toArray} and {@link toCBOR} always produce that order.
 */
export declare class PaymentAssetCollection {
    private readonly _assets;
    private constructor();
    /**
     * Create a PaymentAssetCollection. Assets may be supplied in any order; they
     * are stored canonically.
     *
     * @param {...Asset} data Assets to include (1..256, distinct ids).
     * @returns {PaymentAssetCollection} New collection.
     * @throws {Error} If the count is out of range, or an asset id repeats.
     */
    static create(...data: Asset[]): PaymentAssetCollection;
    /**
     * Create PaymentAssetCollection from CBOR bytes. The encoded assets MUST be in
     * strict canonical asset-id order with no duplicates.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {PaymentAssetCollection} Decoded collection.
     * @throws {CborError} If the assets are not in strict canonical asset-id order.
     */
    static fromCBOR(bytes: Uint8Array): PaymentAssetCollection;
    /**
     * Compare two assets by their asset id in canonical order: ascending unsigned
     * lexicographic order of the raw id bytes, a shorter id ordered before a longer
     * one that it is a prefix of.
     *
     * @param {Asset} a First asset.
     * @param {Asset} b Second asset.
     * @returns {number} Negative if `a < b`, positive if `a > b`, zero if equal.
     */
    private static compareAssets;
    /**
     * Build a collection from assets already in canonical asset-id order, validating
     * the count and rejecting duplicates without re-sorting.
     *
     * @param {Asset[]} assets Assets in canonical asset-id order.
     * @returns {PaymentAssetCollection} New collection.
     * @throws {Error} If the count is out of range, or an asset id repeats.
     */
    private static fromArray;
    /**
     * Look up the asset with the given id.
     *
     * @param {AssetId} id Asset id.
     * @returns {Asset|null} Matching asset, or `null`.
     */
    get(id: AssetId): Asset | null;
    /**
     * @returns {number} Number of assets in this collection.
     */
    size(): number;
    /**
     * @returns {Asset[]} Assets in canonical asset-id order.
     */
    toArray(): Asset[];
    /**
     * Convert PaymentAssetCollection to CBOR bytes (assets in canonical order).
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
}
