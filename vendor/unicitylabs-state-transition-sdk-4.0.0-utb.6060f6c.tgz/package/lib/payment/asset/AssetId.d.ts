import { BitString } from '../../util/BitString.js';
/** Identifier for a asset. */
export declare class AssetId {
    private readonly _bytes;
    static readonly MAX_LENGTH = 128;
    static readonly MIN_LENGTH = 1;
    constructor(_bytes: Uint8Array);
    /**
     * @returns {Uint8Array} Copy of the asset id bytes.
     */
    get bytes(): Uint8Array;
    /**
     * Create AssetId from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {AssetId} Decoded asset id.
     */
    static fromCBOR(bytes: Uint8Array): AssetId;
    /**
     * Convert the AssetId to a bit-string representation.
     *
     * @returns {BitString} Bit-string view of the asset id.
     */
    toBitString(): BitString;
    /**
     * Convert AssetId to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} Hex string representation of the asset id.
     */
    toString(): string;
}
