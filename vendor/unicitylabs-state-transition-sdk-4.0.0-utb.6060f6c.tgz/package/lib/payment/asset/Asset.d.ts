import { AssetId } from './AssetId.js';
/**
 * Asset id paired with a strictly positive value in the range `[1, 2^256)`.
 */
export declare class Asset {
    readonly id: AssetId;
    private readonly _value;
    constructor(id: AssetId, _value: bigint);
    /**
     * @returns {bigint} Value held by this asset.
     */
    get value(): bigint;
    /**
     * Create Asset from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {Asset} Decoded asset.
     */
    static fromCBOR(bytes: Uint8Array): Asset;
    /**
     * Convert Asset to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
}
