import { TokenId } from '../transaction/TokenId.js';
import { SigningService } from './secp256k1/SigningService.js';
/**
 * Derives a deterministic {@link SigningService} for minting a token from the
 * token's {@link TokenId} and a fixed universal minter secret. The resulting
 * key is reproducible by anyone holding the same token id.
 */
export declare class MintSigningService {
    private static readonly MINTER_SECRET;
    /**
     * Create signing service for minting operations.
     *
     * @param {TokenId} tokenId Token identifier.
     * @returns {Promise<SigningService>} Signing service derived from the token id.
     */
    static create(tokenId: TokenId): Promise<SigningService>;
}
