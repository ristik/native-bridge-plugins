import { DataHash } from '../hash/DataHash.js';
import { ISigningService } from '../ISigningService.js';
import { Signature } from './Signature.js';
/**
 * Default secp256k1 signing service. Wraps a 32-byte private key and exposes
 * the matching compressed public key, plus helpers for sign/verify.
 *
 * Verification is delegated to {@link Secp256k1SignatureVerifier}: signing
 * depends on verification, never the reverse.
 *
 * @implements {ISigningService}
 */
export declare class SigningService implements ISigningService<Signature> {
    private readonly privateKey;
    /** Stateless, so one shared instance serves every caller. */
    private static readonly SIGNATURE_VERIFIER;
    private readonly _publicKey;
    constructor(privateKey: Uint8Array);
    /**
     * @returns {string} Algorithm name (`secp256k1`).
     */
    get algorithm(): string;
    /**
     * @returns {Uint8Array} Copy of the compressed public key.
     */
    get publicKey(): Uint8Array;
    /**
     * Generate a signing service with a fresh random private key.
     *
     * @returns {SigningService} New signing service.
     */
    static generate(): SigningService;
    /**
     * Generate a fresh random secp256k1 private key.
     *
     * @returns {Uint8Array} 32-byte private key.
     */
    static generatePrivateKey(): Uint8Array;
    /**
     * Check whether the given bytes form a valid compressed secp256k1 public key.
     *
     * @param {Uint8Array} publicKey Compressed public key bytes.
     * @returns {boolean} True if valid.
     */
    static isPublicKeyValid(publicKey: Uint8Array): boolean;
    /**
     * Verify secp256k1 signature against the given public key.
     *
     * @param {DataHash} hash Signed hash.
     * @param {Uint8Array} signature Compact signature bytes.
     * @param {Uint8Array} publicKey Compressed public key.
     * @returns {Promise<boolean>} True if the signature verifies.
     */
    static verify(hash: DataHash, signature: Uint8Array, publicKey: Uint8Array): Promise<boolean>;
    /**
     * Verify a recoverable signature against an expected public key.
     *
     * Unlike {@link verify}, this binds the signature's recovery byte: the
     * public key is recovered from the signature and must equal `publicKey`,
     * so a tampered recovery byte fails verification.
     *
     * @param {DataHash} hash Signed hash.
     * @param {Signature} signature Recoverable signature.
     * @param {Uint8Array} publicKey Expected compressed public key.
     * @returns {Promise<boolean>} True if the signature verifies and the
     *   recovered public key matches `publicKey`.
     */
    static verifyWithPublicKey(hash: DataHash, signature: Signature, publicKey: Uint8Array): Promise<boolean>;
    /**
     * Sign a hash with this service's private key.
     *
     * @param {DataHash} hash Hash to sign.
     * @returns {Promise<Signature>} Recoverable signature.
     */
    sign(hash: DataHash): Promise<Signature>;
    /**
     * Verify a signature against this service's public key.
     *
     * @param {DataHash} hash Signed hash.
     * @param {Signature} signature Recoverable signature.
     * @returns {Promise<boolean>} True if the signature verifies.
     */
    verify(hash: DataHash, signature: Signature): Promise<boolean>;
}
