import { ISignature } from '../ISignature.js';
/**
 * secp256k1 recoverable signature: 64 bytes of compact `(r, s)` plus a
 * single recovery byte used to recover the signer's public key.
 *
 * @throws {RangeError} On construction, if `recovery` is not an integer in 0..3.
 */
export declare class Signature implements ISignature {
    private readonly _bytes;
    readonly recovery: number;
    readonly algorithm: string;
    constructor(_bytes: Uint8Array, recovery: number);
    /**
     * @returns {Uint8Array} Copy of the 64-byte signature.
     */
    get bytes(): Uint8Array;
    /**
     * Create Signature from its 65-byte encoding.
     *
     * @param {Uint8Array} bytes 64 signature bytes followed by recovery byte.
     * @returns {Signature} Decoded signature.
     * @throws {Error} If the input is not 65 bytes long or the recovery id is out of range (0–3).
     */
    static decode(bytes: Uint8Array): Signature;
    /**
     * Create Signature from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {Signature} Decoded signature.
     */
    static fromCBOR(bytes: Uint8Array): Signature;
    /**
     * Create Signature from JSON.
     *
     * @param {string} data Hex string of the encoded signature.
     * @returns {Signature} Decoded signature.
     */
    static fromJSON(data: string): Signature;
    /**
     * @returns {Uint8Array} 65-byte concatenation of signature bytes and recovery byte.
     */
    encode(): Uint8Array;
    /**
     * Convert Signature to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * Convert Signature to JSON.
     *
     * @returns {string} Hex string of the encoded signature.
     */
    toJSON(): string;
    /**
     * @returns {string} Hex string of the encoded signature.
     */
    toString(): string;
}
