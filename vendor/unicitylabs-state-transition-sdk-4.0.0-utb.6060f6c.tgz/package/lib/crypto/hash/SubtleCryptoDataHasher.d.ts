import { DataHash } from './DataHash.js';
import { HashAlgorithm } from './HashAlgorithm.js';
import { IDataHasher } from './IDataHasher.js';
export declare const Algorithm: {
    [HashAlgorithm.RIPEMD160.id]: null;
    [HashAlgorithm.SHA224.id]: null;
    [HashAlgorithm.SHA256.id]: string;
    [HashAlgorithm.SHA384.id]: string;
    [HashAlgorithm.SHA512.id]: string;
};
/**
 * Does hashing with asynchronous way
 */
export declare class SubtleCryptoDataHasher implements IDataHasher {
    readonly algorithm: HashAlgorithm;
    private _data;
    constructor(algorithm: HashAlgorithm);
    /**
     * @inheritDoc
     */
    digest(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    update(data: Uint8Array): this;
}
