/**
 * Hashing error
 */
export declare class HashError extends Error {
    constructor(message: string);
}
