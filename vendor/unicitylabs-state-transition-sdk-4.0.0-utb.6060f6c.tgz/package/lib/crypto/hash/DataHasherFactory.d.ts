import { HashAlgorithm } from './HashAlgorithm.js';
import { IDataHasher } from './IDataHasher.js';
import { IDataHasherFactory } from './IDataHasherFactory.js';
/**
 * Generic factory that produces fresh {@link IDataHasher} instances of type
 * `T` for a fixed {@link HashAlgorithm}. Lets callers choose the hasher
 * implementation (Node, Web Crypto, noble) without coupling to it.
 *
 * @typeParam T Concrete hasher type produced by this factory.
 */
export declare class DataHasherFactory<T extends IDataHasher> implements IDataHasherFactory<T> {
    readonly algorithm: HashAlgorithm;
    private readonly _hasherConstructor;
    constructor(algorithm: HashAlgorithm, _hasherConstructor: new (algorithm: HashAlgorithm) => T);
    /**
     * Create a new hasher instance configured with {@link algorithm}.
     *
     * @returns {T} Fresh hasher instance.
     */
    create(): T;
}
