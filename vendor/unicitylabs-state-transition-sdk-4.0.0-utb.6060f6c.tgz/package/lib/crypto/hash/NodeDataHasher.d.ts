import { DataHash } from './DataHash.js';
import { HashAlgorithm } from './HashAlgorithm.js';
import { IDataHasher } from './IDataHasher.js';
export declare const Algorithm: {
    [HashAlgorithm.RIPEMD160.id]: string;
    [HashAlgorithm.SHA224.id]: string;
    [HashAlgorithm.SHA256.id]: string;
    [HashAlgorithm.SHA384.id]: string;
    [HashAlgorithm.SHA512.id]: string;
};
/**
 * {@link IDataHasher} implementation backed by Node's built-in `crypto` module.
 * Suitable for server-side code; use {@link SubtleCryptoDataHasher} in the
 * browser.
 */
export declare class NodeDataHasher implements IDataHasher {
    readonly algorithm: HashAlgorithm;
    private _hasher;
    constructor(algorithm: HashAlgorithm);
    /**
     * @inheritDoc
     */
    digest(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    update(data: Uint8Array): this;
}
