import { HashAlgorithm } from './HashAlgorithm.js';
/**
 * Immutable hash value paired with the {@link HashAlgorithm} that produced
 * it. Carries both the raw `data` bytes and a 2-byte-prefixed `imprint`
 * encoding suitable for storage and comparison across algorithms.
 */
export declare class DataHash {
    readonly algorithm: HashAlgorithm;
    private readonly _data;
    private readonly _imprint;
    constructor(algorithm: HashAlgorithm, _data: Uint8Array);
    /**
     * @returns {Uint8Array} Copy of the raw hash bytes.
     */
    get data(): Uint8Array;
    /**
     * Returns the imprint of the hash, which includes the algorithm identifier and the data.
     * The first two bytes represent the algorithm, followed by the data bytes.
     * NB! Do not use this for signing, use `data` instead.
     *
     * @returns {Uint8Array} Copy of the imprint bytes.
     */
    get imprint(): Uint8Array;
    /**
     * Reconstruct a DataHash from its imprint form (2-byte algorithm id
     * followed by the hash bytes).
     *
     * @param {Uint8Array} imprint Imprint bytes; must be at least 3 bytes long.
     * @returns {DataHash} Decoded hash.
     * @throws {HashError} If the imprint is too short.
     */
    static fromImprint(imprint: Uint8Array): DataHash;
    /**
     * Equality check against another hash, comparing imprints so algorithm
     * mismatches are detected.
     *
     * @param {DataHash} hash Other hash, or `undefined`.
     * @returns {boolean} True if the hashes are equal.
     */
    equals(hash?: DataHash): boolean;
    /**
     * @returns {string} `[algorithm]hex` representation of the hash.
     */
    toString(): string;
}
