/**
 * Enumeration of supported hash algorithms. Each instance carries its
 * protocol id, human-readable name, and output length in bytes.
 */
export declare class HashAlgorithm {
    readonly id: number;
    readonly name: string;
    readonly length: number;
    static readonly RIPEMD160: HashAlgorithm;
    static readonly SHA224: HashAlgorithm;
    static readonly SHA256: HashAlgorithm;
    static readonly SHA384: HashAlgorithm;
    static readonly SHA512: HashAlgorithm;
    private constructor();
    /**
     * Look up the algorithm by its protocol id.
     *
     * @param {number} id Numeric algorithm id.
     * @returns {HashAlgorithm} Matching algorithm.
     * @throws {HashError} If no algorithm with the given id is registered.
     */
    static fromId(id: number): HashAlgorithm;
    /**
     * @returns {string} Human-readable name of the algorithm (e.g. `SHA-256`).
     */
    toString(): string;
}
