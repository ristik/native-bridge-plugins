import { DataHash } from './DataHash.js';
import { HashAlgorithm } from './HashAlgorithm.js';
import { IDataHasher } from './IDataHasher.js';
export declare const Algorithm: {
    [HashAlgorithm.RIPEMD160.id]: {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
    } & import("@noble/hashes/utils.js").HashInfo & {
        (msg: import("@noble/hashes/utils.js").TArg<Uint8Array>): import("@noble/hashes/utils.js").TRet<Uint8Array>;
        create(): import("@noble/hashes/utils.js").Hash<any>;
    } & ((msg: import("@noble/hashes/utils.js").TArg<import("@noble/hashes/utils.js").TArg<Uint8Array<ArrayBufferLike>>>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
        oid?: import("@noble/hashes/utils.js").TRet<Uint8Array> | undefined;
        create: () => import("@noble/hashes/utils.js").Hash<any>;
    };
    [HashAlgorithm.SHA224.id]: {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
    } & import("@noble/hashes/utils.js").HashInfo & {
        (msg: import("@noble/hashes/utils.js").TArg<Uint8Array>): import("@noble/hashes/utils.js").TRet<Uint8Array>;
        create(): import("@noble/hashes/sha2.js")._SHA224;
    } & ((msg: import("@noble/hashes/utils.js").TArg<import("@noble/hashes/utils.js").TArg<Uint8Array<ArrayBufferLike>>>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
        oid?: import("@noble/hashes/utils.js").TRet<Uint8Array> | undefined;
        create: () => import("@noble/hashes/sha2.js")._SHA224;
    };
    [HashAlgorithm.SHA256.id]: {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
    } & import("@noble/hashes/utils.js").HashInfo & {
        (msg: import("@noble/hashes/utils.js").TArg<Uint8Array>): import("@noble/hashes/utils.js").TRet<Uint8Array>;
        create(): import("@noble/hashes/sha2.js")._SHA256;
    } & ((msg: import("@noble/hashes/utils.js").TArg<import("@noble/hashes/utils.js").TArg<Uint8Array<ArrayBufferLike>>>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
        oid?: import("@noble/hashes/utils.js").TRet<Uint8Array> | undefined;
        create: () => import("@noble/hashes/sha2.js")._SHA256;
    };
    [HashAlgorithm.SHA384.id]: {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
    } & import("@noble/hashes/utils.js").HashInfo & {
        (msg: import("@noble/hashes/utils.js").TArg<Uint8Array>): import("@noble/hashes/utils.js").TRet<Uint8Array>;
        create(): import("@noble/hashes/sha2.js")._SHA384;
    } & ((msg: import("@noble/hashes/utils.js").TArg<import("@noble/hashes/utils.js").TArg<Uint8Array<ArrayBufferLike>>>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
        oid?: import("@noble/hashes/utils.js").TRet<Uint8Array> | undefined;
        create: () => import("@noble/hashes/sha2.js")._SHA384;
    };
    [HashAlgorithm.SHA512.id]: {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
    } & import("@noble/hashes/utils.js").HashInfo & {
        (msg: import("@noble/hashes/utils.js").TArg<Uint8Array>): import("@noble/hashes/utils.js").TRet<Uint8Array>;
        create(): import("@noble/hashes/sha2.js")._SHA512;
    } & ((msg: import("@noble/hashes/utils.js").TArg<import("@noble/hashes/utils.js").TArg<Uint8Array<ArrayBufferLike>>>) => Uint8Array<ArrayBufferLike> & Uint8Array<ArrayBuffer>) & {
        outputLen: number;
        blockLen: number;
        canXOF: boolean;
        oid?: import("@noble/hashes/utils.js").TRet<Uint8Array> | undefined;
        create: () => import("@noble/hashes/sha2.js")._SHA512;
    };
};
/**
 * Provides synchronous hashing functions
 */
export declare class DataHasher implements IDataHasher {
    readonly algorithm: HashAlgorithm;
    private _messageDigest;
    constructor(algorithm: HashAlgorithm);
    /**
     * @inheritDoc
     */
    digest(): Promise<DataHash>;
    /**
     * @inheritDoc
     */
    update(data: Uint8Array): this;
}
