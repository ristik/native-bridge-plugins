/**
 * Identifies which predicate execution environment a predicate belongs to.
 * Each engine has its own verifier registry.
 */
export declare enum PredicateEngine {
    BUILT_IN = 1
}
