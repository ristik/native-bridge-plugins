import { IPredicateVerifier } from './IPredicateVerifier.js';
import { DataHash } from '../../crypto/hash/DataHash.js';
import { VerificationResult } from '../../verification/VerificationResult.js';
import { VerificationStatus } from '../../verification/VerificationStatus.js';
import { EncodedPredicate } from '../EncodedPredicate.js';
/**
 * Registry that dispatches predicate verification to the right
 * {@link IPredicateVerifier} based on the predicate's engine.
 */
export declare class PredicateVerifierService {
    private readonly verifiers;
    private constructor();
    /**
     * Create verifier service with default verifiers.
     *
     * @returns {PredicateVerifierService} Service with the default verifiers registered.
     */
    static create(): PredicateVerifierService;
    /**
     * Register a verifier for its declared engine.
     *
     * @param {IPredicateVerifier} verifier Verifier to register.
     * @returns {PredicateVerifierService} This service for chaining.
     * @throws {Error} If a verifier is already registered for the engine.
     */
    addVerifier(verifier: IPredicateVerifier): this;
    /**
     * Verify given predicate with registered predicate verifiers.
     *
     * @param {EncodedPredicate} predicate Predicate being unlocked.
     * @param {bigint} referenceTime Reference time the transition was validated under, in Unix seconds.
     * @param {DataHash} sourceStateHash Hash of the state being spent.
     * @param {DataHash} transactionHash Hash of the spending transaction.
     * @param {Uint8Array} unlockScript Witness bytes for the predicate.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     * @throws {Error} If no verifier is registered for the predicate's engine.
     */
    verify(predicate: EncodedPredicate, referenceTime: bigint, sourceStateHash: DataHash, transactionHash: DataHash, unlockScript: Uint8Array): Promise<VerificationResult<VerificationStatus>>;
}
