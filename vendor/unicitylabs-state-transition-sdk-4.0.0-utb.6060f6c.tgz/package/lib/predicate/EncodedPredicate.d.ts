import { IPredicate } from './IPredicate.js';
import { PredicateEngine } from './PredicateEngine.js';
/**
 * Wire-form predicate: holds the engine id and opaque code/parameter bytes
 * without re-decoding them. Used wherever predicates are stored or
 * transmitted as CBOR.
 */
export declare class EncodedPredicate implements IPredicate {
    readonly engine: PredicateEngine;
    private readonly _code;
    private readonly _params;
    static readonly CBOR_TAG = 39032n;
    private constructor();
    /**
     * Null-safe structural equality on engine, code, and parameters.
     *
     * @param {EncodedPredicate|null|undefined} a First predicate.
     * @param {EncodedPredicate|null|undefined} b Second predicate.
     * @returns {boolean} True if both are nullish, or if engines and bytes match.
     */
    static equals(a: EncodedPredicate | null | undefined, b: EncodedPredicate | null | undefined): boolean;
    /**
     * Create EncodedPredicate from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {EncodedPredicate} Decoded predicate.
     * @throws {CborError} On wrong tag or unknown engine.
     */
    static fromCBOR(bytes: Uint8Array): EncodedPredicate;
    /**
     * Wrap any {@link IPredicate} into its encoded form.
     *
     * @param {IPredicate} predicate Predicate to wrap.
     * @returns {EncodedPredicate} Encoded copy of the predicate.
     */
    static fromPredicate(predicate: IPredicate): EncodedPredicate;
    /**
     * @inheritDoc
     */
    encodeCode(): Uint8Array;
    /**
     * @inheritDoc
     */
    encodeParameters(): Uint8Array;
    /**
     * Convert EncodedPredicate to CBOR bytes.
     *
     * @returns {Uint8Array} Tagged CBOR encoding of this predicate.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} String representation of the predicate.
     */
    toString(): string;
}
