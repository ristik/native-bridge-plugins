import { DataHash } from '../../crypto/hash/DataHash.js';
import { VerificationResult } from '../../verification/VerificationResult.js';
import { VerificationStatus } from '../../verification/VerificationStatus.js';
import { EncodedPredicate } from '../EncodedPredicate.js';
import { PredicateEngine } from '../PredicateEngine.js';
import { IPredicateVerifier } from '../verification/IPredicateVerifier.js';
import { IBuiltInPredicateVerifier } from './verification/IBuiltInPredicateVerifier.js';
/**
 * Default {@link IPredicateVerifier} for the built-in engine. Uses
 * {@link IBuiltInPredicateVerifier} by the predicate's type id to verify it.
 */
export declare class DefaultBuiltInPredicateVerifier implements IPredicateVerifier {
    readonly engine: PredicateEngine;
    private readonly verifiers;
    constructor(verifiers: IBuiltInPredicateVerifier[]);
    /**
     * Create a verifier preloaded with the default built-in predicate verifiers,
     * wired to secp256k1. To use a different signature verifier, compose the
     * registry directly:
     * `new DefaultBuiltInPredicateVerifier([new SignaturePredicateVerifier(myVerifier)])`.
     *
     * @returns {DefaultBuiltInPredicateVerifier} New verifier.
     */
    static create(): DefaultBuiltInPredicateVerifier;
    /**
     * @inheritDoc
     */
    verify(predicate: EncodedPredicate, referenceTime: bigint, sourceStateHash: DataHash, transactionHash: DataHash, unlockScript: Uint8Array): Promise<VerificationResult<VerificationStatus>>;
}
