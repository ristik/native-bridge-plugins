import { SigningService } from '../../crypto/secp256k1/SigningService.js';
import { PredicateEngine } from '../PredicateEngine.js';
import { BuiltInPredicateType } from './BuiltInPredicateType.js';
import { IBuiltInPredicate } from './IBuiltInPredicate.js';
import { EncodedPredicate } from '../EncodedPredicate.js';
/**
 * Built-in predicate that locks a state to a single secp256k1 public key.
 * Spending requires a {@link SignaturePredicateUnlockScript} signed by the
 * matching private key.
 */
export declare class SignaturePredicate implements IBuiltInPredicate {
    private readonly _publicKey;
    private constructor();
    /**
     * @returns {PredicateEngine} Built-in predicate engine.
     */
    get engine(): PredicateEngine;
    /**
     * @returns {Uint8Array} Copy of the compressed public key.
     */
    get publicKey(): Uint8Array;
    /**
     * @returns {BuiltInPredicateType} Signature predicate type id.
     */
    get type(): BuiltInPredicateType;
    /**
     * Create a SignaturePredicate from a compressed secp256k1 public key.
     *
     * @param {Uint8Array} publicKey Compressed public key bytes.
     * @returns {SignaturePredicate} New predicate.
     * @throws {Error} If `publicKey` is not a valid compressed point.
     */
    static create(publicKey: Uint8Array): SignaturePredicate;
    /**
     * Decode a SignaturePredicate from an EncodedPredicate.
     *
     * @param {EncodedPredicate} predicate Encoded predicate.
     * @returns {SignaturePredicate} Decoded predicate.
     * @throws {Error} If the engine or type does not match.
     */
    static fromPredicate(predicate: EncodedPredicate): SignaturePredicate;
    /**
     * Create a SignaturePredicate from the public key of a SigningService.
     *
     * @param {SigningService} signingService Service whose public key is used.
     * @returns {SignaturePredicate} New predicate.
     */
    static fromSigningService(signingService: SigningService): SignaturePredicate;
    /**
     * @inheritDoc
     */
    encodeCode(): Uint8Array;
    /**
     * @inheritDoc
     */
    encodeParameters(): Uint8Array;
    /**
     * @returns {string} String representation of the predicate.
     */
    toString(): string;
}
