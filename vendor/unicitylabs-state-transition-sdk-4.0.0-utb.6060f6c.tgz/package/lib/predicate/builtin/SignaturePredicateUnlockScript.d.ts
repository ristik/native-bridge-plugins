import { Signature } from '../../crypto/secp256k1/Signature.js';
import { SigningService } from '../../crypto/secp256k1/SigningService.js';
import { ITransaction } from '../../transaction/ITransaction.js';
import { IUnlockScript } from '../IUnlockScript.js';
/**
 * Unlock script for {@link SignaturePredicate}: a secp256k1 signature over
 * the (sourceStateHash, transactionHash) pair.
 */
export declare class SignaturePredicateUnlockScript implements IUnlockScript {
    readonly signature: Signature;
    private constructor();
    /**
     * Sign the transaction's source-state and transaction hashes to produce
     * an unlock script.
     *
     * @param {ITransaction} transaction Transaction being unlocked.
     * @param {SigningService} signingService Service holding the private key.
     * @returns {Promise<SignaturePredicateUnlockScript>} Signed unlock script.
     */
    static create(transaction: ITransaction, signingService: SigningService): Promise<SignaturePredicateUnlockScript>;
    /**
     * Decode an unlock script from its signature encoding.
     *
     * @param {Uint8Array} bytes Encoded signature bytes.
     * @returns {SignaturePredicateUnlockScript} Decoded unlock script.
     */
    static decode(bytes: Uint8Array): SignaturePredicateUnlockScript;
    /**
     * @inheritDoc
     */
    encode(): Uint8Array;
}
