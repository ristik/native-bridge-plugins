import { DataHash } from '../../../crypto/hash/DataHash.js';
import { ISignatureVerifier } from '../../../crypto/ISignatureVerifier.js';
import { Signature } from '../../../crypto/secp256k1/Signature.js';
import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import { EncodedPredicate } from '../../EncodedPredicate.js';
import { IBuiltInPredicateVerifier } from './IBuiltInPredicateVerifier.js';
import { BuiltInPredicateType } from '../BuiltInPredicateType.js';
/**
 * Verifier for {@link SignaturePredicate}: recomputes the
 * (sourceStateHash, transactionHash) digest and checks the signature in the
 * unlock script against the predicate's public key.
 */
export declare class SignaturePredicateVerifier implements IBuiltInPredicateVerifier {
    private readonly signatureVerifier;
    readonly type = BuiltInPredicateType.Signature;
    /**
     * @param {ISignatureVerifier<Signature>} signatureVerifier Verifier for unlock-script signatures.
     */
    constructor(signatureVerifier: ISignatureVerifier<Signature>);
    /**
     * @inheritDoc
     */
    verify(encodedPredicate: EncodedPredicate, _referenceTime: bigint, sourceStateHash: DataHash, transactionHash: DataHash, unlockScriptBytes: Uint8Array): Promise<VerificationResult<VerificationStatus>>;
}
