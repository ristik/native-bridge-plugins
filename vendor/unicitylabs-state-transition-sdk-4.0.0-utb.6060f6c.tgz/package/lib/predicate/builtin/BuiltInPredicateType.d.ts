/**
 * Predicate type ids for the built-in predicate engine.
 */
export declare enum BuiltInPredicateType {
    Signature = 1,
    Burn = 2
}
