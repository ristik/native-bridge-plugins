import { BuiltInPredicateType } from './BuiltInPredicateType.js';
import { PredicateEngine } from '../PredicateEngine.js';
import { IBuiltInPredicate } from './IBuiltInPredicate.js';
import { EncodedPredicate } from '../EncodedPredicate.js';
/**
 * Built-in predicate that permanently locks a state. The `reason` payload
 * records why the token was burned and is never spendable.
 */
export declare class BurnPredicate implements IBuiltInPredicate {
    private readonly _reason;
    private constructor();
    /**
     * @returns {PredicateEngine} Built-in predicate engine.
     */
    get engine(): PredicateEngine;
    /**
     * @returns {Uint8Array} Copy of the burn reason bytes.
     */
    get reason(): Uint8Array;
    /**
     * @returns {BuiltInPredicateType} Burn predicate type id.
     */
    get type(): BuiltInPredicateType;
    /**
     * Create a BurnPredicate with the given reason payload.
     *
     * @param {Uint8Array} reason Reason bytes recorded with the burn.
     * @returns {BurnPredicate} New predicate.
     */
    static create(reason: Uint8Array): BurnPredicate;
    /**
     * Decode a BurnPredicate from an EncodedPredicate.
     *
     * @param {EncodedPredicate} predicate Encoded predicate.
     * @returns {BurnPredicate} Decoded predicate.
     * @throws {Error} If the engine or type does not match.
     */
    static fromPredicate(predicate: EncodedPredicate): BurnPredicate;
    /**
     * @inheritDoc
     */
    encodeCode(): Uint8Array;
    /**
     * @inheritDoc
     */
    encodeParameters(): Uint8Array;
    /**
     * @returns {string} String representation of the predicate.
     */
    toString(): string;
}
