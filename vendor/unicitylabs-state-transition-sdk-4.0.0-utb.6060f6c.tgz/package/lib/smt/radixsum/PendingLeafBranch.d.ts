import { FinalizedLeafBranch } from './FinalizedLeafBranch.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Pending leaf in a radix sparse Merkle sum tree, awaiting hashing.
 */
export declare class PendingLeafBranch {
    private readonly _key;
    private readonly _data;
    readonly value: bigint;
    readonly depth: number;
    constructor(_key: Uint8Array, _data: Uint8Array, value: bigint);
    /**
     * @returns {Uint8Array} Copy of the leaf data bytes.
     */
    get data(): Uint8Array;
    /**
     * @returns {Uint8Array} Copy of the leaf key bytes.
     */
    get key(): Uint8Array;
    /**
     * Routing key: the leaf's own key, read bit-by-bit during tree construction.
     *
     * @returns {Uint8Array} Copy of the routing key.
     */
    get path(): Uint8Array;
    /**
     * Depth at which `key` diverges from this leaf's key, capped at the leaf's own depth (a full match
     * returns `depth`, signalling a duplicate key).
     *
     * @param {Uint8Array} key Key being inserted.
     * @returns {number} Common-prefix depth.
     */
    calculateSplitDepth(key: Uint8Array): number;
    /**
     * Hash this leaf to produce a finalized branch.
     *
     * @param {IDataHasherFactory<IDataHasher>} factory Hasher factory.
     * @returns {Promise<FinalizedLeafBranch>} Finalized leaf branch.
     */
    finalize(factory: IDataHasherFactory<IDataHasher>): Promise<FinalizedLeafBranch>;
    /**
     * @returns {string} String representation of the leaf.
     */
    toString(): string;
}
