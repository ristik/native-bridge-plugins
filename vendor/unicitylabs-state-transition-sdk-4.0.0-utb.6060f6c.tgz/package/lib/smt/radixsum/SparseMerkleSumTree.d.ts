import { SparseMerkleSumTreeRootNode } from './SparseMerkleSumTreeRootNode.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Radix sparse Merkle sum tree. It reuses the radix sparse Merkle tree structure
 * (big-endian key routing, path-compressed binary trie, absolute bifurcation
 * depths) and additionally commits a positive amount at every leaf and the
 * accumulated sum at every internal node, so any inclusion proof also proves the
 * leaf amount is part of the committed root total.
 */
export declare class SparseMerkleSumTree {
    readonly factory: IDataHasherFactory<IDataHasher>;
    private left;
    private right;
    /**
     * Creates a new instance of SparseMerkleSumTree.
     * @param factory The factory to create data hashers.
     */
    constructor(factory: IDataHasherFactory<IDataHasher>);
    /**
     * Add a leaf to the tree.
     *
     * @param {Uint8Array} key 32-byte leaf key.
     * @param {Uint8Array} data 32-byte leaf data.
     * @param {bigint} value Leaf amount in the range `[1, 2^256)`.
     * @returns {Promise<void>} Resolves when the leaf has been inserted.
     * @throws {Error} If the value is not a positive 256-bit integer, or the key or data is not 32 bytes.
     */
    addLeaf(key: Uint8Array, data: Uint8Array, value: bigint): Promise<void>;
    /**
     * Calculates the hashes for tree and returns root of the tree for given state.
     * @returns A promise that resolves to the SumTreeRootNode representing the root of the tree.
     */
    calculateRoot(): Promise<SparseMerkleSumTreeRootNode>;
    private buildTree;
}
