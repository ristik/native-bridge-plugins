import { FinalizedBranch } from './FinalizedBranch.js';
import { DataHash } from '../../crypto/hash/DataHash.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Radix sparse Merkle sum tree root node. If the tree holds a single leaf the
 * root hash and sum are that leaf's; otherwise the root is the top internal
 * node, which bifurcates at depth 0.
 */
export declare class SparseMerkleSumTreeRootNode {
    readonly left: FinalizedBranch | null;
    readonly right: FinalizedBranch | null;
    readonly value: bigint;
    readonly hash: DataHash;
    readonly depth = 0;
    private constructor();
    /**
     * Creates a new instance of SumTreeRootNode.
     * @param left Root node left branch.
     * @param right Root node right branch.
     * @param factory Factory to create data hashers.
     * @return A promise that resolves to a new SumTreeRootNode instance.
     * @throws {RangeError} On 256-bit sum overflow.
     */
    static create(left: FinalizedBranch | null, right: FinalizedBranch | null, factory: IDataHasherFactory<IDataHasher>): Promise<SparseMerkleSumTreeRootNode>;
    /**
     * Returns a string representation of the SumTreeRootNode.
     */
    toString(): string;
}
