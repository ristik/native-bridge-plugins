import { FinalizedBranch } from './FinalizedBranch.js';
import { DataHash } from '../../crypto/hash/DataHash.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Sparse Merkle Tree root node implementation.
 */
export declare class SparseMerkleTreeRootNode {
    readonly left: FinalizedBranch | null;
    readonly right: FinalizedBranch | null;
    readonly hash: DataHash;
    readonly depth = 0;
    private constructor();
    /**
     * Creates a new instance of MerkleTreeRootNode.
     * @param left Root node left branch.
     * @param right Root node right branch.
     * @param factory Factory to create data hashers.
     * @return A promise that resolves to a new MerkleTreeRootNode instance.
     */
    static create(left: FinalizedBranch | null, right: FinalizedBranch | null, factory: IDataHasherFactory<IDataHasher>): Promise<SparseMerkleTreeRootNode>;
    /**
     * Check whether a leaf with the given key is in the tree.
     *
     * @param {Uint8Array} key Leaf key.
     * @returns {boolean} True if the key is present.
     */
    has(key: Uint8Array): boolean;
    /**
     * Returns a string representation of the MerkleTreeRootNode.
     */
    toString(): string;
}
