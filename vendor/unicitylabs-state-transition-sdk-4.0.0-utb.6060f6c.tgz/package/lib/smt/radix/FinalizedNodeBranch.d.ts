import { FinalizedBranch } from './FinalizedBranch.js';
import { PendingBranch } from './PendingBranch.js';
import { PendingNodeBranch } from './PendingNodeBranch.js';
import { DataHash } from '../../crypto/hash/DataHash.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Finalized interior node in a radix sparse Merkle tree.
 */
export declare class FinalizedNodeBranch {
    private readonly _path;
    readonly depth: number;
    readonly left: FinalizedBranch;
    readonly right: FinalizedBranch;
    readonly hash: DataHash;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the node's committed region (its `depth`-bit prefix, suffix zeroed).
     */
    get path(): Uint8Array;
    /**
     * Hash a {@link PendingNodeBranch} into a finalized node.
     *
     * @param {IDataHasherFactory<IDataHasher>} factory Hasher factory.
     * @param {PendingNodeBranch} node Pending node to finalize.
     * @returns {Promise<FinalizedNodeBranch>} Finalized node branch.
     */
    static create(factory: IDataHasherFactory<IDataHasher>, node: PendingNodeBranch): Promise<FinalizedNodeBranch>;
    /**
     * Depth at which `key` diverges from this node's committed region, capped at the node's own depth.
     *
     * @param {Uint8Array} key Key being inserted.
     * @returns {number} Common-prefix depth.
     */
    calculateSplitDepth(key: Uint8Array): number;
    /**
     * @returns {Promise<FinalizedNodeBranch>} This branch (already finalized).
     */
    finalize(): Promise<FinalizedNodeBranch>;
    /**
     * @returns {string} String representation of the node.
     */
    toString(): string;
    /**
     * Derive a pending node with `left` as its left child, reusing this node's committed region.
     *
     * @param {PendingBranch} left Replacement left child.
     * @returns {PendingNodeBranch} New pending node.
     */
    withLeftBranch(left: PendingBranch): PendingNodeBranch;
    /**
     * Derive a pending node with `right` as its right child, reusing this node's committed region.
     *
     * @param {PendingBranch} right Replacement right child.
     * @returns {PendingNodeBranch} New pending node.
     */
    withRightBranch(right: PendingBranch): PendingNodeBranch;
}
