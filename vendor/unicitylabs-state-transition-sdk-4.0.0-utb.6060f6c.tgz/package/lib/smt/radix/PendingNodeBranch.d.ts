import { FinalizedNodeBranch } from './FinalizedNodeBranch.js';
import { PendingBranch } from './PendingBranch.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Pending interior node in a radix sparse Merkle tree, awaiting hashing.
 */
export declare class PendingNodeBranch {
    private readonly _path;
    readonly depth: number;
    readonly left: PendingBranch;
    readonly right: PendingBranch;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the node's committed region (its `depth`-bit prefix, suffix zeroed).
     */
    get path(): Uint8Array;
    /**
     * Create a pending node, defensively copying the committed region.
     *
     * @param {Uint8Array} path Committed region (its `depth`-bit prefix, suffix zeroed).
     * @param {number} depth Node depth.
     * @param {PendingBranch} left Left child.
     * @param {PendingBranch} right Right child.
     * @returns {PendingNodeBranch} New pending node.
     */
    static create(path: Uint8Array, depth: number, left: PendingBranch, right: PendingBranch): PendingNodeBranch;
    /**
     * Depth at which `key` diverges from this node's committed region, capped at the node's own depth.
     *
     * @param {Uint8Array} key Key being inserted.
     * @returns {number} Common-prefix depth.
     */
    calculateSplitDepth(key: Uint8Array): number;
    /**
     * Hash this node (after finalizing children).
     *
     * @param {IDataHasherFactory<IDataHasher>} factory Hasher factory.
     * @returns {Promise<FinalizedNodeBranch>} Finalized node branch.
     */
    finalize(factory: IDataHasherFactory<IDataHasher>): Promise<FinalizedNodeBranch>;
    /**
     * @returns {string} String representation of the node.
     */
    toString(): string;
    /**
     * Derive a node with `left` as its left child, reusing this node's committed region without copying it.
     *
     * @param {PendingBranch} left Replacement left child.
     * @returns {PendingNodeBranch} New pending node.
     */
    withLeftBranch(left: PendingBranch): PendingNodeBranch;
    /**
     * Derive a node with `right` as its right child, reusing this node's committed region without copying it.
     *
     * @param {PendingBranch} right Replacement right child.
     * @returns {PendingNodeBranch} New pending node.
     */
    withRightBranch(right: PendingBranch): PendingNodeBranch;
}
