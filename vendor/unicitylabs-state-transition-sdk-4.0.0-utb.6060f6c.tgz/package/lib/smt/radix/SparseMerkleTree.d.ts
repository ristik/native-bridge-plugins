import { SparseMerkleTreeRootNode } from './SparseMerkleTreeRootNode.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Sparse Merkle Tree implementation.
 */
export declare class SparseMerkleTree {
    readonly factory: IDataHasherFactory<IDataHasher>;
    private left;
    private right;
    /**
     * Creates a new instance of SparseMerkleTree.
     * @param factory The factory to create data hashers.
     */
    constructor(factory: IDataHasherFactory<IDataHasher>);
    /**
     * Add a leaf to the tree.
     *
     * @param {Uint8Array} key 32-byte leaf key.
     * @param {Uint8Array} data Leaf data bytes (arbitrary length).
     * @returns {Promise<void>} Resolves when the leaf has been inserted.
     * @throws {Error} If the key is not 32 bytes.
     */
    addLeaf(key: Uint8Array, data: Uint8Array): Promise<void>;
    /**
     * Calculates the hashes for tree and returns root of the tree for given state.
     * @returns A promise that resolves to the MerkleTreeRootNode representing the root of the tree.
     */
    calculateRoot(): Promise<SparseMerkleTreeRootNode>;
    private buildTree;
}
