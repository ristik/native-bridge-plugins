import { PendingLeafBranch } from './PendingLeafBranch.js';
import { DataHash } from '../../crypto/hash/DataHash.js';
import { IDataHasher } from '../../crypto/hash/IDataHasher.js';
import { IDataHasherFactory } from '../../crypto/hash/IDataHasherFactory.js';
/**
 * Finalized leaf in a radix sparse Merkle tree.
 */
export declare class FinalizedLeafBranch {
    private readonly _key;
    private readonly _data;
    readonly hash: DataHash;
    readonly depth: number;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the leaf data bytes.
     */
    get data(): Uint8Array;
    /**
     * @returns {Uint8Array} Copy of the leaf key bytes.
     */
    get key(): Uint8Array;
    /**
     * Routing key: the leaf's own key, read bit-by-bit during tree construction.
     *
     * @returns {Uint8Array} Copy of the routing key.
     */
    get path(): Uint8Array;
    /**
     * Hash a {@link PendingLeafBranch} into a finalized leaf.
     *
     * @param {IDataHasherFactory<IDataHasher>} factory Hasher factory.
     * @param {PendingLeafBranch} leaf Pending leaf to finalize.
     * @returns {Promise<FinalizedLeafBranch>} Finalized leaf branch.
     */
    static fromPendingLeaf(factory: IDataHasherFactory<IDataHasher>, leaf: PendingLeafBranch): Promise<FinalizedLeafBranch>;
    /**
     * Depth at which `key` diverges from this leaf's key, capped at the leaf's own depth (a full match
     * returns `depth`, signalling a duplicate key).
     *
     * @param {Uint8Array} key Key being inserted.
     * @returns {number} Common-prefix depth.
     */
    calculateSplitDepth(key: Uint8Array): number;
    /**
     * @returns {Promise<FinalizedLeafBranch>} This branch (already finalized).
     */
    finalize(): Promise<FinalizedLeafBranch>;
    /**
     * @returns {string} String representation of the leaf.
     */
    toString(): string;
}
