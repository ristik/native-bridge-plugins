/**
 * Outcome of verifying a sparse Merkle tree path. The verification is
 * successful only when the path is both well-formed and proves inclusion of
 * the leaf.
 */
export declare class PathVerificationResult {
    readonly isPathValid: boolean;
    readonly isPathIncluded: boolean;
    readonly isSuccessful: boolean;
    constructor(isPathValid: boolean, isPathIncluded: boolean);
}
