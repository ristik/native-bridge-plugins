/**
 * Thrown when a sparse Merkle tree insertion targets a key that is already
 * present in the tree.
 */
export declare class LeafExistsError extends Error {
    constructor();
}
