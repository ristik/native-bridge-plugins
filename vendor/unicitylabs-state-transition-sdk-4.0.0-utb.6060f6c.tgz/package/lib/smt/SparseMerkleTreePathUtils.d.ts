/**
 * Length of the common big-endian bit prefix shared by keys `a` and `b`, capped at `maxDepth`
 * (depth 0 is the most significant bit of byte 0). Used to find where a new key bifurcates from an
 * existing branch: pass `256` for a leaf (compare the whole key) or the node's depth for an interior
 * branch (its stored region is only meaningful up to that depth).
 */
export declare function commonPrefixLength(a: Uint8Array, b: Uint8Array, maxDepth: number): number;
/**
 * The key's first `depth` bits, with the remaining bits of the 32-byte array zeroed.
 */
export declare function regionFromKey(key: Uint8Array, depth: number): Uint8Array;
/**
 * Big-endian bit of `data` at the given depth per the Yellowpaper: depth 0 is the most significant
 * bit of `data[0]` (`data[0] & 0x80`) and depth 255 is the least significant bit of `data[31]`.
 */
export declare function getBitAtDepth(data: Uint8Array, depth: number): number;
/**
 * Render the first `length` big-endian bits of `data` as a `'0'`/`'1'` string: whole bytes first,
 * then the high bits of the partial byte.
 */
export declare function bitsToString(data: Uint8Array, length: number): string;
