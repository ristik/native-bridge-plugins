import { CertificationData } from './CertificationData.js';
import { CertificationResponse } from './CertificationResponse.js';
import { IAggregatorClient } from './IAggregatorClient.js';
import { IBatchAggregatorClient, IBatchRequestOptions, InclusionProofBatch } from './IBatchAggregatorClient.js';
import { InclusionProofResponse } from './InclusionProofResponse.js';
import { INonInclusionAggregatorClient, NonInclusionProofResponse } from './INonInclusionAggregatorClient.js';
import { IInclusionProofRequestOptions, IRequestOptions } from './IRequestOptions.js';
import { ITrustBaseSource } from './ITrustBaseSource.js';
import { StateId } from './StateId.js';
/**
 * Client implementation for communicating with an aggregator via JSON-RPC.
 */
export declare class AggregatorClient implements IAggregatorClient, IBatchAggregatorClient, INonInclusionAggregatorClient, ITrustBaseSource {
    #private;
    /** Largest trust-base response read: the GetTrustBase page cap plus slack for the HTTP framing. */
    static readonly MAX_TRUST_BASE_RESPONSE_BYTES: number;
    private readonly transport;
    private readonly url;
    /**
     * Create a new client pointing to the given aggregator URL.
     *
     * @param url Base URL of the aggregator JSON-RPC endpoint
     * @param key API key for authenticating
     * @param allowInsecureTransport When `true`, permit sending the API key over a non-HTTPS URL
     *   (intended for local development and testing only).
     * @throws {Error} If an API key is supplied for a non-HTTPS URL and `allowInsecureTransport` is `false`.
     */
    constructor(url: string, key?: string | null, allowInsecureTransport?: boolean);
    private static batchFailure;
    /** The validated `waitMs` of a batch call: a caller error is a `rejected` failure before anything is sent. */
    private static batchWait;
    private static decodeBatch;
    /**
     * Decode the proof of a received result. Any failure here, whatever its type or text, is the phase "the service sent
     * material that is not a proof": a malformed response, never a transport or RPC condition.
     */
    private static decodeInclusionProofResponse;
    private static isDuplicateSubmission;
    /**
     * The offending request indexes of a state status error: `data.indexes` is an object with one list per class
     * (`{"pending":[0],"expired":[2],"unknown":[3]}`, `{"not_in_root":[...]}` for an exact root). Malformed lists are
     * ignored, never trusted for control flow.
     */
    private static offendingIndexes;
    private static rpcFailure;
    private static stateIndexes;
    /**
     * @inheritDoc
     * @throws {JsonRpcResponseError} If the result cannot be decoded as a proof (not hex, not CBOR, malformed proof
     *   material): the original decoding error is kept as `cause`. Earlier releases threw that raw error (`CborError`,
     *   `HashError` or `Error`).
     */
    getInclusionProof(stateId: StateId, options?: IInclusionProofRequestOptions): Promise<InclusionProofResponse>;
    /**
     * @inheritDoc
     */
    getInclusionProofs(stateIds: readonly StateId[], options?: IBatchRequestOptions): Promise<InclusionProofBatch>;
    getLatestBlockNumber(): Promise<bigint>;
    /**
     * @inheritDoc
     */
    getNonInclusionProof(stateId: StateId, options?: IRequestOptions): Promise<NonInclusionProofResponse>;
    /**
     * Query the aggregator's latest block number.
     *
     * @returns {Promise<bigint>} Latest block number.
     * @throws {Error} If the response does not contain a numeric `blockNumber`.
     */
    /**
     * Fetch the signed trust-base entries after the latest held one: `GET /api/v1/trustbases?from=<epoch>&maxEntries=<n>` on the aggregator's
     * origin, answered with the GetTrustBase response (tag 39015, `application/cbor`). The bytes are returned undecoded: the aggregator is untrusted
     * transport, the caller decodes them with the page limits and appends each entry through the authenticated history.
     *
     * @param {bigint} fromEpoch First epoch wanted (the latest held epoch + 1).
     * @param {number} maxEntries Most entries wanted.
     * @param {IRequestOptions} [options] Request options.
     * @returns {Promise<Uint8Array>} The encoded response.
     * @throws {JsonRpcNetworkError} On a non-success HTTP status.
     * @throws {JsonRpcResponseError} When the body exceeds {@link MAX_TRUST_BASE_RESPONSE_BYTES}.
     */
    getTrustBaseEntries(fromEpoch: bigint, maxEntries: number, options?: IRequestOptions): Promise<Uint8Array>;
    /**
     * @inheritDoc
     */
    submitCertificationRequest(certificationData: CertificationData, options?: IRequestOptions): Promise<CertificationResponse>;
}
