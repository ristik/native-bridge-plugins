import { UnicityCertificate } from './bft/UnicityCertificate.js';
import { UnicityCertificateInterner } from './bft/UnicityCertificateInterner.js';
import { InclusionProof } from './InclusionProof.js';
import { ProofStatusHint } from './ProofStatusHint.js';
/**
 * What the aggregator answers when asked about a state.
 *
 * This is the wire shape, and it has two forms: a certified leaf, or the absence of one. Keeping
 * that distinction here rather than inside {@link InclusionProof} is what lets the proof itself be
 * complete by construction — a verifier that holds one never has to ask whether it describes a
 * leaf.
 */
export declare class InclusionProofResponse {
    readonly blockNumber: bigint;
    readonly inclusionProof: InclusionProof | null;
    readonly unicityCertificate: UnicityCertificate;
    private readonly _statusHint;
    private readonly _waitedMs;
    private constructor();
    /**
     * The aggregator's **unauthenticated hint**, present only when the request asked for it (`includeStatusHint`) and the
     * aggregator answered with a recognized one; `null` is the legacy behavior. It is not a verdict and not evidence: it
     * is not part of the proof, never changes how a proof is verified, can accompany a missing proof (`included`
     * without one), and `unknown` or `expired` is not a proof of absence.
     *
     * @returns {ProofStatusHint|null} Hint, or `null`.
     */
    get statusHint(): ProofStatusHint | null;
    /**
     * The aggregator's **unauthenticated echo** of the time it held the request (`waitMs`), in milliseconds: present only
     * when the request asked for a wait and the aggregator echoed it; `null` is the legacy behavior. `0` means it did not
     * wait. It is timing metadata, not evidence: not part of the proof, not encoded by {@link toCBOR}, and no
     * promise that a particular duration was honored. A missing echo says nothing about the aggregator's capability.
     *
     * @returns {number|null} Milliseconds, or `null`.
     */
    get waitedMs(): number | null;
    /**
     * The aggregator has certified this state.
     *
     * The round it was served against is the proof's own, so there is no second certificate to
     * supply and none that could disagree with it.
     *
     * @param {bigint} blockNumber Block number the answer was served at.
     * @param {InclusionProof} inclusionProof The certified leaf.
     * @returns {InclusionProofResponse} The response.
     */
    static certified(blockNumber: bigint, inclusionProof: InclusionProof): InclusionProofResponse;
    /**
     * Create response from CBOR bytes within a decoding operation sharing identical wire certificates.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @param {UnicityCertificateInterner} [interner] Decoding operation, or none to parse every certificate.
     * @returns {InclusionProofResponse} Inclusion proof response.
     */
    static decodeWith(bytes: Uint8Array, interner?: UnicityCertificateInterner): InclusionProofResponse;
    /**
     * Create response from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {InclusionProofResponse} Inclusion proof response.
     */
    static fromCBOR(bytes: Uint8Array): InclusionProofResponse;
    /**
     * The aggregator has not certified this state yet, so only the round is meaningful.
     *
     * @param {bigint} blockNumber Block number the answer was served at.
     * @param {UnicityCertificate} unicityCertificate Certificate of the round the answer was served against.
     * @returns {InclusionProofResponse} The response.
     */
    static notCertified(blockNumber: bigint, unicityCertificate: UnicityCertificate): InclusionProofResponse;
    /**
     * Convert InclusionProofResponse to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * The same response with the aggregator's (unauthenticated) hint attached. The hint is not encoded by {@link toCBOR}.
     *
     * @param {ProofStatusHint|null} hint Hint, `null` for none.
     * @returns {InclusionProofResponse} New response.
     */
    withStatusHint(hint: ProofStatusHint | null): InclusionProofResponse;
    /**
     * The same response with the aggregator's (unauthenticated) wait echo attached. It is not encoded by {@link toCBOR}.
     *
     * @param {number|null} waitedMs Milliseconds waited, `null` for no echo.
     * @returns {InclusionProofResponse} New response.
     */
    withWaitedMs(waitedMs: number | null): InclusionProofResponse;
    /**
     * Encode the wire form for a state with no certified leaf: the three leaf fields absent, the
     * round's certificate still present.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    private encodeNoCertifiedLeaf;
}
