import { UnicityCertificate } from './bft/UnicityCertificate.js';
import { UnicityCertificateInterner } from './bft/UnicityCertificateInterner.js';
import { CertificationData } from './CertificationData.js';
import { InclusionCertificate } from './InclusionCertificate.js';
/**
 * Represents a proof of inclusion or non inclusion in a sparse merkle tree.
 */
export declare class InclusionProof {
    readonly certificationData: CertificationData;
    readonly referenceTime: bigint;
    readonly inclusionCertificate: InclusionCertificate;
    readonly unicityCertificate: UnicityCertificate;
    static readonly CBOR_TAG = 39033n;
    static readonly VERSION = 1n;
    /**
     * Constructs an InclusionProof instance.
     *
     * An InclusionProof describes a certified leaf, so every field is present. The aggregator's
     * answer for a state it has not certified yet is not an InclusionProof at all — see
     * {@link InclusionProofResponse}, which is the type that can express it.
     *
     * @param certificationData Certification data.
     * @param referenceTime Reference time of the round the leaf was created in, in Unix seconds.
     * @param inclusionCertificate Inclusion certificate.
     * @param unicityCertificate Unicity certificate.
     */
    constructor(certificationData: CertificationData, referenceTime: bigint, inclusionCertificate: InclusionCertificate, unicityCertificate: UnicityCertificate);
    /**
     * @returns {bigint} Wire-format version of this inclusion proof.
     */
    get version(): bigint;
    /**
     * Decodes an InclusionProof from CBOR bytes within a decoding operation sharing identical wire certificates.
     *
     * @param bytes The CBOR-encoded bytes.
     * @param interner Decoding operation, or none to parse every certificate.
     * @returns An InclusionProof instance.
     * @throws {CborError} On a wrong tag, an unsupported version, or bytes describing no leaf.
     */
    static decodeWith(bytes: Uint8Array, interner?: UnicityCertificateInterner): InclusionProof;
    /**
     * Decodes an InclusionProof from CBOR bytes.
     *
     * The bytes must describe a certified leaf. The same wire form can also say that no leaf is
     * certified yet, but that is not an InclusionProof — {@link InclusionProofResponse} is the type
     * that carries it, and it decodes that case itself.
     *
     * @param bytes The CBOR-encoded bytes.
     * @returns An InclusionProof instance.
     * @throws {CborError} On a wrong tag, an unsupported version, or bytes describing no leaf.
     */
    static fromCBOR(bytes: Uint8Array): InclusionProof;
    /**
     * Encodes the InclusionProof to CBOR format.
     * @returns The CBOR-encoded bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the InclusionProof.
     * @returns The string representation.
     */
    toString(): string;
}
