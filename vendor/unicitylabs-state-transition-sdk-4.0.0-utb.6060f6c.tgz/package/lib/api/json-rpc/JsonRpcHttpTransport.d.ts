import { IRequestOptions } from '../IRequestOptions.js';
/**
 * JSON-RPC HTTP service.
 */
export declare class JsonRpcHttpTransport {
    /** Default maximum response body size in bytes, matching the Rust SDK's `MAX_RESPONSE_BODY_BYTES`. */
    static readonly DEFAULT_MAX_RESPONSE_BYTES: number;
    private readonly maxResponseBytes;
    private readonly url;
    /**
     * JSON-RPC HTTP service constructor.
     *
     * @param {string} url Endpoint URL.
     * @param {number} maxResponseBytes Maximum response body size in bytes; defaults to {@link JsonRpcHttpTransport.DEFAULT_MAX_RESPONSE_BYTES}.
     */
    constructor(url: string, maxResponseBytes?: number);
    /** The error object of an envelope as an error, or a response error if it is not a valid error object. */
    /**
     * The `Retry-After` header as milliseconds (RFC 9110): delay-seconds of any length saturate at 60 s, an HTTP-date is
     * the date minus the local clock (floored at 0, capped at 60 s), a sign or anything else is ignored.
     *
     * @param {string | null} value Header value.
     * @param {number} [now] Local time in milliseconds (for the date form).
     * @returns {number | undefined} Milliseconds, `undefined` when absent or not a valid form.
     */
    static parseRetryAfter(value: string | null, now?: number): number | undefined;
    private static dataError;
    private static parseEnvelope;
    /**
     * An HTTP-date (RFC 9110 §5.6.7) in exactly one of its three forms, IMF-fixdate, RFC 850 or asctime, with every field
     * validated (a day within its month, hour at most 23, ...). Anything else is not a date.
     *
     * @param {string} text The header value.
     * @param {number} now Local time in milliseconds (the two-digit year of RFC 850 is read relative to it).
     * @returns {number | undefined} Milliseconds since the epoch, `undefined` when it is not an HTTP-date.
     */
    private static parseHttpDate;
    /**
     * Read a response body as text, rejecting bodies larger than `maxBytes`.
     *
     * @param {Response} response Fetch response.
     * @param {number} maxBytes Maximum allowed body size in bytes.
     * @returns {Promise<string>} The decoded body, or an empty string when the response has no body.
     * @throws {JsonRpcResponseError} If the body exceeds `maxBytes`.
     */
    private static readBoundedText;
    /**
     * Send a JSON-RPC request.
     *
     * @param {string} method JSON-RPC method.
     * @param {unknown} params JSON-RPC params.
     * @param {Headers} headers Optional request headers.
     * @param {IRequestOptions} options Optional per-request options, e.g. an abort signal.
     * @returns {Promise<unknown>} The response result.
     * @throws {JsonRpcNetworkError} On a non-success HTTP status.
     * @throws {JsonRpcDataError} When the response carries a JSON-RPC error object.
     * @throws {JsonRpcResponseError} When the response is malformed (version, id, exclusivity, size).
     */
    request(method: string, params: unknown, headers?: Headers, options?: IRequestOptions): Promise<unknown>;
}
