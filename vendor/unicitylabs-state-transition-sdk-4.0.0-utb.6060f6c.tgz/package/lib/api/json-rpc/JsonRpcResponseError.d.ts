/**
 * Thrown when a JSON-RPC response is malformed — wrong protocol version,
 * mismatched id, not exactly one of result/error, oversized, or not valid JSON.
 */
export declare class JsonRpcResponseError extends Error {
    readonly name: string;
    /** The `Retry-After` of that response in milliseconds (capped at 60 s). */
    readonly retryAfterMs?: number;
    /** The HTTP status of a non-2xx response whose body could not be read (oversized): it still classifies the answer. */
    readonly status?: number;
    /**
     * @param {string} message Error message.
     * @param {ErrorOptions & {status?: number; retryAfterMs?: number}} [options] Cause and response details.
     */
    constructor(message: string, options?: ErrorOptions & {
        retryAfterMs?: number;
        status?: number;
    });
}
