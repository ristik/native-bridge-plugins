import { NetworkId } from '../NetworkId.js';
/**
 * JSON representation of a root trust base node information.
 */
interface INodeInfoJson {
    /**
     * Node id.
     */
    readonly nodeId: string;
    /**
     * Signing key.
     */
    readonly sigKey: string;
    /**
     * Staked amount.
     */
    readonly stake: string;
}
/**
 * Root trust base node information.
 */
export declare class RootTrustBaseNodeInfo {
    readonly nodeId: string;
    private readonly _signingKey;
    readonly stakedAmount: bigint;
    /**
     * RootTrustBaseNodeInfo constructor.
     * @param nodeId node id.
     * @param _signingKey signing key.
     * @param stakedAmount staked amount.
     */
    private constructor();
    /**
     * Get the signing key.
     */
    get signingKey(): Uint8Array;
    /**
     * Create a RootTrustBaseNodeInfo from JSON representation.
     * @param input JSON representation.
     * @return RootTrustBaseNodeInfo instance.
     */
    static fromJSON(input: unknown): RootTrustBaseNodeInfo;
    /**
     * Check whether the input is a JSON representation of RootTrustBaseNodeInfo.
     * @param input input to check.
     * @return true if the input is a JSON representation of RootTrustBaseNodeInfo.
     */
    static isJSON(input: unknown): input is INodeInfoJson;
    /**
     * @returns {INodeInfoJson} JSON representation of the node info.
     */
    toJSON(): INodeInfoJson;
    /**
     * @returns {string} String representation of the node info.
     */
    toString(): string;
}
/**
 * JSON shape of a {@link RootTrustBase}.
 */
interface IRootTrustBaseJson {
    readonly changeRecordHash: string | null;
    readonly epoch: string;
    readonly epochStartRound: string;
    readonly networkId: number;
    readonly previousEntryHash: string | null;
    readonly quorumThreshold: string;
    readonly rootNodes: INodeInfoJson[];
    readonly signatures: {
        [key: string]: string;
    };
    readonly stateHash: string;
    readonly version: string;
}
/**
 * Root trust base information.
 */
export declare class RootTrustBase {
    readonly networkId: NetworkId;
    readonly epoch: bigint;
    readonly epochStartRound: bigint;
    readonly _rootNodes: Map<string, RootTrustBaseNodeInfo>;
    readonly quorumThreshold: bigint;
    readonly _stateHash: Uint8Array;
    readonly _changeRecordHash: Uint8Array | null;
    readonly _previousEntryHash: Uint8Array | null;
    private readonly _signatures;
    private static readonly VERSION;
    private constructor();
    /**
     * Get the change record hash.
     */
    get changeRecordHash(): Uint8Array | null;
    /**
     * Get the previous entry hash.
     */
    get previousEntryHash(): Uint8Array | null;
    /**
     * Get the root nodes.
     */
    get rootNodes(): Map<string, RootTrustBaseNodeInfo>;
    /**
     * Get the signatures.
     */
    get signatures(): Map<string, Uint8Array>;
    /**
     * Get the state hash.
     */
    get stateHash(): Uint8Array;
    /**
     * @returns {bigint} Wire-format version of the trust base.
     */
    get version(): bigint;
    /**
     * Create a root trust base from JSON string.
     *
     * @param input JSON string
     * @return root trust base
     */
    static fromJSON(input: unknown): RootTrustBase;
    /**
     * Check whether the input is a JSON representation of RootTrustBase.
     * @param input input to check.
     * @return true if the input is a JSON representation of RootTrustBase.
     */
    static isJSON(input: unknown): input is IRootTrustBaseJson;
    /**
     * Faithful copy of this trust base: same signer lookup entries (map keys included), threshold and context. Later
     * changes to either object do not affect the other.
     *
     * @returns {RootTrustBase} Independent copy.
     */
    snapshot(): RootTrustBase;
    /**
     * @returns {IRootTrustBaseJson} JSON representation of the trust base (mirrors {@link fromJSON}).
     */
    toJSON(): IRootTrustBaseJson;
    /**
     * @returns {string} String representation of the trust base.
     */
    toString(): string;
}
export {};
