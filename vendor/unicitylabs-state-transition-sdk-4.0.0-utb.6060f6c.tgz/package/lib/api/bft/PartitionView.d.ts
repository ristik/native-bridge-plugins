import { InputRecord } from './InputRecord.js';
import { ShardId } from './ShardId.js';
import { UnicityCertificate } from './UnicityCertificate.js';
import { ShardTree } from '../../internal/bft/ShardTree.js';
/**
 * Optional stricter policy a candidate view is additionally checked against. The view is authenticated by its
 * commitment under the enclosing seal; pins from the verifier's own configuration (never from the response carrying the
 * view) only narrow what is accepted. Pins are part of the identity of the authenticator that applies them.
 */
export interface IPartitionViewPolicy {
    /**
     * Required sharding scheme: empty for a single shard partition, otherwise at least two shards forming a complete
     * prefix-free set.
     */
    readonly scheme?: readonly ShardId[];
    /**
     * Pinned shard configuration hashes. Every pinned shard must be a shard of the view, a shard is pinned at most once
     * and every hash is 32 bytes; anything else is rejected, never silently ignored (a pin that is not consulted would
     * make the policy fail open). Shards without a pin are not constrained.
     */
    readonly shardConfigurationPins?: readonly IShardConfigurationPin[];
}
/**
 * Pinned configuration hash of one shard.
 */
export interface IShardConfigurationPin {
    /** The shard's 32-byte configuration hash. */
    readonly hash: Uint8Array;
    /** The shard. */
    readonly shard: ShardId;
}
/**
 * Committed content of one shard in a {@link PartitionView}.
 */
export declare class PartitionViewLeaf {
    readonly shardId: ShardId;
    readonly inputRecord: InputRecord;
    private readonly _shardConfigurationHash;
    private readonly _technicalRecordHash;
    constructor(shardId: ShardId, inputRecord: InputRecord, technicalRecordHash: Uint8Array, shardConfigurationHash: Uint8Array);
    /**
     * @returns {Uint8Array} Copy of the shard configuration hash.
     */
    get shardConfigurationHash(): Uint8Array;
    /**
     * @returns {Uint8Array} Copy of the technical record hash.
     */
    get technicalRecordHash(): Uint8Array;
    /**
     * Strictly decode one encoded leaf and check its bounds.
     *
     * @param {Uint8Array} bytes CBOR `[shardId, inputRecord, trHash, shardConfHash]`.
     * @returns {PartitionViewLeaf} Decoded leaf.
     * @throws {PartitionViewError} If the bytes are not a valid leaf.
     */
    static fromCBOR(bytes: Uint8Array): PartitionViewLeaf;
    /**
     * @returns {Uint8Array} CBOR encoding `[shardId, inputRecord, trHash, shardConfHash]`.
     */
    toCBOR(): Uint8Array;
    /**
     * Check the per leaf limits. Does not know the expected topology.
     *
     * @returns {void}
     * @throws {PartitionViewError} If the leaf is out of bounds.
     */
    validateBounds(): void;
}
/**
 * Partition view: the complete vector of shard tree leaves of one partition, as committed by a single unicity seal.
 *
 * Untagged, explicitly versioned CBOR array `[1, partitionId, [[shardId, inputRecord, trHash, shardConfHash], ...]]`
 * from which the ordinary unicity certificates of every shard can be derived. A decoded view is NOT trusted:
 * {@link PartitionViewAuthenticator.authenticate} authenticates it against the enclosing certificate and the seal.
 */
export declare class PartitionView {
    readonly partitionId: bigint;
    /** Maximum size of an encoded view. */
    static readonly MAX_BYTES: number;
    /** Maximum size of an encoded input record. */
    static readonly MAX_INPUT_RECORD_BYTES = 1024;
    /** Maximum number of shards in a view. */
    static readonly MAX_LEAVES = 8;
    /** Maximum shard id length in bits. */
    static readonly MAX_SHARD_ID_BITS = 256;
    /** Maximum size of the input record summary value. */
    static readonly MAX_SUMMARY_VALUE_BYTES = 256;
    private static readonly MAX_PARTITION_ID;
    private static readonly VERSION;
    private readonly _leaves;
    /**
     * @param {bigint} partitionId Partition id, nonzero 32-bit unsigned.
     * @param {PartitionViewLeaf[]} leaves Leaves in canonical order.
     * @throws {PartitionViewError} If the view is out of bounds.
     */
    constructor(partitionId: bigint, leaves: readonly PartitionViewLeaf[]);
    /**
     * @returns {PartitionViewLeaf[]} Copy of the leaf list.
     */
    get leaves(): PartitionViewLeaf[];
    /**
     * @returns {ShardId[]} Sharding scheme the candidate's leaves describe: empty for a single shard partition.
     *   Candidate data, not authenticated by itself.
     */
    get scheme(): ShardId[];
    /**
     * @returns {bigint} Wire-format version of the view.
     */
    get version(): bigint;
    /**
     * Shard ids of the scheme in binary tree left-to-right order (lexicographic bit string, `0` before `1`). Empty
     * scheme yields the single empty shard id.
     *
     * @param {readonly ShardId[]} scheme Sharding scheme.
     * @returns {ShardId[]} Shard ids in canonical order.
     * @throws {PartitionViewError} If the scheme is not a complete prefix-free set within limits.
     */
    static canonicalShardOrder(scheme: readonly ShardId[]): ShardId[];
    /**
     * Decode the enclosing certificate of a view, rejecting any encoding that does not re-encode byte-identically, so
     * derived certificates carry exactly the master seal bytes that were authenticated.
     *
     * @param {Uint8Array} bytes CBOR bytes of a unicity certificate.
     * @returns {UnicityCertificate} Decoded certificate.
     * @throws {PartitionViewError} If decoding fails or the encoding is not canonical.
     */
    static decodeEnclosingCertificate(bytes: Uint8Array): UnicityCertificate;
    /**
     * Strictly decode a view: bounded input size, exact array lengths, no trailing bytes, no indefinite length items,
     * explicit version 1, untagged, and the encoding must be the canonical one.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {PartitionView} Decoded view, not authenticated.
     * @throws {PartitionViewError} If the bytes are not a valid view.
     */
    static fromCBOR(bytes: Uint8Array): PartitionView;
    /**
     * Validate the structure and rebuild the native shard tree from the leaves.
     *
     * @param {bigint} partition Expected partition id.
     * @param {IPartitionViewPolicy} [policy] Optional pins.
     * @returns {Promise<ShardTree>} Shard tree, built from untrusted candidate data.
     * @throws {PartitionViewError} If the view is not well formed or does not match the pins.
     */
    buildShardTree(partition: bigint, policy?: IPartitionViewPolicy): Promise<ShardTree>;
    /**
     * Check that the view hashes into the unicity seal of the enclosing certificate: structure and topology are
     * validated, the partition certificate must be for the view's partition and the rebuilt shard tree root must evaluate
     * through it to the seal hash. The enclosing certificate's own shard leaf must match the view completely.
     *
     * The seal signatures are NOT checked here, see {@link PartitionViewAuthenticator.authenticate}.
     *
     * @param {UnicityCertificate} enclosingUc Certificate carrying the seal the view is committed under.
     * @param {bigint} partition Expected partition id.
     * @param {IPartitionViewPolicy} [policy] Optional pins.
     * @returns {Promise<ShardTree>} The rebuilt shard tree.
     * @throws {PartitionViewError} If the view is not committed by the certificate.
     */
    checkCommitmentUnauthenticated(enclosingUc: UnicityCertificate, partition: bigint, policy?: IPartitionViewPolicy): Promise<ShardTree>;
    /**
     * Convert to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * Check that the view is a well formed candidate for the given partition: its leaves are distinct valid shard ids
     * forming a complete prefix-free scheme in canonical left-to-right order. The scheme is taken from the candidate
     * itself (it is authenticated later by the seal commitment); pins in `policy` only narrow it. Does not touch any
     * hash tree.
     *
     * @param {bigint} partition Expected partition id.
     * @param {IPartitionViewPolicy} [policy] Optional pins.
     * @returns {void}
     * @throws {PartitionViewError} If the view does not match.
     */
    validateStructure(partition: bigint, policy?: IPartitionViewPolicy): void;
    private deriveCertificate;
    /** The pins by shard bit string; unknown shards, duplicates and wrong lengths are errors. */
    private resolvePins;
}
