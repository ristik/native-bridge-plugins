import { CertificateVerificationResult } from './CertificateVerdict.js';
import { UnicitySealQuorumSignaturesVerificationRule } from './rule/UnicitySealQuorumSignaturesVerificationRule.js';
import { SealVerificationSession } from './SealVerificationSession.js';
import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import { InclusionProof } from '../../InclusionProof.js';
import { ITrustBaseAuthority } from '../trustbase/TrustBaseAuthority.js';
import { UnicityCertificate } from '../UnicityCertificate.js';
/** Options of a certificate verification. */
export interface IUnicityCertificateVerificationOptions {
    /** Expected partition, the aggregation partition by default. */
    readonly partitionId?: bigint;
}
/**
 * Result of a {@link UnicityCertificateVerifier} run, with its {@link CertificateVerdict} (`no_entry_for_epoch` is retryable after appending newer
 * trust-base entries).
 */
export declare class UnicityCertificateVerificationResult extends CertificateVerificationResult {
    private constructor();
    /**
     * Build a failed verification result, classified by its failing (last) child.
     *
     * @param {VerificationResult<unknown>[]} results Child rule results, the failing one last.
     * @returns {UnicityCertificateVerificationResult} Failed result.
     */
    static fail(results: VerificationResult<unknown>[]): UnicityCertificateVerificationResult;
    /**
     * Build a successful verification result.
     *
     * @param {VerificationResult<unknown>[]} results Child rule results.
     * @returns {UnicityCertificateVerificationResult} Successful result.
     */
    static ok(results: VerificationResult<unknown>[]): UnicityCertificateVerificationResult;
}
/**
 * Unicity certificate verification.
 *
 * Composed from the quorum-signature rule, which carries the signature verifier
 * and any seal memo, so callers pass this domain-level verifier around rather
 * than a bare signature verifier that says nothing about what it verifies:
 *
 * ```ts
 * new UnicityCertificateVerifier(
 *   new UnicitySealQuorumSignaturesVerificationRule(
 *     new Secp256k1SignatureVerifier(),
 *     new VerifiedSealCache(256), // omit to verify every seal afresh
 *   ),
 * );
 * ```
 */
export declare class UnicityCertificateVerifier {
    protected readonly quorumSignaturesRule: UnicitySealQuorumSignaturesVerificationRule;
    /**
     * @param {UnicitySealQuorumSignaturesVerificationRule} quorumSignaturesRule Seal quorum-signature rule.
     */
    constructor(quorumSignaturesRule: UnicitySealQuorumSignaturesVerificationRule);
    /**
     * @returns {UnicitySealQuorumSignaturesVerificationRule} The quorum rule this verifier applies, with its signature
     *   verifier and cache: whoever shares seal work with this verifier must do it through this rule.
     */
    get quorumRule(): UnicitySealQuorumSignaturesVerificationRule;
    /**
     * Begin one verification operation (e.g. one token with every nested token).
     *
     * Returns a verifier with the same rules whose repeated work is shared for the operation only: a distinct complete
     * unicity certificate has its shard and partition path to the seal hash evaluated once, a distinct complete seal has
     * its quorum signatures checked once (concurrent checks share the running one), and the authority identity is built
     * once. Per-input rules (leaf data, reference time, predicates, paths to the state root) are not shared. Memo keys
     * commit to the complete certificate or seal bytes and the operation's authority snapshot, only successes are kept,
     * and the state is bounded and discarded with the returned object.
     *
     * A subclass that customizes verification, or a verifier built with a customized quorum rule, returns itself: injected
     * verifiers and rules keep full control.
     *
     * @param {SealVerificationSession} [session] Session to adopt for its trust base, so that a caller that already
     *   authenticated a seal strictly in the same operation does not pay the quorum check twice.
     * @returns {UnicityCertificateVerifier} Operation scoped verifier.
     */
    beginOperation(session?: SealVerificationSession): UnicityCertificateVerifier;
    /**
     * Verify the unicity certificate in an inclusion proof against the held trust-base history.
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history.
     * @param {InclusionProof} inclusionProof Inclusion proof carrying the unicity certificate.
     * @param {IUnicityCertificateVerificationOptions} [options] Options.
     * @returns {Promise<UnicityCertificateVerificationResult>} Verification outcome with its class.
     */
    verify(trustBase: ITrustBaseAuthority, inclusionProof: InclusionProof, options?: IUnicityCertificateVerificationOptions): Promise<UnicityCertificateVerificationResult>;
    /**
     * Verify a unicity certificate against the held trust-base history, in the order and with the classes of the native B1 verifier: format and
     * bounds (`malformed`), structure and partition (`invalid`), the tree path to the seal hash (`invalid`), then the seal against the committee of
     * its own epoch (`no_entry_for_epoch` for an epoch newer than the latest held one, otherwise `invalid` or `ok`).
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history.
     * @param {UnicityCertificate} certificate Certificate.
     * @param {IUnicityCertificateVerificationOptions} [options] Options.
     * @returns {Promise<UnicityCertificateVerificationResult>} Verification outcome with its class.
     */
    verifyCertificate(trustBase: ITrustBaseAuthority, certificate: UnicityCertificate, options?: IUnicityCertificateVerificationOptions): Promise<UnicityCertificateVerificationResult>;
    /**
     * @param {UnicityCertificate} certificate Certificate.
     * @returns {Promise<VerificationResult<VerificationStatus>>} The shard and unicity tree path to the seal hash.
     */
    protected verifyBody(certificate: UnicityCertificate): Promise<VerificationResult<VerificationStatus>>;
    /**
     * @param {ITrustBaseAuthority} trustBase Held trust-base history.
     * @param {UnicityCertificate} certificate Certificate.
     * @returns {Promise<VerificationResult<VerificationStatus>>} The seal against its epoch committee.
     */
    protected verifySeal(trustBase: ITrustBaseAuthority, certificate: UnicityCertificate): Promise<VerificationResult<VerificationStatus>>;
}
/**
 * Hardware-independent work counters of an operation scoped verifier.
 */
export interface IOperationVerificationStats {
    /** Authority identities built (once per trust base of the operation, never per proof). */
    readonly authorityBuilds: number;
    /** Shard and partition path evaluations to the seal hash actually executed (distinct complete certificates). */
    readonly bodyChecks: number;
    /** Body results served from the memo or a running check. */
    readonly bodyHits: number;
    /** Certificate encodings made to key the memo (one per verified proof). */
    readonly encodes: number;
    /** Quorum signature verifications actually executed (distinct complete seals per trust base). */
    readonly quorumChecks: number;
}
/**
 * {@link UnicityCertificateVerifier} for one operation, see {@link UnicityCertificateVerifier.beginOperation}.
 */
export declare class OperationUnicityCertificateVerifier extends UnicityCertificateVerifier {
    private static readonly MAX_BODIES;
    private readonly bodies;
    private readonly counters;
    private readonly inFlight;
    private readonly sessions;
    /**
     * Not constructible by applications: obtain it with {@link UnicityCertificateVerifier.beginOperation}, so that an
     * operation always starts from the caller's own verifier and rule.
     *
     * @param {symbol} capability Module private capability.
     * @param {UnicitySealQuorumSignaturesVerificationRule} rule Quorum rule of the verifier this operation began from.
     * @param {SealVerificationSession} [session] Session to adopt for its trust base.
     */
    constructor(capability: symbol, rule: UnicitySealQuorumSignaturesVerificationRule, session?: SealVerificationSession);
    /**
     * @returns {IOperationVerificationStats} Snapshot of the work counters.
     */
    get stats(): IOperationVerificationStats;
    /**
     * @inheritDoc
     */
    beginOperation(): OperationUnicityCertificateVerifier;
    /**
     * The operation's seal session for a trust base (created on first use): whoever authenticates seals strictly in this
     * operation, e.g. `verifyNonInclusion`, shares the quorum checks of the proofs verified through this verifier.
     *
     * @param {ITrustBaseAuthority} trustBase Held trust-base history.
     * @returns {SealVerificationSession} The session.
     */
    sessionFor(trustBase: ITrustBaseAuthority): SealVerificationSession;
    /**
     * @inheritDoc
     */
    protected verifyBody(certificate: UnicityCertificate): Promise<VerificationResult<VerificationStatus>>;
    /**
     * @inheritDoc
     */
    protected verifySeal(trustBase: ITrustBaseAuthority, certificate: UnicityCertificate): Promise<VerificationResult<VerificationStatus>>;
    private body;
    private session;
}
