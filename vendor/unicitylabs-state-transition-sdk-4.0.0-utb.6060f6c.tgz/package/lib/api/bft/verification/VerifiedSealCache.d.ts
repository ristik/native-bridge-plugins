import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
/**
 * Bounded memo of seals that have already been verified.
 *
 * Every leaf certified in one aggregator round shares a seal, so a batch of
 * inclusion proofs re-verifies the same few seals — measured on testnet2,
 * twenty proofs shared three seals. Caching that pure result removes most of
 * the signature work from proof verification.
 *
 * The cache is supplied to {@link UnicitySealQuorumSignaturesVerificationRule}
 * by the caller rather than held statically, so its lifetime and size are the
 * application's to choose, and a rule constructed without one simply does not
 * memoise.
 *
 * Keys must commit to everything the verdict depends on — the rule builds them;
 * see its documentation for why the seal's signature-excluding hash is not
 * enough on its own.
 */
export declare class VerifiedSealCache {
    private readonly maxEntries;
    private readonly entries;
    /**
     * @param {number} maxEntries Upper bound on retained entries; the oldest is evicted first.
     * @throws {Error} If `maxEntries` is not a positive integer.
     */
    constructor(maxEntries: number);
    /**
     * @param {string} key Cache key.
     * @returns {VerificationResult<VerificationStatus>|null} Memoised outcome, or null on a miss.
     */
    get(key: string): VerificationResult<VerificationStatus> | null;
    /**
     * Store an outcome, evicting the oldest entry once full (`Map` iterates in
     * insertion order).
     *
     * @param {string} key Cache key.
     * @param {VerificationResult<VerificationStatus>} result Outcome to memoise.
     * @returns {void}
     */
    set(key: string, result: VerificationResult<VerificationStatus>): void;
}
