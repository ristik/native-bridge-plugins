import { VerificationResult } from '../../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../../verification/VerificationStatus.js';
import { UnicityCertificate } from '../../UnicityCertificate.js';
/**
 * Rule for the application-level shape of a unicity certificate, checked before any hashing or signature work: it is of
 * the aggregation partition ({@link AGGREGATION_PARTITION_ID}), and it satisfies the structural rules of the native
 * `UnicityCertificate.IsValid` (bft-go-base): input record, 32 byte technical record hash, and seal.
 *
 * It never throws: a certificate that violates a rule yields a failed result.
 */
export declare class UnicityCertificateStructureRule {
    /**
     * @param {UnicityCertificate} unicityCertificate Certificate to check.
     * @param {bigint} [partitionId] Expected partition, the aggregation partition by default.
     * @returns {string|null} Failure description, or `null` if the certificate is acceptable.
     */
    static failure(unicityCertificate: UnicityCertificate, partitionId?: bigint): string | null;
    /**
     * @param {UnicityCertificate} unicityCertificate Certificate to check.
     * @param {bigint} [partitionId] Expected partition, the aggregation partition by default.
     * @returns {VerificationResult<VerificationStatus>} Verification outcome.
     */
    static verify(unicityCertificate: UnicityCertificate, partitionId?: bigint): VerificationResult<VerificationStatus>;
}
