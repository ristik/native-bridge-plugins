import { UnicityCertificate } from '../../UnicityCertificate.js';
import { CertificateVerificationResult } from '../CertificateVerdict.js';
/**
 * The native B1 bounds and formats of a unicity certificate (bft-core `b1ref` limits): a certificate outside them is refused as `malformed` before
 * anything is evaluated, the same class B1 gives it (`status = error`).
 *
 * - encoded certificate at most {@link MAX_CERTIFICATE_BYTES};
 * - shard tree path: exactly one sibling per shard bit, at most {@link MAX_SHARD_SIBLINGS};
 * - unicity tree path: at most {@link MAX_UNICITY_STEPS} steps;
 * - input record summary value at most {@link MAX_SUMMARY_BYTES};
 * - seal signatures: see {@link UnicitySealQuorumSignaturesVerificationRule.checkSignatureFormat}.
 */
export declare class UnicityCertificateFormatRule {
    static readonly MAX_CERTIFICATE_BYTES = 24576;
    static readonly MAX_SHARD_SIBLINGS = 256;
    static readonly MAX_SUMMARY_BYTES = 256;
    static readonly MAX_UNICITY_STEPS = 32;
    /**
     * @param {UnicityCertificate} certificate Certificate.
     * @returns {string|null} Why the certificate is malformed, or null.
     */
    static failure(certificate: UnicityCertificate): string | null;
    /**
     * @param {UnicityCertificate} certificate Certificate.
     * @returns {CertificateVerificationResult} `ok` or `malformed`.
     */
    static verify(certificate: UnicityCertificate): CertificateVerificationResult;
}
