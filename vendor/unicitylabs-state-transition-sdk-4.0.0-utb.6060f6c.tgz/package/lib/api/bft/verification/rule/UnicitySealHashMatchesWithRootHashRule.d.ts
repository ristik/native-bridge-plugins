import { VerificationResult } from '../../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../../verification/VerificationStatus.js';
import { UnicityCertificate } from '../../UnicityCertificate.js';
/**
 * Rule to verify that the UnicitySeal hash matches the root hash of the UnicityTreeCertificate.
 */
export declare class UnicitySealHashMatchesWithRootHashRule {
    /**
     * Verify the unicity seal hash matches the recomputed root hash.
     *
     * @param {UnicityCertificate} unicityCertificate Unicity certificate to verify.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     */
    static verify(unicityCertificate: UnicityCertificate): Promise<VerificationResult<VerificationStatus>>;
}
