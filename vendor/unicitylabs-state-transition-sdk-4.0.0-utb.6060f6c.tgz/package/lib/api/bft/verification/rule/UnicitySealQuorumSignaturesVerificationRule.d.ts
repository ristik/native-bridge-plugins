import { ISignatureVerifier } from '../../../../crypto/ISignatureVerifier.js';
import { Signature } from '../../../../crypto/secp256k1/Signature.js';
import { IEpochCommittee, ITrustBaseAuthority } from '../../trustbase/TrustBaseAuthority.js';
import { UnicitySeal } from '../../UnicitySeal.js';
import { CertificateVerificationResult } from '../CertificateVerdict.js';
import { VerifiedSealCache } from '../VerifiedSealCache.js';
/**
 * Rule to verify that a unicity seal is authenticated by the trust-base committee of its own epoch, with exactly the native B1 rule (bft-core
 * `b1ref`, the any-age bridge verifier), so that a wallet accepts exactly the seals the chain accepts:
 *
 * 1. **Format** (B1 refuses the input, `malformed`): at most {@link MAX_SIGNATURES} signatures; signer identifiers of at most
 *    {@link MAX_NODE_ID_BYTES} bytes; every signature 64 bytes `r‖s`, or 65 bytes `r‖s‖v` with `v` 0 or 1.
 * 2. **Authority**: signatures present; the seal's network; the committee of `seal.epoch` (an epoch after the latest held one is
 *    `no_entry_for_epoch`, retryable; one before the first held epoch is invalid); the root round inside the epoch's interval, `start ≤ r` and `r < end`
 *    once the next epoch is held.
 * 3. **Signatures**: every supplied signature is checked, with no early exit; an unknown signer, `r` or `s` out of range (`1 ≤ r < n`,
 *    `1 ≤ s ≤ n/2`) or a signature that does not verify against the member's listed key fails the seal even when the others reach the threshold;
 *    the verified members' weights must reach the committee threshold. The recovery byte is not trusted: a signature is valid when one of the four
 *    recovery bytes recovers the member's key, which is exactly ECDSA validity under that key (the carried byte is tried first).
 *
 * This is stricter than upstream O3 (which let an unknown or malformed extra signature count zero) and than the native shard path (which lets a known
 * member's invalid signature count zero): for honest seals all agree. Signature work dominates proof verification and every proof of an aggregator
 * round carries the same seal, so successes can be memoised in a caller-supplied {@link VerifiedSealCache}.
 */
export declare class UnicitySealQuorumSignaturesVerificationRule {
    private readonly signatureVerifier;
    private readonly cache?;
    static readonly MAX_NODE_ID_BYTES = 128;
    static readonly MAX_SIGNATURES = 16;
    /**
     * @param {ISignatureVerifier<Signature>} signatureVerifier Recovering secp256k1 verifier for the root-node signatures.
     * @param {VerifiedSealCache} [cache] Memo for verified seals; omit to verify every seal afresh.
     */
    constructor(signatureVerifier: ISignatureVerifier<Signature>, cache?: VerifiedSealCache | undefined);
    /**
     * The B1 format checks of a seal's signature map, independent of any authority.
     *
     * @param {UnicitySeal} seal Seal.
     * @returns {string|null} Why the seal is malformed, or null.
     */
    static checkSignatureFormat(seal: UnicitySeal): string | null;
    /**
     * Select the committee of the seal's epoch and check the seal's network and root round against it.
     *
     * @param {ITrustBaseAuthority} authority Held trust-base history.
     * @param {UnicitySeal} seal Seal.
     * @returns {IEpochCommittee|CertificateVerificationResult} The committee, or the failed check.
     */
    static selectCommittee(authority: ITrustBaseAuthority, seal: UnicitySeal): IEpochCommittee | CertificateVerificationResult;
    /**
     * The memo key commits to the committee record and its interval (a later held epoch closes an interval) and to the complete seal encoding,
     * signatures included (`calculateHash` excludes them, so it cannot be the key).
     *
     * @param {IEpochCommittee} committee Committee of the seal's epoch.
     * @param {UnicitySeal} unicitySeal Seal.
     * @returns {Promise<string>} Cache key.
     */
    private static cacheKeyFor;
    /**
     * Verify the seal against the committee of its epoch in the held history.
     *
     * @param {ITrustBaseAuthority} authority Held trust-base history.
     * @param {UnicitySeal} unicitySeal Seal to verify.
     * @returns {Promise<CertificateVerificationResult>} Verification outcome with its class.
     */
    verify(authority: ITrustBaseAuthority, unicitySeal: UnicitySeal): Promise<CertificateVerificationResult>;
    private verifySignature;
}
