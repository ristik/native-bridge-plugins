/**
 * Hash step in the certificate.
 */
export declare class HashStep {
    readonly key: bigint;
    private readonly _hash;
    constructor(key: bigint, _hash: Uint8Array);
    /**
     * Get the hash.
     */
    get hash(): Uint8Array;
    /**
     * Create hash step from CBOR bytes.
     *
     * @param bytes CBOR bytes
     * @return hash step
     */
    static fromCBOR(bytes: Uint8Array): HashStep;
    /**
     * Convert hash step to CBOR bytes.
     *
     * @return CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the UnicityTreeCertificate.
     * @returns The string representation.
     */
    toString(): string;
}
/**
 * Unicity tree certificate.
 */
export declare class UnicityTreeCertificate {
    readonly partitionIdentifier: bigint;
    private readonly _steps;
    private readonly nullList;
    static readonly CBOR_TAG = 39004n;
    private static readonly VERSION;
    /**
     * @param {bigint} partitionIdentifier Partition.
     * @param {HashStep[]} _steps Path steps.
     * @param {boolean} [nullList] The (empty) step list was encoded as CBOR null, as Go encodes a nil slice; kept so the bytes round-trip.
     */
    constructor(partitionIdentifier: bigint, _steps: HashStep[], nullList?: boolean);
    /**
     * Get the steps.
     */
    get steps(): HashStep[];
    /**
     * @returns {bigint} Wire-format version of this certificate.
     */
    get version(): bigint;
    /**
     * Create certificate from CBOR bytes.
     *
     * @param bytes CBOR bytes
     * @return certificate
     */
    static fromCBOR(bytes: Uint8Array): UnicityTreeCertificate;
    /**
     * Convert certificate to CBOR bytes.
     *
     * @return CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the UnicityTreeCertificate.
     * @returns The string representation.
     */
    toString(): string;
}
