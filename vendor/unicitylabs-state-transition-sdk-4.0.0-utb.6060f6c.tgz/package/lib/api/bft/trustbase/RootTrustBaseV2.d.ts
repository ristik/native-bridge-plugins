import { DataHash } from '../../../crypto/hash/DataHash.js';
import { RootTrustBase } from '../RootTrustBase.js';
/** One member of an epoch's root committee. */
export interface IRootTrustBaseV2Member {
    /** libp2p peer identifier of the member. */
    readonly nodeId: string;
    /** Compressed (33-byte) secp256k1 signing key. */
    readonly signingKey: Uint8Array;
    /** Voting weight, 1..2^40. */
    readonly weight: bigint;
}
/**
 * A Unicity Trust Base entry, record version 2: the root committee of one epoch, signed by the previous epoch's committee.
 *
 * Wire form (tag 39000, deterministic CBOR): `[2, networkId, epoch, epochStartRound, [[nodeId, signingKey, weight]…], quorumThreshold, stateHash,
 * changeRecordHash, previousEntryId, {nodeId → signature} | null]`. The entry's identity is {@link entryId} = SHA-256 of {@link sigBytes} (the entry
 * with the signature field encoded as null), so two valid signature subsets of one entry have the same identity. The genesis entry has a 32-byte
 * zero `previousEntryId` and null signatures; it is authenticated by a pin on its EntryID, never by signatures.
 *
 * Mirrors bft-go-base `types.RootTrustBaseV2` (ristik fork, bft-go-base#2): decoding is strict (exact tag, version and arity, canonical encoding
 * only, bounded sizes) and witness signatures follow the strict 65-byte recoverable rule.
 */
export declare class RootTrustBaseV2 {
    readonly networkId: number;
    readonly epoch: bigint;
    readonly epochStartRound: bigint;
    private readonly _rootNodes;
    readonly quorumThreshold: bigint;
    private readonly _stateHash;
    private readonly _changeRecordHash;
    private readonly _previousEntryId;
    private readonly _signatures;
    static readonly ID_LENGTH = 32;
    /** The admitted committee size: entries with more members are never stored (bft-core utb.MaxMembers). */
    static readonly MAX_ADMITTED_MEMBERS = 16;
    /** Largest encoded entry accepted anywhere (bft-core utbstore / GetTrustBase). */
    static readonly MAX_ENCODED_LENGTH: number;
    /** Member-list bound while decoding; deployments admit far fewer (see {@link MAX_ADMITTED_MEMBERS}). */
    static readonly MAX_MEMBERS = 256;
    static readonly MAX_NODE_ID_LENGTH = 128;
    static readonly MAX_WEIGHT: bigint;
    static readonly TAG = 39000n;
    static readonly VERSION = 2n;
    private constructor();
    /** @returns {Uint8Array|null} Copy of the change-record hash (null or 32 bytes). */
    get changeRecordHash(): Uint8Array | null;
    /** @returns {boolean} True when the predecessor id is 32 zero bytes. */
    get isGenesis(): boolean;
    /** @returns {Uint8Array} Copy of the predecessor's EntryID (32 zero bytes for the genesis entry). */
    get previousEntryId(): Uint8Array;
    /** @returns {IRootTrustBaseV2Member[]} Copy of the members, sorted by node identifier. */
    get rootNodes(): IRootTrustBaseV2Member[];
    /** @returns {Map<string, Uint8Array>|null} Copy of the witness signatures (null for the genesis entry). */
    get signatures(): Map<string, Uint8Array> | null;
    /** @returns {Uint8Array|null} Copy of the state hash (null or 32 bytes). */
    get stateHash(): Uint8Array | null;
    /** @returns {bigint} Total weight of the committee. */
    get totalWeight(): bigint;
    /**
     * Build an unsigned entry. Members are sorted by node identifier; the threshold is the caller's and is checked by {@link validate}.
     *
     * @param {object} fields Entry fields.
     * @param {number} fields.networkId Network identifier.
     * @param {bigint} fields.epoch Epoch number.
     * @param {bigint} fields.epochStartRound First root round of the epoch.
     * @param {IRootTrustBaseV2Member[]} fields.rootNodes Members.
     * @param {bigint} fields.quorumThreshold Threshold, floor(2W/3)+1.
     * @param {Uint8Array|null} fields.stateHash State hash (null or 32 bytes).
     * @param {Uint8Array|null} fields.changeRecordHash Change-record hash (null or 32 bytes).
     * @param {Uint8Array} fields.previousEntryId Predecessor EntryID (32 zero bytes for a genesis entry).
     * @returns {RootTrustBaseV2} The unsigned entry, shape-checked (sign it with {@link withSignatures} unless it is a genesis entry).
     * @throws {TrustBaseError} `invalid` for a structure rule.
     */
    static create(fields: {
        readonly changeRecordHash: Uint8Array | null;
        readonly epoch: bigint;
        readonly epochStartRound: bigint;
        readonly networkId: number;
        readonly previousEntryId: Uint8Array;
        readonly quorumThreshold: bigint;
        readonly rootNodes: readonly IRootTrustBaseV2Member[];
        readonly stateHash: Uint8Array | null;
    }): RootTrustBaseV2;
    /**
     * Strictly decode a tagged version-2 entry and check its structure ({@link validate}); signatures are not verified.
     *
     * @param {Uint8Array} bytes Tagged CBOR.
     * @returns {RootTrustBaseV2} The entry.
     * @throws {TrustBaseError} `malformed` for anything but the canonical encoding of a well-formed entry, `invalid` for a structure rule.
     */
    static fromCBOR(bytes: Uint8Array): RootTrustBaseV2;
    /**
     * The version-2 genesis entry of an on-disk (JSON, version 1) genesis trust base, as bft-core derives it (`utb.BuildUnsigned(nil,
     * utb.FromProjection(v1))`): the same network, epoch, start, members, weights and threshold, a zero predecessor and no signatures. The V1 signatures
     * are ignored: the genesis is authenticated by the pin on the returned entry's EntryID. Empty state and change-record hashes become CBOR null, the
     * one byte form of an absent hash.
     *
     * @param {RootTrustBase} legacy The JSON genesis trust base.
     * @returns {RootTrustBaseV2} The unsigned genesis entry.
     * @throws {TrustBaseError} `invalid` when the result breaks a version-2 rule (for example a threshold other than floor(2W/3)+1).
     */
    static genesisFromLegacy(legacy: RootTrustBase): RootTrustBaseV2;
    /**
     * @returns {Promise<Uint8Array>} The EntryID, SHA-256 of {@link sigBytes}: independent of the signatures.
     */
    entryId(): Promise<Uint8Array>;
    /**
     * @returns {Uint8Array} The signed preimage: the encoding with the signature field as CBOR null (not removed from the array).
     */
    sigBytes(): Uint8Array;
    /**
     * @returns {Uint8Array} The tagged deterministic CBOR encoding.
     */
    toCBOR(): Uint8Array;
    /**
     * {@link validateShape} plus the witness rule: the genesis carries null signatures, every other entry a non-empty signature map.
     *
     * @throws {TrustBaseError} `invalid` for the first violated rule.
     */
    validate(): void;
    /**
     * Check the entry's shape, without the witness rule (an unsigned entry passes, as bft-core `utbentry.ValidateShape`): epoch ≥ 1, members (sorted by
     * raw node-identifier bytes, unique, valid compressed keys, unique keys, positive bounded weights, bounded count), the exact threshold
     * floor(2W/3)+1, hash lengths and a 32-byte predecessor id.
     *
     * @throws {TrustBaseError} `invalid` for the first violated rule.
     */
    validateShape(): void;
    /**
     * Check the entry as the genesis: its structure and a zero predecessor. Its authority is a pin on its EntryID, which the caller compares.
     *
     * @throws {TrustBaseError} `invalid` or `genesis`.
     */
    verifyGenesis(): void;
    /**
     * Check signatures by this entry's members, strictly: every supplied signature must be from a member and valid (an unknown or invalid extra fails
     * even when the rest reach quorum), and the signers' weight must reach the threshold. A signature is exactly 65 bytes `r‖s‖v`, `1 ≤ r,s < n`,
     * low-S, `v` in 0..3, and the key it recovers must be the member's key.
     *
     * @param {DataHash} hash SHA-256 of the signed bytes.
     * @param {ReadonlyMap<string, Uint8Array>} signatures Node identifier → signature.
     * @throws {TrustBaseError} `invalid`.
     */
    verifyQuorumSignatures(hash: DataHash, signatures: ReadonlyMap<string, Uint8Array>): Promise<void>;
    /**
     * Check that this entry extends `previous`: valid structure, not a genesis, the same network, epoch previous+1, a later start round, the
     * predecessor's EntryID, and a strict quorum of the predecessor's members signing {@link sigBytes}.
     *
     * @param {RootTrustBaseV2} previous The authenticated predecessor.
     * @throws {TrustBaseError} `invalid`.
     */
    verifySuccessor(previous: RootTrustBaseV2): Promise<void>;
    /**
     * @param {ReadonlyMap<string, Uint8Array>|null} signatures Witness signatures.
     * @returns {RootTrustBaseV2} This entry with the given signature field.
     */
    withSignatures(signatures: ReadonlyMap<string, Uint8Array> | null): RootTrustBaseV2;
    private encode;
    private sigBytesHash;
}
