import { RootTrustBase } from '../RootTrustBase.js';
import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
import { IEpochCommittee, ITrustBaseAuthority } from './TrustBaseAuthority.js';
import { ITrustBaseResponseLimits, TrustBaseResponse } from './TrustBaseResponse.js';
import { NetworkId } from '../../NetworkId.js';
/** The latest held entry. */
export interface ITrustBaseTip {
    readonly entryId: Uint8Array;
    readonly epoch: bigint;
}
/** Budget for loading a shipped bundle (a release artifact, not a network page). */
export declare const DEFAULT_BUNDLE_LIMITS: ITrustBaseResponseLimits;
/**
 * The held Unicity Trust Base history: every entry from the pinned genesis forward, append-only.
 *
 * The latest held entry is effectively the pin (owner §29): a release ships the complete history known at release time, and every later entry is
 * verified from the latest held one and then anchors the next. {@link append} is the single way in, with exactly the rules of bft-core `utbstore`:
 *
 * - the next epoch is verified strictly from the held predecessor ({@link RootTrustBaseV2.verifySuccessor}) and the admitted member limit;
 * - an entry of a held epoch with the same unsigned bytes (same EntryID) and a valid witness is a no-op that keeps the held bytes; a different valid
 *   signature subset is not a fork;
 * - an entry of a held epoch with different unsigned bytes is a `conflict`; held entries are never replaced;
 * - an entry that does not directly follow the tip is a `gap`; nothing is skipped.
 */
export declare class TrustBaseHistory implements ITrustBaseAuthority {
    private readonly committees;
    private readonly entries;
    private readonly ids;
    private readonly raw;
    /** Serialises every mutation: each append runs its check, verification and push without another one interleaving at an `await`. */
    private writes;
    private constructor();
    /** @returns {bigint} The genesis epoch. */
    get genesisEpoch(): bigint;
    /** @returns {string} Network, genesis EntryID and latest EntryID: the held history in a cache or session key. */
    get identity(): string;
    /** @returns {NetworkId} The network. */
    get networkId(): NetworkId;
    /** @returns {ITrustBaseTip} The latest held entry. */
    get tip(): ITrustBaseTip;
    /** @returns {bigint} The latest held epoch. */
    get tipEpoch(): bigint;
    /**
     * A history loaded from a shipped bundle (tag 39015): the bundle's genesis must be the pinned one and every entry is appended through
     * {@link append}.
     *
     * @param {Uint8Array} bundle The bundle bytes.
     * @param {Uint8Array} pin The genesis EntryID.
     * @param {ITrustBaseResponseLimits} limits File budget.
     * @returns {Promise<TrustBaseHistory>} The history.
     * @throws {TrustBaseError} The first refusal.
     */
    static fromBundle(bundle: Uint8Array, pin: Uint8Array, limits?: ITrustBaseResponseLimits): Promise<TrustBaseHistory>;
    /**
     * A history holding the pinned genesis alone.
     *
     * @param {Uint8Array} genesis Canonical bytes of the genesis entry.
     * @param {Uint8Array} pin Its EntryID, the deployment's authenticated genesis identity.
     * @returns {Promise<TrustBaseHistory>} The history.
     * @throws {TrustBaseError} `malformed`, `invalid` or `genesis`.
     */
    static fromGenesis(genesis: Uint8Array, pin: Uint8Array): Promise<TrustBaseHistory>;
    /**
     * A history holding the version-2 genesis of an on-disk JSON (version 1) genesis trust base (owner D6), see
     * {@link RootTrustBaseV2.genesisFromLegacy}. The pin must come from the deployment's authenticated configuration, never from the file itself.
     *
     * @param {RootTrustBase} legacy The JSON genesis trust base.
     * @param {Uint8Array} pin EntryID of its version-2 genesis entry.
     * @returns {Promise<TrustBaseHistory>} The history.
     * @throws {TrustBaseError} `invalid` or `genesis`.
     */
    static fromLegacyGenesis(legacy: RootTrustBase, pin: Uint8Array): Promise<TrustBaseHistory>;
    /**
     * Append one entry given as its canonical bytes. Appends are serialised: concurrent calls (a piggybacked entry and a fetch, or two
     * verifications that both miss an epoch) take effect one after another, so an epoch is never stored twice.
     *
     * @param {Uint8Array} bytes Tagged entry.
     * @returns {Promise<boolean>} True when the entry was new; false for a no-op replay of a held entry.
     * @throws {TrustBaseError} `malformed` or `invalid` (refused), `gap`, or `conflict`.
     */
    append(bytes: Uint8Array): Promise<boolean>;
    /**
     * @param {bigint} epoch Epoch.
     * @returns {Uint8Array|null} The held canonical bytes of the epoch (a replay with another witness never replaces them), or null.
     */
    bytes(epoch: bigint): Uint8Array | null;
    /**
     * @param {bigint} epoch Epoch.
     * @returns {IEpochCommittee|null} The committee of a held epoch, with its round interval, or null.
     */
    committee(epoch: bigint): IEpochCommittee | null;
    /**
     * @param {bigint} epoch Epoch.
     * @returns {RootTrustBaseV2|null} The held entry of the epoch, or null when it is not held.
     */
    entry(epoch: bigint): RootTrustBaseV2 | null;
    /**
     * @returns {Promise<Uint8Array>} The whole held history as one bundle (tag 39015), to persist or ship.
     */
    exportBundle(): Promise<Uint8Array>;
    /**
     * Append the entries of a decoded bundle (or page) in order, as one serialised mutation (no other append interleaves); a refusal leaves the
     * history at the last good entry. An older bundle neither truncates nor rolls back the history.
     *
     * @param {TrustBaseResponse} bundle Decoded bundle or OK page.
     * @returns {Promise<number>} The number of new entries.
     * @throws {TrustBaseError} The first refusal.
     */
    installBundle(bundle: TrustBaseResponse): Promise<number>;
    /**
     * @returns {TrustBaseHistory} An immutable view of the held history: later appends to this history do not change it.
     */
    snapshot(): TrustBaseHistory;
    /** {@link append} while holding the write chain. */
    private appendExclusive;
    /**
     * Run a mutation after every earlier one has settled, whatever its outcome.
     *
     * @param {Function} task The mutation.
     * @returns {Promise<T>} Its result.
     */
    private exclusive;
}
