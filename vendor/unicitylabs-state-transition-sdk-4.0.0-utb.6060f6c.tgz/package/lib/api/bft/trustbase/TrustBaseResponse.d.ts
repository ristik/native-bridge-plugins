import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
/** Status of a GetTrustBase response. */
export declare enum TrustBaseResponseStatus {
    OK = 0,
    INVALID_REQUEST = 1,
    WRONG_NETWORK = 2,
    NOT_YET_AVAILABLE = 3,
    HISTORY_MISMATCH = 4,
    LIMIT_TOO_SMALL = 5,
    BUSY = 6,
    UNAVAILABLE = 7
}
/** Bounds of one response decode; `maxBytes` is checked before anything is decoded. */
export interface ITrustBaseResponseLimits {
    readonly maxBytes: number;
    readonly maxEntries: number;
}
/**
 * The GetTrustBase response, which is also the release bundle format: tag 39015 (provisional; bft-core `gettrustbase.ResponseTag`),
 * `[version=1, network, status, fromEpoch, effectiveEnd, endEntryId | null, [entry…], nextEpoch | null]`, entries embedded verbatim as their canonical
 * tagged bytes.
 *
 * Mirrors bft-core `gettrustbase.Response`, `DecodeResponse` and `DecodeBundle`.
 */
export declare class TrustBaseResponse {
    readonly networkId: number;
    readonly status: TrustBaseResponseStatus;
    readonly fromEpoch: bigint;
    readonly effectiveEnd: bigint;
    private readonly _endEntryId;
    private readonly _rawEntries;
    readonly nextEpoch: bigint | null;
    readonly entries: readonly RootTrustBaseV2[];
    /** Peer page caps (bft-core `gettrustbase.PageLimits`). */
    static readonly PAGE_LIMITS: ITrustBaseResponseLimits;
    /** Provisional tag, as bft-core `gettrustbase.ResponseTag`. */
    static readonly TAG = 39015n;
    static readonly VERSION = 1n;
    private constructor();
    /** @returns {Uint8Array|null} Copy of the EntryID of `effectiveEnd`. */
    get endEntryId(): Uint8Array | null;
    /** @returns {Uint8Array[]} Copies of the entries' canonical bytes. */
    get rawEntries(): Uint8Array[];
    /**
     * Strictly decode a complete bundle: status OK, starting at a genesis entry, no cursor, consecutive entries linked by predecessor EntryID up to
     * `effectiveEnd` with the matching end id, nothing after. Structure and links only; see {@link verifyBundle} for the signatures.
     *
     * @param {Uint8Array} bytes Tagged CBOR.
     * @param {ITrustBaseResponseLimits} limits File budget (not the page caps).
     * @returns {Promise<TrustBaseResponse>} The bundle.
     * @throws {TrustBaseError} `malformed` or `bundle`.
     */
    static decodeBundle(bytes: Uint8Array, limits: ITrustBaseResponseLimits): Promise<TrustBaseResponse>;
    /**
     * Encode the complete history (ascending from the genesis) as a release bundle, after checking it with the same decoder that loads it.
     *
     * @param {Uint8Array[]} rawEntries Canonical entry bytes, the genesis first.
     * @returns {Promise<Uint8Array>} The bundle.
     * @throws {TrustBaseError} `bundle` or `malformed` for a gap, duplicate or broken link.
     */
    static encodeBundle(rawEntries: readonly Uint8Array[]): Promise<Uint8Array>;
    /**
     * Strictly decode a response and check its internal consistency: status and cursor rules, and for an OK page a contiguous ascending run of
     * structurally valid entries of the response's network, linked by predecessor EntryID, ending at `effectiveEnd` when no cursor remains.
     * Signatures are not verified here; the history verifies each entry when it is appended.
     *
     * @param {Uint8Array} bytes Tagged CBOR.
     * @param {ITrustBaseResponseLimits} limits Bounds.
     * @returns {Promise<TrustBaseResponse>} The response.
     * @throws {TrustBaseError} `malformed`.
     */
    static fromCBOR(bytes: Uint8Array, limits?: ITrustBaseResponseLimits): Promise<TrustBaseResponse>;
    /**
     * The offline bundle check: the genesis must be the pinned identity and every later entry must carry a strict quorum of its predecessor's members.
     *
     * @param {TrustBaseResponse} bundle A decoded bundle.
     * @param {Uint8Array} pin The genesis EntryID.
     * @throws {TrustBaseError} `genesis` or `invalid`.
     */
    static verifyBundle(bundle: TrustBaseResponse, pin: Uint8Array): Promise<void>;
    private static checkPage;
    /**
     * @returns {Uint8Array} The tagged deterministic CBOR encoding.
     */
    toCBOR(): Uint8Array;
    private withEntries;
}
