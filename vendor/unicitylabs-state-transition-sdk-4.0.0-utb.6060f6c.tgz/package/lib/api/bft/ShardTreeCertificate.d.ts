import { ShardId } from './ShardId.js';
/**
 * Shard tree certificate.
 */
export declare class ShardTreeCertificate {
    private readonly _shard;
    private readonly _siblingHashList;
    private readonly nullList;
    static readonly CBOR_TAG = 39003n;
    private static readonly VERSION;
    /**
     * @param {ShardId} _shard Shard.
     * @param {Uint8Array[]} _siblingHashList Sibling hashes, one per shard bit.
     * @param {boolean} [nullList] The (empty) list was encoded as CBOR null, as Go encodes a nil slice; kept so the bytes round-trip.
     */
    constructor(_shard: ShardId, _siblingHashList: Uint8Array[], nullList?: boolean);
    /**
     * Get the shard.
     */
    get shard(): ShardId;
    /**
     * Get the sibling hash list.
     */
    get siblingHashList(): Uint8Array[];
    /**
     * @returns {bigint} Wire-format version of this certificate.
     */
    get version(): bigint;
    /**
     * Create shard tree certificate from CBOR bytes.
     *
     * @param bytes CBOR bytes
     * @return shard tree certificate
     */
    static fromCBOR(bytes: Uint8Array): ShardTreeCertificate;
    /**
     * Convert shard tree certificate to CBOR bytes.
     *
     * @return CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the ShardTreeCertificate.
     * @returns The string representation.
     */
    toString(): string;
}
