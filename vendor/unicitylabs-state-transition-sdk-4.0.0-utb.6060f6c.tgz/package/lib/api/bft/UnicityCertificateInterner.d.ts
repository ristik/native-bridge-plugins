import type { UnicityCertificate } from './UnicityCertificate.js';
/**
 * Work counters of a {@link UnicityCertificateInterner}.
 */
export interface IInternerStats {
    /** Occurrences served from an earlier parse of the same complete bytes. */
    readonly hits: number;
    /** Actual parses. */
    readonly parses: number;
}
/**
 * Decodes each distinct wire unicity certificate once per decoding operation.
 *
 * Every proof of a consolidated token carries a copy of the same certificate, so decoding L proofs would parse the same
 * bytes L times. Reading the L copies is unavoidable, parsing them again is not: occurrences are matched by their
 * **complete** bytes (never a signature-excluding hash), only successful parses are remembered, and the memo is bounded
 * and scoped to the interner, i.e. to one token, batch or other decoding operation. Proofs decoded through one interner
 * share the certificate instance, which is immutable through its API.
 */
export declare class UnicityCertificateInterner {
    private readonly parse;
    private readonly maxEntries;
    private readonly counters;
    private readonly entries;
    /**
     * @param {Function} parse Parser of one wire certificate.
     * @param {number} [maxEntries] Upper bound on remembered certificates, the oldest is dropped first.
     * @throws {Error} If `maxEntries` is not a positive integer.
     */
    constructor(parse: (bytes: Uint8Array) => UnicityCertificate, maxEntries?: number);
    /**
     * @returns {IInternerStats} Snapshot of the counters.
     */
    get stats(): IInternerStats;
    /**
     * @param {Uint8Array} bytes Complete wire certificate.
     * @returns {UnicityCertificate} The decoded certificate, parsed at most once per distinct complete bytes.
     * @throws {CborError} If the bytes are not a certificate (failures are not remembered).
     */
    decode(bytes: Uint8Array): UnicityCertificate;
}
