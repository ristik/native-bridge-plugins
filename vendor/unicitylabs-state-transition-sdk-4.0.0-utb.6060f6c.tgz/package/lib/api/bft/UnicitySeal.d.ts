import { DataHash } from '../../crypto/hash/DataHash.js';
import { Signature } from '../../crypto/secp256k1/Signature.js';
import { SigningService } from '../../crypto/secp256k1/SigningService.js';
import { NetworkId } from '../NetworkId.js';
/**
 * UnicitySeal represents a seal in the Unicity BFT system, containing metadata and signatures.
 */
export declare class UnicitySeal {
    readonly networkId: NetworkId;
    readonly rootChainRoundNumber: bigint;
    readonly epoch: bigint;
    readonly timestamp: bigint;
    private readonly _previousHash;
    private readonly _hash;
    private readonly _witnesses;
    static readonly CBOR_TAG = 39005n;
    private static readonly VERSION;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the seal hash bytes.
     */
    get hash(): Uint8Array;
    /**
     * @returns {Uint8Array|null} Copy of the previous-seal hash, or `null` if absent.
     */
    get previousHash(): Uint8Array | null;
    /**
     * The signatures that are well-formed (65 bytes, recovery id 0..3), by signer. A carried witness that is not
     * (see {@link UnicitySeal.witnesses}) is not listed here: it is kept in the seal, re-encoded and hashed unchanged,
     * but it can never count as a vote.
     *
     * @returns {Map<string, Signature>|null} Signer-to-signature map, or `null` if the seal carries no signature map.
     */
    get signatures(): Map<string, Signature> | null;
    /**
     * @returns {bigint} Wire-format version of this seal.
     */
    get version(): bigint;
    /**
     * Every carried signature witness exactly as received: the byte string of each map entry, well-formed or not. The
     * quorum rule decodes each one strictly and counts a malformed one as zero votes, like the Go and Rust clients.
     *
     * @returns {Map<string, Uint8Array>|null} Copy of the signer-to-witness map, or `null` if the seal carries none.
     */
    get witnesses(): Map<string, Uint8Array> | null;
    /**
     * Create a UnicitySeal and sign it with the given signing services.
     *
     * @param {NetworkId} networkId Network identifier.
     * @param {bigint} rootChainRoundNumber Root-chain round number.
     * @param {bigint} epoch Epoch number.
     * @param {bigint} timestamp Timestamp.
     * @param {Uint8Array|null} _previousHash Previous-seal hash, or `null` for the first seal.
     * @param {Uint8Array} _hash Hash being sealed.
     * @param {Map<string, SigningService>} signers Signing services keyed by signer id.
     * @returns {Promise<UnicitySeal>} Signed seal.
     */
    static create(networkId: NetworkId, rootChainRoundNumber: bigint, epoch: bigint, timestamp: bigint, _previousHash: Uint8Array | null, _hash: Uint8Array, signers: Map<string, SigningService>): Promise<UnicitySeal>;
    /**
     * Create unicity seal from CBOR bytes.
     *
     * @param bytes CBOR bytes
     * @return unicity seal
     * @throws {CborError} On malformed CBOR. A signature entry that is a byte string of any length is kept as it is,
     *   including one that is not a valid signature encoding (it counts as zero votes in the quorum rule).
     */
    static fromCBOR(bytes: Uint8Array): UnicitySeal;
    /**
     * A signer identifier is UTF-8 text: anything else is malformed, as natively (CBOR text with invalid UTF-8 is refused).
     *
     * @param {Uint8Array} data CBOR text string.
     * @returns {string} The identifier.
     * @throws {CborError} If the text is not valid UTF-8.
     */
    private static decodeSignerId;
    /**
     * @returns {Promise<DataHash>} Hash of this seal, computed without the signatures.
     */
    calculateHash(): Promise<DataHash>;
    /**
     * Convert unicity seal to CBOR bytes.
     *
     * @return CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the UnicitySeal.
     * @returns The string representation.
     */
    toString(): string;
}
