/**
 * Input record for UnicityCertificate.
 */
export declare class InputRecord {
    readonly roundNumber: bigint;
    readonly epoch: bigint;
    private readonly _previousHash;
    private readonly _hash;
    private readonly _summaryValue;
    readonly timestamp: bigint;
    private readonly _blockHash;
    readonly sumOfEarnedFees: bigint;
    private readonly _executedTransactionsHash;
    static readonly CBOR_TAG = 39002n;
    private static readonly VERSION;
    constructor(roundNumber: bigint, epoch: bigint, _previousHash: Uint8Array | null, _hash: Uint8Array | null, _summaryValue: Uint8Array | null, timestamp: bigint, _blockHash: Uint8Array | null, sumOfEarnedFees: bigint, _executedTransactionsHash: Uint8Array | null);
    /**
     * Get the block hash.
     */
    get blockHash(): Uint8Array | null;
    /**
     * Get the executed transactions hash.
     */
    get executedTransactionsHash(): Uint8Array | null;
    /**
     * Get the hash. Empty when the native record carries CBOR null (initial state), so an empty result is NOT a hash and
     * two records with null hashes must never be treated as equal roots.
     *
     * @deprecated Use {@link InputRecord.nullableHash}, which tells null from a value.
     */
    get hash(): Uint8Array;
    /**
     * Get the hash, `null` if the native record carries CBOR null (distinct from an empty byte string).
     */
    get nullableHash(): Uint8Array | null;
    /**
     * Get the summary value, `null` if the native record carries CBOR null (distinct from an empty byte string).
     */
    get nullableSummaryValue(): Uint8Array | null;
    /**
     * Get the previous hash.
     */
    get previousHash(): Uint8Array | null;
    /**
     * Get the summary value. Empty when the native record carries CBOR null, see {@link nullableSummaryValue}.
     *
     * @deprecated Use {@link InputRecord.nullableSummaryValue}, which tells null from a value.
     */
    get summaryValue(): Uint8Array;
    /**
     * @returns {bigint} Wire-format version of this input record.
     */
    get version(): bigint;
    /**
     * Create InputRecord from CBOR bytes.
     *
     * @param bytes CBOR bytes
     * @return input record
     */
    static fromCBOR(bytes: Uint8Array): InputRecord;
    /**
     * Native structural validity (bft-go-base `InputRecord.IsValid`), which is conditional: from round 1 the summary value
     * must not be null and the timestamp must be assigned; if the state hash did not change the block hash must be nil
     * (null or empty), and if it changed the block hash must not be nil. A null field alone is not malformed, only these
     * combinations are (a null summary is legal at round 0, an empty block hash is required for an unchanged state).
     *
     * @returns {string|null} Failure description, or `null` if the record is structurally valid.
     */
    structureFailure(): string | null;
    /**
     * Convert InputRecord to CBOR bytes.
     *
     * @return CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the InputRecord.
     * @returns The string representation.
     */
    toString(): string;
}
