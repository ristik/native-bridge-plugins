import { PartitionView, IPartitionViewPolicy, PartitionViewLeaf } from './PartitionView.js';
import { ShardId } from './ShardId.js';
import { UnicityCertificate } from './UnicityCertificate.js';
import { UnicitySeal } from './UnicitySeal.js';
import { ISealAuthenticator } from './verification/ISealAuthenticator.js';
import { ShardTree } from '../../internal/bft/ShardTree.js';
import { NetworkId } from '../NetworkId.js';
/** Capability to construct, held by this module only (the symbol is not exported). */
declare const AUTHENTICATED: unique symbol;
interface IAuthenticatedParts {
    readonly authority: string;
    readonly enclosing: Uint8Array;
    readonly leaves: readonly Uint8Array[];
    readonly partitionId: bigint;
    readonly policy: string;
    readonly tree: ShardTree;
}
/**
 * Partition view whose complete content is committed by an authenticated seal.
 *
 * Instances come only from {@link PartitionViewAuthenticator.authenticate}, after the view hashed into the enclosing
 * certificate's partition path and seal hash, matched the enclosing certificate's own leaf exactly, and the complete
 * seal was authenticated under the verifier's anchored authority (network, exact epoch, round at least the epoch
 * start, quorum). There is no flag or map a caller can supply to obtain one, and no reachable factory.
 *
 * Immutable and independent of every object graph it was built from or hands out: it holds only private canonical
 * bytes and the private authenticated shard tree, all snapshotted before verification, and every accessor builds fresh
 * copies. Per-shard work is lazy and indexed: a lookup decodes and derives only that shard's leaf and certificate
 * (O(1) leaves, O(depth) hashes already held by the tree), not the whole view, and nothing is derived for shards nobody
 * asks for.
 *
 * The committed scheme and configuration hashes are authenticated by the commitment itself, they are not taken from
 * the response on trust and no independent hash list is required.
 */
export declare class AuthenticatedPartitionView {
    #private;
    /** Identity of the anchored authority and verifier policy the seal was authenticated under. */
    readonly authority: string;
    /** Partition id. */
    readonly partitionId: bigint;
    /** Identity of the optional pins applied during authentication. */
    readonly policy: string;
    /**
     * Not callable outside this module, use {@link PartitionViewAuthenticator.authenticate}.
     *
     * @param {symbol} capability Module private capability.
     * @param {IAuthenticatedParts} parts Verified parts, canonical bytes.
     */
    constructor(capability: typeof AUTHENTICATED, parts: IAuthenticatedParts);
    /**
     * @returns {PartitionViewLeaf[]} Independent copies of the committed leaves in canonical order.
     */
    get leaves(): PartitionViewLeaf[];
    /**
     * @returns {NetworkId} Network of the authenticated seal.
     */
    get networkId(): NetworkId;
    /**
     * @returns {ShardId[]} Committed sharding scheme, empty for a single shard partition.
     */
    get scheme(): ShardId[];
    /**
     * @returns {UnicitySeal} Independent copy of the complete authenticated seal.
     */
    get seal(): UnicitySeal;
    /**
     * Ordinary version 1 unicity certificates of every shard in canonical order, each carrying the shared partition
     * certificate and the identical complete master seal. Shards in their initial state keep their native null input
     * record fields. Every call returns independent objects. Derives all S certificates; use
     * {@link AuthenticatedPartitionView.certificateOf} for the shards that are needed.
     *
     * @returns {UnicityCertificate[]} Certificates.
     */
    assembleCertificates(): UnicityCertificate[];
    /**
     * @param {ShardId} shard Shard of the partition.
     * @returns {UnicityCertificate} Independent copy of the certificate of the shard.
     * @throws {Error} If the shard is not committed by the view.
     */
    certificateOf(shard: ShardId): UnicityCertificate;
    /**
     * Independent copy of one committed leaf, found through the private index: decodes only that leaf.
     *
     * @param {ShardId} shard Shard of the partition.
     * @returns {PartitionViewLeaf} Leaf of the shard.
     * @throws {Error} If the shard is not committed by the view.
     */
    leafOf(shard: ShardId): PartitionViewLeaf;
    /** One shard's certificate from its leaf, the authenticated tree and the shared partition path and seal. */
    private derive;
}
/**
 * Turns an untrusted candidate {@link PartitionView} into an {@link AuthenticatedPartitionView}.
 *
 * Steps: structural validation of the candidate (distinct valid prefixes, complete coverage, canonical order, optional
 * pins), shard tree rebuild and partition path evaluation to the seal hash (nil path steps rejected), exact match of
 * the enclosing certificate's own leaf, then authentication of the complete seal by the anchored authority. The
 * authority is the caller's, never derived from the response.
 *
 * Optional pins (scheme, per-shard configuration hashes) are a stricter policy. They are deep-copied at construction;
 * the same private snapshot is applied to every check and produces {@link PartitionViewAuthenticator.identity}, which
 * keys the bounded memo of authenticated views and should key any cache derived from them. Inputs are snapshotted to
 * private canonical bytes before any asynchronous work.
 */
export declare class PartitionViewAuthenticator {
    #private;
    private readonly sealAuthenticator;
    private static readonly MAX_ENTRIES;
    private readonly completed;
    private readonly inFlight;
    /** The partition every view is authenticated for: fixed, never chosen by the caller or the response. */
    private readonly partition;
    private readonly pins;
    private readonly policyId;
    /**
     * @param {ISealAuthenticator} sealAuthenticator Authenticates the master seal under the anchored authority.
     * @param {IPartitionViewPolicy} [policy] Optional stricter pins, copied.
     */
    constructor(sealAuthenticator: ISealAuthenticator, policy?: IPartitionViewPolicy);
    /**
     * @returns {string} Identity of partition, authority and pins; part of any cache or session key.
     */
    get identity(): string;
    /**
     * Authenticate a candidate view against its enclosing certificate. The arguments are snapshotted first, later
     * mutation of the caller's buffers or objects cannot affect the outcome or the result.
     *
     * @param {PartitionView | Uint8Array} candidate Candidate view or its bytes.
     * @param {UnicityCertificate | Uint8Array} enclosing Certificate (or its bytes) carrying the seal.
     * @returns {Promise<AuthenticatedPartitionView>} Authenticated view.
     * @throws {PartitionViewError} If any check fails.
     */
    authenticate(candidate: PartitionView | Uint8Array, enclosing: UnicityCertificate | Uint8Array): Promise<AuthenticatedPartitionView>;
}
export {};
