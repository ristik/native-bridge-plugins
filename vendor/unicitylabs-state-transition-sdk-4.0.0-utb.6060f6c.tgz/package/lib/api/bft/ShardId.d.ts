/**
 * Shard identifier.
 */
export declare class ShardId {
    private readonly _bits;
    readonly length: number;
    /** The empty shard id, the only shard of an unsharded partition (encoded `80`). */
    static readonly ROOT: ShardId;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the bit-string bytes.
     */
    get bits(): Uint8Array;
    /**
     * Decode a ShardId from its byte encoding.
     *
     * @param {Uint8Array} data Encoded bytes.
     * @returns {ShardId} Decoded shard id.
     * @throws {CborError} If the encoding is invalid.
     */
    static decode(data: Uint8Array): ShardId;
    /**
     * Build a shard id from its bit string, e.g. `'01'`; the empty string is {@link ShardId.ROOT}.
     *
     * @param {string} bits Bit string of `0` and `1`, at most 256 bits.
     * @returns {ShardId} Shard id.
     * @throws {RangeError} If `bits` is not a bit string within the limit.
     */
    static fromBits(bits: string): ShardId;
    /**
     * @returns {Uint8Array} Encoded shard id bytes.
     */
    encode(): Uint8Array;
    /**
     * Compare with another shard id by value.
     *
     * @param {ShardId} other Other shard id.
     * @returns {boolean} True if both have the same length and bits.
     */
    equals(other: ShardId): boolean;
    /**
     * Return the bit at the given index.
     *
     * @param {number} index Bit index, zero-based.
     * @returns {number} The bit value (0 or 1).
     * @throws {Error} If the index is out of bounds.
     */
    getBit(index: number): number;
    /**
     * Check whether this shard id is a bit-prefix of the given data.
     *
     * @param {Uint8Array} data Bytes to test.
     * @returns {boolean} True if this shard id is a prefix of `data`.
     */
    isPrefixOf(data: Uint8Array): boolean;
    /**
     * @returns {string} Binary string representation of the shard id.
     */
    toString(): string;
}
