import { InputRecord } from './InputRecord.js';
import { ShardTreeCertificate } from './ShardTreeCertificate.js';
import { UnicityCertificateInterner } from './UnicityCertificateInterner.js';
import { UnicitySeal } from './UnicitySeal.js';
import { UnicityTreeCertificate } from './UnicityTreeCertificate.js';
import { DataHash } from '../../crypto/hash/DataHash.js';
/**
 * Unicity certificate.
 */
export declare class UnicityCertificate {
    readonly inputRecord: InputRecord;
    private readonly _technicalRecordHash;
    private readonly _shardConfigurationHash;
    readonly shardTreeCertificate: ShardTreeCertificate;
    readonly unicityTreeCertificate: UnicityTreeCertificate;
    readonly unicitySeal: UnicitySeal;
    static readonly CBOR_TAG = 39001n;
    private static readonly VERSION;
    constructor(inputRecord: InputRecord, _technicalRecordHash: Uint8Array | null, _shardConfigurationHash: Uint8Array, shardTreeCertificate: ShardTreeCertificate, unicityTreeCertificate: UnicityTreeCertificate, unicitySeal: UnicitySeal);
    /**
     * @returns {Uint8Array} Copy of the shard configuration hash.
     */
    get shardConfigurationHash(): Uint8Array;
    /**
     * @returns {Uint8Array|null} Copy of the technical record hash, or `null` if absent.
     */
    get technicalRecordHash(): Uint8Array | null;
    /**
     * @returns {bigint} Wire-format version of this certificate.
     */
    get version(): bigint;
    /**
     * Calculate the shard tree leaf hash: the hash of the committed input record, technical record hash and shard
     * configuration hash.
     *
     * @param {InputRecord} inputRecord            input record
     * @param {Uint8Array | null} technicalRecordHash    technical record hash
     * @param {Uint8Array} shardConfigurationHash shard configuration hash
     * @return leaf hash
     */
    static calculateShardLeafHash(inputRecord: InputRecord, technicalRecordHash: Uint8Array | null, shardConfigurationHash: Uint8Array): Promise<DataHash>;
    /**
     * Calculate the root hash of the shard tree certificate.
     *
     * @param {InputRecord} inputRecord            input record
     * @param {Uint8Array | null} technicalRecordHash    technical record hash
     * @param {Uint8Array} shardConfigurationHash shard configuration hash
     * @param {ShardTreeCertificate} shardTreeCertificate   shard tree certificate
     * @return root hash
     */
    static calculateShardTreeCertificateRootHash(inputRecord: InputRecord, technicalRecordHash: Uint8Array | null, shardConfigurationHash: Uint8Array, shardTreeCertificate: ShardTreeCertificate): Promise<DataHash>;
    /**
     * Create unicity certificate from CBOR bytes within a decoding operation: a certificate with the same complete bytes
     * is parsed once per interner.
     *
     * @param bytes CBOR bytes
     * @param interner Decoding operation, or none to parse every occurrence.
     * @return unicity certificate
     */
    static decodeWith(bytes: Uint8Array, interner?: UnicityCertificateInterner): UnicityCertificate;
    /**
     * Create unicity certificate from CBOR bytes.
     *
     * @param bytes CBOR bytes
     * @return unicity certificate
     */
    static fromCBOR(bytes: Uint8Array): UnicityCertificate;
    /**
     * Create UnicityCertificate from JSON.
     *
     * @param {unknown} data Hex string of CBOR-encoded certificate.
     * @returns {UnicityCertificate} Decoded certificate.
     * @throws {InvalidJsonStructureError} If the input is not a string.
     */
    static fromJSON(data: unknown): UnicityCertificate;
    private static isJSON;
    /**
     * Convert unicity certificate to CBOR bytes.
     *
     * @return CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the UnicityCertificate.
     * @returns The string representation.
     */
    toString(): string;
}
