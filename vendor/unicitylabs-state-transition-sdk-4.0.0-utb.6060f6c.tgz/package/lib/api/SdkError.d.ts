declare const BRAND: unique symbol;
/**
 * Base of the errors of the newer SDK APIs.
 *
 * Every subclass has a **literal** `name`, so `error.name` narrows in a type guard, and every instance carries a
 * registry-wide brand, so that {@link SdkError.is} still recognizes an error that was created by another copy of the SDK
 * in the same bundle (where `instanceof` fails). Use the subclass's own `is()` (or its discriminant) to narrow further.
 */
export declare abstract class SdkError<N extends string = string> extends Error {
    readonly [BRAND]: true;
    abstract readonly name: N;
    /**
     * @param {unknown} error Anything that was thrown.
     * @returns {boolean} True for an error created by this or another copy of the SDK.
     */
    static is(error: unknown): error is SdkError;
}
export {};
