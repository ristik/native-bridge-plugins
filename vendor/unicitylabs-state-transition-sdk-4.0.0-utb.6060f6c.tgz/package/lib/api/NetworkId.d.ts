/**
 * Unicity network identifier (α). Used to scope token ids and other
 * network-bound values so they cannot be replayed across networks.
 */
export declare class NetworkId {
    readonly id: number;
    private readonly name?;
    static readonly LOCAL: NetworkId;
    static readonly MAINNET: NetworkId;
    /** testnet2: network 4, as its published genesis trust base (unicity-ids `bft-trustbase.testnet2.json`). */
    static readonly TESTNET: NetworkId;
    private constructor();
    /**
     * Resolve a NetworkId from its numeric identifier. Returns the registered
     * singleton for known ids; constructs a new (unnamed) instance for any
     * other value in the 16-bit unsigned range.
     *
     * @param {number|bigint} id Numeric network identifier.
     * @returns {NetworkId} NetworkId for the given identifier.
     * @throws {Error} If `id` is outside the 16-bit unsigned range.
     */
    static fromId(id: number | bigint): NetworkId;
    /**
     * Equality check against another NetworkId.
     *
     * @param {NetworkId} other Other network identifier.
     * @returns {boolean} True if both share the same numeric id.
     */
    equals(other: NetworkId): boolean;
    /**
     * @returns {string} `NetworkId[<name>]` for registered networks, `NetworkId[<id>]` otherwise.
     */
    toString(): string;
}
