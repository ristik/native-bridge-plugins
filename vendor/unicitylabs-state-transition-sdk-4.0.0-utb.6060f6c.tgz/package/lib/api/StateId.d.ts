import { CertificationData } from './CertificationData.js';
import { ITransaction } from '../transaction/ITransaction.js';
/**
 * Represents a unique state identifier derived from a public key and state hash.
 */
export declare class StateId {
    private readonly hash;
    private constructor();
    /**
     * @returns {Uint8Array} Underlying state-id hash bytes.
     */
    get data(): Uint8Array;
    /**
     * Create StateId from CBOR bytes.
     *
     * @param {Uint8Array} bytes CBOR bytes.
     * @returns {StateId} Decoded state id.
     */
    static fromCBOR(bytes: Uint8Array): StateId;
    /**
     * Create StateId from certification data.
     *
     * @param {CertificationData} certificationData Certification data.
     * @returns {Promise<StateId>} Derived state id.
     */
    static fromCertificationData(certificationData: CertificationData): Promise<StateId>;
    /**
     * Create StateId from a transaction's lock script and source state hash.
     *
     * @param {ITransaction} transaction Transaction.
     * @returns {Promise<StateId>} Derived state id.
     */
    static fromTransaction(transaction: ITransaction): Promise<StateId>;
    /**
     * Creates a StateId from a public key and state hash.
     * @param predicate predicate as a Uint8Array.
     * @param stateHash state hash.
     * @returns A Promise resolving to a StateId instance.
     */
    private static create;
    /**
     * Equality check against another state id.
     *
     * @param {StateId} id Other state id.
     * @returns {boolean} True if the two state ids share the same hash.
     */
    equals(id: StateId): boolean;
    /**
     * Convert StateId to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes.
     */
    toCBOR(): Uint8Array;
    /**
     * @returns {string} String representation of the state id.
     */
    toString(): string;
}
