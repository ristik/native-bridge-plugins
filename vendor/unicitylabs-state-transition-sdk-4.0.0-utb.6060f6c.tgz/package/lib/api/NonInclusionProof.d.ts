import { UnicityCertificate } from './bft/UnicityCertificate.js';
import { NonInclusionCertificate } from './NonInclusionCertificate.js';
import { StateId } from './StateId.js';
/**
 * Decoded `get_non_inclusion_proof.v1` material. **This is not evidence.** It claims that the state was absent at the
 * snapshot the embedded unicity certificate certifies; only `verifyNonInclusion`, against a trusted authority, turns it
 * into a verified snapshot outcome (`absent_at_snapshot` or `included_at_snapshot`).
 *
 * Wire: `[blockNumber: uint64, 39034([1, certificate: bstr, unicityCertificate: native tagged CBOR value])]`. The state
 * id is never read from the wire: it is the one the caller asked for, bound here when the proof is decoded, and a proof
 * can only be verified for that state.
 *
 * Non-inclusion proves absence only at the authenticated snapshot returned by verification. It does not prove absence
 * now, continuous absence, or that a token can be spent. Compare the snapshot’s network and root round (or its
 * certified seal timestamp under your application’s time policy) with an independently trusted requirement. The seal
 * timestamp is a consensus-certified time, not proof of real-time freshness. Do not use unverified response metadata
 * for this check.
 */
export declare class NonInclusionProof {
    readonly stateId: StateId;
    readonly unauthenticatedBlockNumber: bigint;
    private readonly _certificate;
    private readonly _unicityCertificate;
    /** CBOR tag of the proof. */
    static readonly CBOR_TAG = 39034n;
    /** Largest accepted wire encoding (certificate, certificate of the unicity chain and signatures), before decoding. */
    static readonly MAX_WIRE_BYTES: number;
    /** Version of the proof encoding. */
    static readonly VERSION = 1n;
    private constructor();
    /**
     * @returns {NonInclusionCertificate} The decoded certificate.
     */
    get certificate(): NonInclusionCertificate;
    /**
     * @returns {UnicityCertificate} A fresh decoding of the embedded unicity certificate (untrusted until verified).
     */
    get unicityCertificate(): UnicityCertificate;
    /**
     * Decode the result of `get_non_inclusion_proof.v1` for a state that was asked about, completely and strictly: no
     * trailing bytes, shortest integers, the certificate as a byte string, the unicity certificate as an embedded value
     * with exactly its canonical encoding, certificate within its size bound.
     *
     * @param {StateId} stateId The state the request was for.
     * @param {Uint8Array} bytes Wire bytes (copied).
     * @returns {NonInclusionProof} Decoded, unverified proof.
     * @throws {CborError|RangeError} If the bytes are not the profile.
     */
    static decode(stateId: StateId, bytes: Uint8Array): NonInclusionProof;
    /**
     * @returns {Uint8Array} Wire bytes of the proof, byte for byte what was decoded.
     */
    toCBOR(): Uint8Array;
}
