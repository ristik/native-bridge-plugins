import { StateId } from './StateId.js';
/** What a non-inclusion certificate says about a key relative to one root. */
export type NonInclusionRelation = 'absent' | 'certificate_invalid' | 'state_included';
/**
 * The raw certificate of `get_non_inclusion_proof.v1`: the authenticated terminal leaf reached by walking the query at
 * every actual junction of the compressed radix tree, with the sibling hashes of the junctions.
 *
 * Wire bytes (the profile of rugregator, aggregator-go and the Rust SDK): empty is the certified empty tree; otherwise
 * exactly `bitmap[32] || sibling[32] * popcount(bitmap) || terminalKey[32] || terminalValue[32]`, which is
 * `96 + 32 * popcount` bytes and at most {@link NonInclusionCertificate.MAX_BYTES}. The query key is not part of it.
 *
 * This is only a codec and a path fold. It does not authenticate anything: the root it is checked against must come from
 * an authenticated certificate, see `verifyNonInclusion`.
 */
export declare class NonInclusionCertificate {
    private readonly bitmap;
    private readonly siblings;
    private readonly terminalKey;
    private readonly terminalValue;
    /** Largest valid certificate: 256 junctions. */
    static readonly MAX_BYTES: number;
    private constructor();
    /**
     * @returns {boolean} Whether this is the certificate of the empty tree.
     */
    get isEmpty(): boolean;
    /**
     * @returns {Uint8Array|null} Copy of the key of the authenticated terminal leaf, `null` for the empty certificate.
     */
    get terminalKeyBytes(): Uint8Array | null;
    /**
     * Strictly decode the certificate bytes. The length is checked against the bitmap before any path is allocated.
     *
     * @param {Uint8Array} bytes Certificate bytes, copied.
     * @returns {NonInclusionCertificate} Decoded certificate.
     * @throws {RangeError} If the bytes are not exactly the profile (oversized, truncated, trailing bytes).
     */
    static fromBytes(bytes: Uint8Array): NonInclusionCertificate;
    /**
     * @returns {Uint8Array} A copy of the wire bytes.
     */
    toBytes(): Uint8Array;
    /**
     * **Building block: this does not authenticate a seal or a certificate.** It only answers what the certificate
     * says about the state relative to `root`, a root the caller already authenticated. Use `verifyNonInclusion` for a
     * proof from a service.
     *
     * Relation to the root (all of which are statements about that one root, not about the present): the empty
     * certificate holds only for the empty tree (`root` null, never a zero hash); a nonempty one only for a 32-byte root;
     * the query must choose the terminal's side at every junction, and the folded path must equal the root.
     *
     * @param {StateId} stateId The queried state, bound by the caller (the wire does not carry it).
     * @param {Uint8Array|null} root Authenticated state root, `null` for the certified empty tree.
     * @returns {Promise<NonInclusionRelation>} `absent` if the terminal differs from the query, `state_included` if the
     *   authenticated terminal is the query, `certificate_invalid` otherwise.
     */
    verifyAgainstTrustedRoot(stateId: StateId, root: Uint8Array | null): Promise<NonInclusionRelation>;
}
