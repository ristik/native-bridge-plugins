import { CertificationData } from './CertificationData.js';
import { StateId } from './StateId.js';
/**
 * Certification request object sent by the client to the aggregator.
 */
export declare class CertificationRequest {
    readonly stateId: StateId;
    readonly certificationData: CertificationData;
    static readonly CBOR_TAG = 39030n;
    private static readonly VERSION;
    /**
     * Constructs a CertificationRequest instance.
     * @param {StateId} stateId Unique state identifier.
     * @param {CertificationData} certificationData Certification data.
     */
    private constructor();
    /**
     * @returns {bigint} Wire-format version of this request.
     */
    get version(): bigint;
    /**
     * Create a new CertificationRequest instance.
     * @param {CertificationData} certificationData Certification data.
     *
     * @returns {Promise<CertificationRequest>} A promise that resolves to a CertificationRequest instance.
     */
    static create(certificationData: CertificationData): Promise<CertificationRequest>;
    /**
     * Convert the request to a CBOR bytes.
     *
     * @returns CBOR bytes
     */
    toCBOR(): Uint8Array;
}
