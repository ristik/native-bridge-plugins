import { InclusionProof } from './InclusionProof.js';
import { ProofStatusHint } from './ProofStatusHint.js';
import { SdkError } from './SdkError.js';
import { StateId } from './StateId.js';
import { InclusionProofVerificationStatus } from '../transaction/verification/rule/InclusionProofVerificationRule.js';
/**
 * Why waiting for an inclusion proof ended without one, as decided by the aggregator's answers.
 */
export type InclusionProofWaitFailure = 'conflict' | 'expired' | 'unknown';
/**
 * Base of the errors of {@link waitInclusionProof} that say "stop waiting and decide". One `instanceof` (or
 * {@link SdkError.is} plus `code`) catches all of them.
 *
 * The hint-driven ones are **unauthenticated hints** ("not a proof of absence, not a verdict"); the conflict is found by
 * comparing a served proof with the transaction.
 */
export declare abstract class InclusionProofWaitError<C extends InclusionProofWaitFailure = InclusionProofWaitFailure> extends SdkError {
    readonly stateId: StateId;
    /** What ended the wait. */
    abstract readonly code: C;
    /** True when submitting the same signed request again is a sensible next step. */
    abstract readonly resubmittable: boolean;
    /**
     * @param {StateId} stateId State id that was waited for.
     * @param {string} message Message.
     */
    protected constructor(stateId: StateId, message: string);
}
/**
 * The aggregator's (unauthenticated) hint ended the wait: `expired` or `unknown`. Carries the hint.
 *
 * Remember that the hint says nothing about the state being unspent and nothing about the transaction having failed.
 */
export declare abstract class InclusionProofStatusError<S extends 'expired' | 'unknown' = 'expired' | 'unknown'> extends InclusionProofWaitError<S> {
    readonly resubmittable = true;
    /** The hint the aggregator reported. */
    abstract readonly status: S;
}
/**
 * The aggregator reports the request as dropped because its deadline passed before it was included.
 */
export declare class InclusionProofExpiredError extends InclusionProofStatusError<'expired'> {
    readonly code: "expired";
    readonly name: "InclusionProofExpiredError";
    readonly status: "expired";
    /**
     * @param {StateId} stateId State id that was waited for.
     */
    constructor(stateId: StateId);
}
/**
 * The aggregator does not know the request: never seen, misrouted, lost, or wiped by a restart.
 */
export declare class InclusionProofUnknownError extends InclusionProofStatusError<'unknown'> {
    readonly code: "unknown";
    readonly name: "InclusionProofUnknownError";
    readonly status: "unknown";
    /**
     * @param {StateId} stateId State id that was waited for.
     * @param {number} [waitedMs] How long the hint stayed unknown before the wait gave up.
     */
    constructor(stateId: StateId, waitedMs?: number);
}
/**
 * The aggregator returned a proof for this state id that certifies a different request than the awaited transaction: a
 * conflicting submission (another device, a re-created transaction, an application bug) was queued first and will be
 * the one certified, so the awaited transaction was not and cannot be certified for this state. Not a status hint: it
 * is detected by comparing the proof's certification data with the transaction. Resubmitting the same request does not
 * help.
 *
 * The error is raised only for a proof that authenticates as the certified request for this state id (its path to the UC
 * root, shard binding and seal quorum verify against the trust base); a mismatching proof that does not is an invalid
 * response, not a conflict. The proof is still carried under the `unverified` name because the SDK verified it for the
 * state id only, not against the awaited transaction. The message starts with the legacy
 * `Invalid inclusion proof status: <status>` text.
 */
export declare class InclusionProofConflictError extends InclusionProofWaitError<'conflict'> {
    readonly reason: InclusionProofVerificationStatus.CERTIFICATION_DATA_MISMATCH | InclusionProofVerificationStatus.TRANSACTION_HASH_MISMATCH;
    readonly unverifiedInclusionProof: InclusionProof;
    readonly code: "conflict";
    readonly name: "InclusionProofConflictError";
    readonly resubmittable = false;
    /**
     * @param {string} reason Verification status that revealed the conflict.
     * @param {StateId} stateId State id that was waited for.
     * @param {InclusionProof} unverifiedInclusionProof The proof served for the state id, NOT authenticated.
     */
    constructor(reason: InclusionProofVerificationStatus.CERTIFICATION_DATA_MISMATCH | InclusionProofVerificationStatus.TRANSACTION_HASH_MISMATCH, stateId: StateId, unverifiedInclusionProof: InclusionProof);
}
export type { ProofStatusHint };
