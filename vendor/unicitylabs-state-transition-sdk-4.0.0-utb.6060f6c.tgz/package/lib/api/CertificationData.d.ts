import { DataHash } from '../crypto/hash/DataHash.js';
import { EncodedPredicate } from '../predicate/EncodedPredicate.js';
import { IUnlockScript } from '../predicate/IUnlockScript.js';
import { ITransaction } from '../transaction/ITransaction.js';
import { MintTransaction } from '../transaction/MintTransaction.js';
/**
 * Certification request data.
 */
export declare class CertificationData {
    readonly lockScript: EncodedPredicate;
    readonly sourceStateHash: DataHash;
    readonly transactionHash: DataHash;
    readonly expiresAt: bigint | null;
    private readonly _unlockScript;
    static readonly CBOR_TAG = 39031n;
    /** The only accepted wire version. One version, one element count. */
    static readonly VERSION = 2n;
    private static readonly FIELD_COUNT;
    /**
     * Create a certification data object.
     * @param {IPredicate} lockScript
     * @param {DataHash} sourceStateHash
     * @param {DataHash} transactionHash
     * @param {bigint|null} expiresAt Exclusive request deadline in Unix seconds, or `null` when the service assigns one
     * @param {Uint8Array} _unlockScript Unlock script bytes
     */
    private constructor();
    /**
     * Get the unlock script.
     */
    get unlockScript(): Uint8Array;
    /**
     * @returns {bigint} Wire-format version of this certification data.
     */
    get version(): bigint;
    /**
     * Create CertificationData from CBOR bytes.
     * @param {Uint8Array} bytes CBOR bytes
     *
     * @returns {CertificationData} certification data
     */
    static fromCBOR(bytes: Uint8Array): CertificationData;
    /**
     * Create CertificationData from a mint transaction.
     *
     * @param {MintTransaction} transaction Mint transaction to certify.
     * @returns {Promise<CertificationData>} Certification data.
     */
    static fromMintTransaction(transaction: MintTransaction): Promise<CertificationData>;
    /**
     * Create CertificationData from a transaction and its unlock script.
     *
     * @param {ITransaction} transaction Transaction to certify.
     * @param {IUnlockScript} unlockScript Unlock script for the transaction.
     * @returns {Promise<CertificationData>} Certification data.
     */
    static fromTransaction(transaction: ITransaction, unlockScript: IUnlockScript): Promise<CertificationData>;
    /**
     * Convert the certification data to CBOR bytes.
     *
     * @returns {Uint8Array} CBOR bytes
     */
    toCBOR(): Uint8Array;
    /**
     * Returns a string representation of the CertificationData.
     * @returns The string representation.
     */
    toString(): string;
}
