import { StateId } from './StateId.js';
import { DataHash } from '../crypto/hash/DataHash.js';
import { SparseMerkleTreeRootNode } from '../smt/radix/SparseMerkleTreeRootNode.js';
/**
 * Inclusion certificate for a leaf in a sparse Merkle tree.
 */
export declare class InclusionCertificate {
    private readonly bitmap;
    private readonly siblings;
    private static readonly BITMAP_SIZE;
    private static readonly MAX_DEPTH;
    private constructor();
    /**
     * Create an InclusionCertificate from a sparse Merkle tree root and leaf key.
     *
     * @param {SparseMerkleTreeRootNode} root Root node of the tree.
     * @param {Uint8Array} key Leaf key.
     * @returns {InclusionCertificate} New certificate.
     * @throws {Error} If the path cannot be constructed.
     */
    static create(root: SparseMerkleTreeRootNode, key: Uint8Array): InclusionCertificate;
    /**
     * Decode an InclusionCertificate from its byte encoding.
     *
     * @param {Uint8Array} bytes Encoded certificate.
     * @returns {InclusionCertificate} Decoded certificate.
     * @throws {Error} If the encoding is malformed.
     */
    static decode(bytes: Uint8Array): InclusionCertificate;
    /**
     * Reconstruct the sparse Merkle tree root hash for this certificate by hashing
     * from the leaf upward.
     *
     * @param {StateId} leafKey Leaf key.
     * @param {DataHash} leafValue Leaf value hash.
     * @returns {Promise<DataHash>} Reconstructed root hash.
     * @throws {Error} If the certificate siblings do not match the bitmap.
     */
    calculateRoot(leafKey: StateId, leafValue: DataHash): Promise<DataHash>;
    /**
     * @returns {Uint8Array} Encoded certificate bytes.
     */
    encode(): Uint8Array;
    /**
     * @returns {string} String representation of the inclusion certificate.
     */
    toString(): string;
    /**
     * Verify the certificate path against the expected root hash.
     *
     * @param {StateId} leafKey Leaf key.
     * @param {DataHash} leafValue Leaf value hash.
     * @param {DataHash} expectedRootHash Expected sparse Merkle tree root hash.
     * @returns {Promise<boolean>} True if the path is valid.
     */
    verify(leafKey: StateId, leafValue: DataHash, expectedRootHash: DataHash): Promise<boolean>;
}
