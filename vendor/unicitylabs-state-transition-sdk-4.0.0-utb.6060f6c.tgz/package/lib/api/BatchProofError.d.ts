import { SdkError } from './SdkError.js';
/**
 * Classification of a failed `get_inclusion_proofs.v1` call. Applications switch on `kind` (and `detail`), they never
 * parse JSON-RPC reason strings.
 *
 * - `unavailable`: the service reports it cannot serve the material now (state not in the snapshot, view not retained
 *   or evicted, no finalized or partition view) or is under pressure (`busy`). Inputs are intact, a new attempt may
 *   succeed, waiting cannot make an excluded leaf appear in a fixed root.
 * - `unsupported`: the endpoint does not support the method or the configuration (e.g. a parent/child aggregator).
 * - `rejected`: the service refused the request itself (invalid params), retrying the same input cannot succeed.
 * - `limit_exceeded`: a method limit (state count, request or response size) was hit.
 * - `server`: operational failure of the service (database, internal or unknown error code), code preserved.
 * - `transport`: the HTTP exchange failed (connection error, non-success status).
 * - `invalid_response`: the response is malformed or inconsistent with the request.
 */
export type BatchProofErrorKind = 'invalid_response' | 'limit_exceeded' | 'rejected' | 'server' | 'transport' | 'unavailable' | 'unsupported';
/**
 * Failure of a batch inclusion proof call. Caller cancellation is never wrapped: an aborted request rejects with the
 * platform's `AbortError`/`TimeoutError`.
 */
export declare class BatchProofError extends SdkError<'BatchProofError'> {
    readonly kind: BatchProofErrorKind;
    readonly name: "BatchProofError";
    private readonly _code;
    private readonly _detail;
    private readonly _indexes;
    private readonly _indexesByClass;
    private readonly _requests;
    private readonly _retryable;
    private readonly _waitedMs;
    /**
     * @param {BatchProofErrorKind} kind Classification.
     * @param {string} message Message.
     * @param {object} [info] Details echoed from the response.
     * @param {number} [info.code] JSON-RPC error code, if the failure was a JSON-RPC error.
     * @param {string} [info.detail] Service detail, e.g. `view_not_retained`, `busy:pinned_views`, `state_count`.
     * @param {number[]} [info.indexes] Positions in the request's state id list the service names as offending (state
     *   status details only).
     * @param {object} [info.indexesByClass] Offending positions by class, as the service sent them.
     * @param {boolean} [info.retryable] Whether a new attempt may succeed.
     * @param {number} [info.waitedMs] The aggregator's echo of the time it waited (`error.data.waitedMs`), when the request
     *   asked for a wait and the aggregator sent one.
     * @param {number} [info.requests] HTTP requests the call sent: 0 for a rejection before anything was sent (the
     *   default), 1, or 2 after the retry without `waitMs`.
     * @param {unknown} [info.cause] Underlying error.
     */
    constructor(kind: BatchProofErrorKind, message: string, info?: {
        readonly cause?: unknown;
        readonly code?: number;
        readonly detail?: string;
        readonly indexes?: readonly number[];
        readonly indexesByClass?: BatchIndexesByClass;
        readonly requests?: 0 | 1 | 2;
        readonly retryable?: boolean;
        readonly waitedMs?: number;
    });
    /**
     * @returns {number|undefined} JSON-RPC error code, if any.
     */
    get code(): number | undefined;
    /**
     * @returns {string|undefined} Service detail, if any.
     */
    get detail(): string | undefined;
    /**
     * @returns {number[]|undefined} Positions in the request's state id list that the service names as the cause of a
     *   state status failure, when it sent them.
     */
    get indexes(): number[] | undefined;
    /**
     * @returns {BatchIndexesByClass|undefined} The offending request positions of every class the service reported. A
     *   mixed outcome is reported under its most severe class (`unknown` over `expired` over `pending`) in
     *   {@link BatchProofError.detail}, the others are still listed here. Copies.
     */
    get indexesByClass(): {
        -readonly [K in BatchIndexClass]?: number[];
    } | undefined;
    /**
     * @returns {number} HTTP requests the failed call sent: 0 if it was rejected locally before anything was sent, 2 if the first answer was the generic `malformed_params` of a
     *   server that does not know `waitMs` and the repeat without it failed as well.
     */
    get requests(): 0 | 1 | 2;
    /**
     * @returns {boolean} Whether a new attempt may succeed. Never a promise that the same root will be served again.
     */
    get retryable(): boolean;
    /**
     * @returns {number|null} The aggregator's **unauthenticated** echo of how long it held the request, in milliseconds,
     *   or `null` if the request asked for no wait or the aggregator sent no echo. Timing metadata only: it says nothing
     *   about the state and never extends a deadline. A failure raised before the method ran has none.
     */
    get waitedMs(): number | null;
    /**
     * @param {unknown} error Anything that was thrown.
     * @returns {boolean} True for a batch proof error of this or another copy of the SDK.
     */
    static is(error: unknown): error is BatchProofError;
}
/**
 * The classes of offending request positions a state status error can list.
 */
export declare const BATCH_INDEX_CLASSES: readonly ["expired", "not_in_root", "pending", "unknown"];
export type BatchIndexClass = (typeof BATCH_INDEX_CLASSES)[number];
export type BatchIndexesByClass = {
    readonly [K in BatchIndexClass]?: readonly number[];
};
/**
 * Details of the state status errors of `get_inclusion_proofs.v1` (`proof_unavailable`). Like the single proof status
 * they are **unauthenticated hints** about what one aggregator knows, never proof of absence.
 *
 * - `state_pending`: accepted and not certified yet in the latest view; retryable.
 * - `state_expired`: the request was dropped before inclusion; not retryable.
 * - `state_unknown`: this aggregator never saw it (misrouted, lost, restarted, other HA instance); not retryable.
 * - `state_not_in_root`: the state is not a leaf of the requested exact root; not retryable.
 */
export declare const BATCH_STATE_DETAILS: readonly ["state_expired", "state_not_in_root", "state_pending", "state_unknown"];
export type BatchStateDetail = (typeof BATCH_STATE_DETAILS)[number];
/**
 * @param {string|undefined} detail Detail of a batch error.
 * @returns {boolean} True for one of the state status details.
 */
export declare function isBatchStateDetail(detail: string | undefined): detail is BatchStateDetail;
