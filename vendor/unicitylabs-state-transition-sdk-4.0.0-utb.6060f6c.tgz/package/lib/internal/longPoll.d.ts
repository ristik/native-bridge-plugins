/**
 * Wire rules of the optional long-poll metadata of the inclusion proof reads (`waitMs` in the request, `waitedMs` in the
 * answer).
 *
 * The wait is a request to the aggregator, never an obligation: a server that does not know the field ignores it and
 * answers at once without an echo. The echo is **unauthenticated** timing metadata. It is not part of any proof, it
 * never authenticates state and the SDK never lets it extend a deadline.
 *
 * Internal: not part of the public API (`./lib/internal/*` is not exported), the negotiation heuristic may change.
 */
/**
 * @param {unknown} value Candidate wait duration or echo.
 * @returns {boolean} True for a non negative safe integer. `-0`, fractions, `NaN`, `Infinity` and anything that is not a
 *   number are not wire integers.
 */
export declare function isWireMilliseconds(value: unknown): value is number;
import { ILongPollOptions } from '../api/ILongPollOptions.js';
/** Settings of a long poll that sizes its waits from the time left. */
export interface ILongPollSettings {
    readonly marginMs: number;
    readonly windowMs: number;
}
/**
 * Check a caller supplied `waitMs`, which is validated before anything is sent.
 *
 * @param {unknown} value Value of the `waitMs` option.
 * @returns {number} The value.
 * @throws {RangeError} If it is not an integer in `[0, Number.MAX_SAFE_INTEGER]`.
 */
export declare function checkWaitMs(value: unknown): number;
/**
 * Whether an error is the answer of a batch endpoint whose strict parser does not know a request field: the generic
 * `-32602` / `invalid_request` / `malformed_params`. The answer does not name the field, so the match is on the generic
 * class, and only for a response that carries the id of the request. An answer with `data.waitedMs` is not it: the
 * server understood the wait.
 *
 * @param {unknown} code JSON-RPC error code.
 * @param {unknown} data The `error.data` member.
 * @returns {boolean} True for exactly that class.
 */
export declare function isMalformedParams(code: unknown, data: unknown): boolean;
/**
 * @param {boolean|ILongPollOptions|undefined} option A `longPoll` style option.
 * @param {boolean} defaultOn What `undefined` means.
 * @returns {ILongPollSettings|null} The settings, or `null` when the long poll is off (`false`, `undefined` unless
 *   `defaultOn`, or a zero window).
 * @throws {RangeError} For a negative or non finite margin or window, or a window above `Number.MAX_SAFE_INTEGER`.
 */
export declare function longPollSettings(option: boolean | ILongPollOptions | undefined, defaultOn: boolean): ILongPollSettings | null;
/**
 * The `waitMs` of the next request: `floor(max(0, min(window, left - margin)))`, the window alone while the time left is
 * unknown. `0` means no wait fits and an ordinary immediate lookup is made.
 *
 * @param {ILongPollSettings} settings Long poll settings.
 * @param {number|undefined} left Milliseconds left, `undefined` if not known.
 * @returns {number} Milliseconds to ask the aggregator to wait.
 */
export declare function longPollWindow(settings: ILongPollSettings, left: number | undefined): number;
