/**
 * Thrown by {@link waitInclusionProof} when the wait is aborted, whether the
 * caller's abort signal fires while a poll request is in flight, while its
 * response is being verified, or while sleeping between polls.
 */
export declare class SleepError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
/**
 * Build the error reported when the caller's abort signal has fired. Nothing
 * here may throw: it runs inside the `abort` listeners, and an exception there
 * would skip the `reject` that ends the wait — the very hang this module
 * guards against.
 *
 * @param {AbortSignal} signal Aborted signal.
 * @returns {SleepError} Error carrying the signal's abort reason.
 */
export declare function createAbortError(signal: AbortSignal): SleepError;
/**
 * Detach an abort listener without letting a hostile or exotic signal break
 * the wait. The listeners are one-shot, so a refused removal is harmless.
 *
 * @param {AbortSignal} signal Signal the listener was attached to.
 * @param {Function} listener Listener to detach.
 */
export declare function removeAbortListener(signal: AbortSignal, listener: () => void): void;
/**
 * Stop the wait immediately if the signal has already fired.
 *
 * @param {AbortSignal} signal Signal to inspect.
 * @throws {SleepError} If the signal is aborted.
 */
export declare function throwIfAborted(signal: AbortSignal): void;
/**
 * Run one poll bounded by the caller's signal. The poll is handed a fresh
 * signal of its own so that the abort reaches the transport as a plain
 * `AbortSignal` — callers may pass any signal-like wrapper — and cancels only
 * this request. The wait settles as soon as either the poll settles or the
 * signal fires, so a poll that ignores its signal, or never responds at all,
 * still cannot outlive the caller's deadline.
 *
 * @param {Function} poll Runs one poll with the request's own abort signal.
 * @param {AbortSignal} signal Signal that ends the wait.
 * @returns {Promise} Promise settling with the poll, or rejecting on abort.
 * @throws {SleepError} If the signal fires before the poll settles.
 */
export declare function abortable<T>(poll: (signal: AbortSignal) => Promise<T>, signal: AbortSignal): Promise<T>;
/**
 * Wait for the given delay, unless the signal fires first.
 *
 * @param {number} ms Delay in milliseconds.
 * @param {AbortSignal} signal Signal that ends the wait.
 * @returns {Promise<void>} Promise resolving once the delay has elapsed.
 * @throws {SleepError} If the signal is or becomes aborted.
 */
export declare function sleep(ms: number, signal: AbortSignal): Promise<void>;
/**
 * A signal that aborts when either input does (`AbortSignal.any` needs a recent browser). Call `dispose` when the work is
 * done, so no listener stays on the long lived input.
 *
 * @param {AbortSignal} first Signal to join.
 * @param {AbortSignal} second Signal to join.
 * @returns {object} The joined signal and its cleanup.
 */
export declare function joinSignals(first: AbortSignal, second: AbortSignal): {
    signal: AbortSignal;
    dispose(): void;
};
