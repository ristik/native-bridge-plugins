import { NonInclusionProofError } from '../api/NonInclusionProofError.js';
/** A failure of `get_non_inclusion_proof.v1` or `null` for the service's claim that the state is included. */
export declare function classifyNonInclusionFailure(e: unknown, signal?: AbortSignal): NonInclusionProofError | null;
