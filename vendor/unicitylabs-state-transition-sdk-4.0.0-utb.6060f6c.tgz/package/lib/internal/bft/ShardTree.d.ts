import { InputRecord } from '../../api/bft/InputRecord.js';
import { ShardId } from '../../api/bft/ShardId.js';
import { ShardTreeCertificate } from '../../api/bft/ShardTreeCertificate.js';
/**
 * Committed content of one shard tree leaf.
 */
export interface IShardTreeInput {
    readonly inputRecord: InputRecord;
    readonly shard: ShardId;
    readonly shardConfigurationHash: Uint8Array;
    readonly technicalRecordHash: Uint8Array | null;
}
/**
 * Native shard tree of one partition, reconstructed from complete leaf set.
 *
 * Leaf hash is `H(IR, TRHash, ShardConfHash)`, inner node is `H(left, right)` with each child hash CBOR byte-string
 * encoded, the shard id only determines the tree position. A single shard partition has a leaf as the root.
 */
export declare class ShardTree {
    private readonly nodes;
    private constructor();
    /**
     * @returns {Uint8Array} Copy of the root hash.
     */
    get rootHash(): Uint8Array;
    /**
     * Build the tree. The leaves must be exactly the shards of a complete prefix-free scheme (the caller validates the
     * topology), a single shard partition has the one empty shard id.
     *
     * @param {IShardTreeInput[]} leaves Leaves of all shards.
     * @returns {Promise<ShardTree>} The tree.
     * @throws {Error} If the leaves do not form a complete tree.
     */
    static create(leaves: readonly IShardTreeInput[]): Promise<ShardTree>;
    /**
     * Shard tree certificate (sibling hashes from the leaf to the root) of the shard.
     *
     * @param {ShardId} shard Shard of a leaf.
     * @returns {ShardTreeCertificate} Certificate.
     * @throws {Error} If the shard is not a leaf of the tree.
     */
    certificate(shard: ShardId): ShardTreeCertificate;
}
