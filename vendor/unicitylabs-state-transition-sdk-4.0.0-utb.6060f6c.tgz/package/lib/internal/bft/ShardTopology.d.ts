import { ShardId } from '../../api/bft/ShardId.js';
/** The single shard of an unsharded partition: the empty shard id, native encoding `80`. */
export declare const SINGLE_SHARD: ShardId;
/**
 * Hardware-independent work counter of a topology validation.
 */
export interface ITopologyMetrics {
    /** Comparisons of two shard bit strings (sortedness check, sorting, prefix neighbor check). */
    comparisons: number;
}
/**
 * Shard ids of a complete prefix-free sharding scheme in binary tree left-to-right order (lexicographic bit string, `0`
 * before `1`). The empty scheme yields the single empty shard id.
 *
 * Validation is O(S) comparisons for an input that is already canonical and O(S log S) otherwise (S shards, bounded
 * id width): a prefix relation between two ids of a lexicographically sorted list always shows between neighbors
 * (everything between a prefix and an id it prefixes starts with that prefix), so no pairwise scan is needed, and
 * completeness is the Kraft sum over the sorted ids.
 *
 * @param {readonly ShardId[]} scheme Sharding scheme.
 * @param {number} maxLeaves Admission limit of shards.
 * @param {number} maxBits Admission limit of the id length in bits.
 * @param {ITopologyMetrics} [metrics] Optional counter of the work done.
 * @returns {ShardId[]} Shard ids in canonical order.
 * @throws {PartitionViewError} `topology` if the scheme is not a complete prefix-free set within the limits.
 */
export declare function canonicalShardOrder(scheme: readonly ShardId[], maxLeaves: number, maxBits: number, metrics?: ITopologyMetrics): ShardId[];
