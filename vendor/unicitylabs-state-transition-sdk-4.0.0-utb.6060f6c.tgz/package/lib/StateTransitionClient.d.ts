import { CertificationData } from './api/CertificationData.js';
import { CertificationResponse } from './api/CertificationResponse.js';
import { IAggregatorClient } from './api/IAggregatorClient.js';
import { InclusionProofResponse } from './api/InclusionProofResponse.js';
import { IInclusionProofRequestOptions, IRequestOptions } from './api/IRequestOptions.js';
import { StateId } from './api/StateId.js';
/**
 * High-level facade over an {@link IAggregatorClient}. Provides the two
 * operations a state-transition flow needs: fetching an inclusion proof for a
 * known state ID and submitting a certification request.
 */
export declare class StateTransitionClient {
    private readonly client;
    constructor(client: IAggregatorClient);
    /**
     * Retrieve the inclusion proof for a given state id.
     *
     * @param {StateId} stateId State id whose inclusion proof to retrieve.
     * @param {IInclusionProofRequestOptions} options Optional per-request options, e.g. an abort signal, or
     *   `includeStatusHint` for the aggregator's unauthenticated status hint.
     * @returns {Promise<InclusionProofResponse>} Inclusion proof response from the aggregator.
     */
    getInclusionProof(stateId: StateId, options?: IInclusionProofRequestOptions): Promise<InclusionProofResponse>;
    /**
     * Submit a certification request derived from the given certification data.
     *
     * @param {CertificationData} certificationData Certification data to submit.
     * @param {IRequestOptions} options Optional per-request options, e.g. an abort signal.
     * @returns {Promise<CertificationResponse>} Certification response from the aggregator.
     */
    submitCertificationRequest(certificationData: CertificationData, options?: IRequestOptions): Promise<CertificationResponse>;
}
