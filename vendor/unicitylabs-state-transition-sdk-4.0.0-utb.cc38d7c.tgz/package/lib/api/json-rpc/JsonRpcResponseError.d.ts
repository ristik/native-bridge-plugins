/**
 * Thrown when a JSON-RPC response is malformed — wrong protocol version,
 * mismatched id, not exactly one of result/error, oversized, or not valid JSON.
 */
export declare class JsonRpcResponseError extends Error {
    readonly name: string;
}
