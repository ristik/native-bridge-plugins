import { IRequestOptions } from '../IRequestOptions.js';
/**
 * JSON-RPC HTTP service.
 */
export declare class JsonRpcHttpTransport {
    /** Default maximum response body size in bytes, matching the Rust SDK's `MAX_RESPONSE_BODY_BYTES`. */
    static readonly DEFAULT_MAX_RESPONSE_BYTES: number;
    private readonly maxResponseBytes;
    private readonly url;
    /**
     * JSON-RPC HTTP service constructor.
     *
     * @param {string} url Endpoint URL.
     * @param {number} maxResponseBytes Maximum response body size in bytes; defaults to {@link JsonRpcHttpTransport.DEFAULT_MAX_RESPONSE_BYTES}.
     */
    constructor(url: string, maxResponseBytes?: number);
    /** The error object of an envelope as an error, or a response error if it is not a valid error object. */
    private static dataError;
    private static parseEnvelope;
    /**
     * Read a response body as text, rejecting bodies larger than `maxBytes`.
     *
     * @param {Response} response Fetch response.
     * @param {number} maxBytes Maximum allowed body size in bytes.
     * @returns {Promise<string>} The decoded body, or an empty string when the response has no body.
     * @throws {JsonRpcResponseError} If the body exceeds `maxBytes`.
     */
    private static readBoundedText;
    /**
     * Send a JSON-RPC request.
     *
     * @param {string} method JSON-RPC method.
     * @param {unknown} params JSON-RPC params.
     * @param {Headers} headers Optional request headers.
     * @param {IRequestOptions} options Optional per-request options, e.g. an abort signal.
     * @returns {Promise<unknown>} The response result.
     * @throws {JsonRpcNetworkError} On a non-success HTTP status.
     * @throws {JsonRpcDataError} When the response carries a JSON-RPC error object.
     * @throws {JsonRpcResponseError} When the response is malformed (version, id, exclusivity, size).
     */
    request(method: string, params: unknown, headers?: Headers, options?: IRequestOptions): Promise<unknown>;
}
