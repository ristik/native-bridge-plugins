/**
 * JSON-RPC error object.
 */
export declare class JsonRpcDataError extends Error {
    readonly idMatched: boolean;
    readonly code: number;
    /** Structured `error.data` of the response, if the server sent any. Untrusted. */
    readonly data: unknown;
    readonly name: string;
    /**
     * JSON-RPC error object constructor.
     * @param {{code: number; message: string; data?: unknown}} data Error data.
     * @param {boolean} idMatched Whether the envelope carried the id of the request (false: a null id).
     */
    constructor({ code, data, message }: {
        code: number;
        data?: unknown;
        message: string;
    }, idMatched?: boolean);
    /**
     * Error info to string.
     */
    toString(): string;
}
