import { IPaymentData } from './IPaymentData.js';
import { SplitAllocationProof } from './SplitAllocationProof.js';
import { NetworkId } from '../api/NetworkId.js';
import { IPredicate } from '../predicate/IPredicate.js';
import { TokenSalt } from '../transaction/TokenSalt.js';
import { TokenType } from '../transaction/TokenType.js';
/**
 * Realized split output: everything needed to mint the new token. Mint it with
 * exactly `paymentData.encode()` as the auxiliary payload — those are the bytes
 * bound by the split allocation proofs.
 */
export declare class SplitToken {
    readonly networkId: NetworkId;
    readonly recipient: IPredicate;
    readonly tokenType: TokenType;
    readonly salt: TokenSalt;
    readonly paymentData: IPaymentData;
    readonly proofs: SplitAllocationProof[];
    constructor(networkId: NetworkId, recipient: IPredicate, tokenType: TokenType, salt: TokenSalt, paymentData: IPaymentData, proofs: SplitAllocationProof[]);
}
