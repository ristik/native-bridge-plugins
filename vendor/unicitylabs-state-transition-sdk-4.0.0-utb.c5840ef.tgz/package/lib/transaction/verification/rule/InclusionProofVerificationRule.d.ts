import { ITrustBaseHistory } from '../../../api/bft/trustbase/ITrustBaseHistory.js';
import { UnicityCertificateVerifier } from '../../../api/bft/verification/UnicityCertificateVerifier.js';
import { InclusionProof } from '../../../api/InclusionProof.js';
import { DataHash } from '../../../crypto/hash/DataHash.js';
import { EncodedPredicate } from '../../../predicate/EncodedPredicate.js';
import { PredicateVerifierService } from '../../../predicate/verification/PredicateVerifierService.js';
import { VerificationResult } from '../../../verification/VerificationResult.js';
/**
 * Status codes for verifying an InclusionProof.
 */
export declare enum InclusionProofVerificationStatus {
    INVALID_TRUSTBASE = "INVALID_TRUSTBASE",
    CERTIFICATION_DATA_MISMATCH = "CERTIFICATION_DATA_MISMATCH",
    TRANSACTION_HASH_MISMATCH = "TRANSACTION_HASH_MISMATCH",
    REFERENCE_TIME_AFTER_ROUND = "REFERENCE_TIME_AFTER_ROUND",
    REQUEST_EXPIRED = "REQUEST_EXPIRED",
    NOT_AUTHENTICATED = "NOT_AUTHENTICATED",
    PATH_INVALID = "PATH_INVALID",
    SHARD_ID_MISMATCH = "SHARD_ID_MISMATCH",
    OK = "OK"
}
/**
 * Genesis verification rule.
 */
export declare class InclusionProofVerificationRule {
    /**
     * Verify an inclusion proof for a transaction, given the transaction data the proof
     * attests to: its canonical hash, the lock script being unlocked, and the source state
     * being spent.
     *
     * @param {ITrustBaseHistory} trustBase Trust-base history.
     * @param {PredicateVerifierService} predicateVerifierFactory Predicate verifier service.
     * @param {InclusionProof} inclusionProof Inclusion proof to verify.
     * @param {DataHash} transactionHash Canonical hash of the transaction.
     * @param {bigint|null} expiresAt Exclusive request deadline in Unix seconds, or `null` when the service assigned one.
     * @param {EncodedPredicate} lockScript Lock script the transaction unlocks.
     * @param {DataHash} sourceStateHash Hash of the state the transaction spends.
     * @returns {Promise<VerificationResult<InclusionProofVerificationStatus>>} Verification outcome.
     */
    static verify(trustBase: ITrustBaseHistory, predicateVerifierFactory: PredicateVerifierService, unicityCertificateVerifier: UnicityCertificateVerifier, inclusionProof: InclusionProof, transactionHash: DataHash, expiresAt: bigint | null, lockScript: EncodedPredicate, sourceStateHash: DataHash): Promise<VerificationResult<InclusionProofVerificationStatus>>;
}
