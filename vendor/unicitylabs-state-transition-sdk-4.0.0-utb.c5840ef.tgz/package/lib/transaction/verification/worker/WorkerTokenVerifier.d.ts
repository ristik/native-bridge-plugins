import { IWorker } from './IWorker.js';
import { UnicityCertificateVerifier } from '../../../api/bft/verification/UnicityCertificateVerifier.js';
import { PredicateVerifierService } from '../../../predicate/verification/PredicateVerifierService.js';
import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import type { Token } from '../../Token.js';
import { ITokenVerifier } from '../ITokenVerifier.js';
import { IVerificationContext } from '../IVerificationContext.js';
/**
 * A single transfer encoded self-contained (see {@link encodeSelfContained}) and its
 * index in the token.
 */
export interface IEncodedTransferTransaction {
    readonly bytes: Uint8Array;
    readonly index: number;
}
/**
 * The trust-base history as it crosses the worker boundary: the pinned genesis entry id and the held entries, hex encoded. The worker appends
 * them again, so it checks the chain itself rather than trusting the main thread's word.
 */
export interface IEncodedTrustBaseHistory {
    readonly entries: readonly string[];
    readonly genesisPin: string;
}
/**
 * The message posted to a worker: the transfers of one batch and the trust-base history.
 */
export interface ITransferTransactionVerificationRequest {
    readonly transfers: readonly IEncodedTransferTransaction[];
    readonly trustBase: IEncodedTrustBaseHistory;
}
/**
 * One transfer's verification outcome as it crosses the worker boundary.
 */
export interface ITransferTransactionVerificationResult {
    readonly index: number;
    readonly message: string;
    /** Set when the failure is the typed "no trust-base entry for this epoch" (epoch and held tip epoch as decimal strings; tip empty if none). */
    readonly noEntry?: {
        readonly epoch: string;
        readonly tipEpoch: string;
    };
    readonly status: VerificationStatus;
}
/**
 * What a worker posts back: either the batch results, or an error to re-throw on the
 * main thread.
 */
export type TransferTransactionVerificationResponse = ITransferTransactionVerificationResult[] | {
    error: string;
};
/**
 * Worker-side verifier for transfer batches: verifies every transfer of a batch against
 * the trust base shipped with it, using the subclass-supplied predicate verifier — the
 * only verification dependency a transfer needs. The worker entry script runs an
 * instance.
 */
export declare abstract class TransferTransactionVerifier {
    /** The history of the last request: batches of one token carry the same one, and building it checks every signature of the chain. */
    private lastHistory;
    /**
     * The predicate verifier to verify batches with.
     *
     * Must be equivalent to the one in the context the main thread passes to
     * {@link WorkerTokenVerifier.verify}: the two verifiers are built independently on each
     * side of the worker boundary, and if they differ, the transfers verified here and the
     * genesis verified on the main thread are judged under different rules — the token
     * verdict silently diverges from {@link Token.verify}.
     */
    protected abstract get predicateVerifier(): PredicateVerifierService;
    /**
     * Unicity certificate verifier for worker-side inclusion-proof checks.
     *
     * Verifier instances cannot cross the worker boundary, so each side builds
     * its own; this one MUST be equivalent to the one in the main-thread
     * verification context. If they differ, worker-verified transfers and the
     * main-thread-verified genesis are judged under different rules.
     */
    protected abstract get unicityCertificateVerifier(): UnicityCertificateVerifier;
    /**
     * Verify every transfer in the request against the trust base shipped with it.
     *
     * @param {ITransferTransactionVerificationRequest} request The batch to verify.
     * @returns {Promise<TransferTransactionVerificationResponse>} Batch results, or the error to report back.
     */
    verify(request: ITransferTransactionVerificationRequest): Promise<TransferTransactionVerificationResponse>;
    private historyOf;
}
/**
 * Base for worker-pool {@link ITokenVerifier} implementations. Verifies the genesis and
 * walks the provenance on the calling thread, and fans each token's transfer
 * verifications out to a shared pool of workers reused across every {@link verify}. A
 * consumer subclass supplies {@link createWorker} for its platform (Node worker threads
 * via the {@link NodeWorker} adapter, browser Web Workers as-is).
 *
 * Each worker runs a consumer-authored entry script bootstrapping a
 * {@link NodeTransferTransactionVerifierWorker} or
 * {@link BrowserTransferTransactionVerifierWorker} subclass, so every batch is verified
 * with the predicate verifier that subclass supplies. Call {@link dispose} to terminate
 * the pool.
 */
export declare abstract class WorkerTokenVerifier implements ITokenVerifier {
    private readonly poolSize;
    private readonly pool;
    protected constructor(poolSize: number);
    /** Terminate the worker pool. The verifier must not be used afterwards. */
    dispose(): void;
    /**
     * @inheritDoc
     */
    verify(token: Token, outer: IVerificationContext): Promise<VerificationResult<VerificationStatus>>;
    /**
     * Spread `[0, count)` round-robin across at most {@link poolSize} batches.
     *
     * @param {number} count Number of transfers to distribute.
     * @returns {number[][]} Non-empty index batches.
     */
    private partition;
    /**
     * Create one worker running this SDK's batch handling.
     *
     * @returns {IWorker} A fresh worker.
     */
    protected abstract createWorker(): IWorker;
}
