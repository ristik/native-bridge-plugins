/** The package version; a test keeps it equal to `package.json`. */
export declare const SDK_VERSION = "4.0.0";
