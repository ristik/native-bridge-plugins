import { ShardId } from './bft/ShardId.js';
import { SealVerificationSession } from './bft/verification/SealVerificationSession.js';
import { NonInclusionProof } from './NonInclusionProof.js';
import { StateId } from './StateId.js';
import { IVerificationContext } from '../transaction/verification/IVerificationContext.js';
/**
 * The authenticated snapshot a non-inclusion verification speaks for. Every field is read from the authenticated
 * unicity certificate and its input record, never from RPC block metadata or the time of receipt.
 *
 * ```ts
 * // checkpoint: obtained independently of the proof and of the server response
 * const r = await verifyNonInclusion(proof, trustedContext);
 * if (r.verdict !== 'absent_at_snapshot') throw new Error('No verified absence');
 * if (r.snapshot.networkId !== checkpoint.networkId ||
 *     r.snapshot.rootRound < checkpoint.requiredRootRound) {
 *   throw new Error('Snapshot does not meet application policy');
 * }
 * // Absence at r.snapshot only; any spend/finality decision needs its own policy.
 * ```
 *
 * Non-inclusion proves absence only at the authenticated snapshot returned by verification. It does not prove absence
 * now, continuous absence, or that a token can be spent. Compare the snapshot’s network and root round (or its certified
 * seal timestamp under your application’s time policy) with an independently trusted requirement. The seal timestamp is
 * a consensus-certified time, not proof of real-time freshness. Do not use unverified response metadata for this check.
 *
 * Only obtainable from {@link verifyNonInclusion}; it cannot be constructed, forged or mutated, and it owns copies of
 * its bytes.
 */
export declare class NonInclusionSnapshot {
    #private;
    /** Network of the authenticated seal. */
    readonly networkId: number;
    /** Partition of the certificate: always {@link AGGREGATION_PARTITION_ID}. */
    readonly partitionId: bigint;
    /** Epoch of the seal. */
    readonly rootEpoch: bigint;
    /** Root chain round of the seal: the round of the snapshot. */
    readonly rootRound: bigint;
    /** Time of the seal in Unix seconds, a consensus-certified time. */
    readonly sealTimestampSeconds: bigint;
    /** Epoch of the shard's input record. */
    readonly shardEpoch: bigint;
    /** Round of the shard's input record. */
    readonly shardRound: bigint;
    /**
     * @returns {ShardId} A fresh copy of the shard of the certificate, the empty shard for an unsharded partition.
     */
    get shardId(): ShardId;
    /**
     * @returns {Uint8Array|null} Copy of the state root of the snapshot, `null` for the certified empty tree.
     */
    get stateRoot(): Uint8Array | null;
}
/** The authenticated values of a {@link NonInclusionSnapshot}. */
export interface INonInclusionSnapshotParts {
    readonly networkId: number;
    readonly partitionId: bigint;
    readonly rootEpoch: bigint;
    readonly rootRound: bigint;
    readonly sealTimestampSeconds: bigint;
    readonly shardEpoch: bigint;
    readonly shardId: ShardId;
    readonly shardRound: bigint;
    readonly stateRoot: Uint8Array | null;
}
/**
 * Why a proof was rejected, from the first check that failed, in this order: the certificate is not valid for the fixed
 * aggregation partition and the expected shard (`uc_invalid`), its seal is not from the trusted authority
 * (`authority_rejected`), or the path does not reach the root (`certificate_invalid`). A proof that does not decode is
 * not a rejection but an error of {@link NonInclusionProof.decode}.
 */
export type NonInclusionRejection = 'authority_rejected' | 'certificate_invalid' | 'uc_invalid';
/**
 * Explicit context of {@link verifyNonInclusion}: what the application expects, never taken from the proof. The
 * partition is not a choice: it is {@link AGGREGATION_PARTITION_ID}. Freshness is not a verifier option either: it is
 * a decision of the caller on the returned snapshot.
 */
export interface INonInclusionVerificationOptions {
    /**
     * Authenticated start of the next epoch, if the authority history ends the verified one: a seal at or after it is
     * rejected. Must come from an authenticated history, never from the proof.
     */
    readonly nextEpochStartRound?: bigint;
    /**
     * Overrides the seal session. Not needed with an operation scoped context: if `unicityCertificateVerifier` came from
     * `beginOperation()`, its session is used and seals shared with inclusion proofs are checked once. Must be anchored to
     * the context's trust base.
     */
    readonly session?: SealVerificationSession;
    /**
     * Shard of the partition the application expects, like Go `noninclusion.Context.Shard` and Rust `with_shard`: the
     * empty shard (the default) is the unsharded form, a certificate of any shard is then `uc_invalid`. A nonempty shard
     * needs a shard path with exactly one sibling per bit, and the queried state and the authenticated terminal leaf must
     * belong to it. Never taken from the proof.
     */
    readonly shard?: ShardId;
    /** Pinned shard configuration hash of the partition. */
    readonly shardConfigurationHash?: Uint8Array;
}
/**
 * Result of {@link verifyNonInclusion}: narrow on `verdict`. Only the two snapshot verdicts carry a `snapshot`; a
 * rejection carries none.
 *
 * Non-inclusion proves absence only at the authenticated snapshot returned by verification. It does not prove absence
 * now, continuous absence, or that a token can be spent. Compare the snapshot’s network and root round (or its certified
 * seal timestamp under your application’s time policy) with an independently trusted requirement. The seal timestamp is
 * a consensus-certified time, not proof of real-time freshness. Do not use unverified response metadata for this check.
 */
export type NonInclusionVerification = {
    /** Empty for a snapshot outcome. */
    readonly reason: '';
    readonly snapshot: NonInclusionSnapshot;
    readonly stateId: StateId;
    readonly verdict: 'absent_at_snapshot' | 'included_at_snapshot';
} | {
    /**
     * Diagnostic text for logs only: do not parse it and do not base a decision on it. It may quote values of the
     * unverified proof (for example the epoch of a seal that was not authenticated); the decision is `verdict`.
     */
    readonly reason: string;
    readonly snapshot: null;
    readonly stateId: StateId;
    readonly verdict: NonInclusionRejection;
};
/**
 * Verify a decoded proof against a trusted authority and report **the authenticated snapshot** it speaks for: the state
 * is `absent_at_snapshot`, or (a valid path proving that exact key present) `included_at_snapshot`; anything else is a
 * rejection without any snapshot metadata. Both outcomes are facts about that one root, not about now.
 *
 * Non-inclusion proves absence only at the authenticated snapshot returned by verification. It does not prove absence
 * now, continuous absence, or that a token can be spent. Compare the snapshot’s network and root round (or its certified
 * seal timestamp under your application’s time policy) with an independently trusted requirement. The seal timestamp is
 * a consensus-certified time, not proof of real-time freshness. Do not use unverified response metadata for this check.
 *
 * ```ts
 * // checkpoint: obtained independently of the proof and of the server response
 * const r = await verifyNonInclusion(proof, trustedContext);
 * if (r.verdict !== 'absent_at_snapshot') throw new Error('No verified absence');
 * if (r.snapshot.networkId !== checkpoint.networkId ||
 *     r.snapshot.rootRound < checkpoint.requiredRootRound) {
 *   throw new Error('Snapshot does not meet application policy');
 * }
 * // Absence at r.snapshot only; any spend/finality decision needs its own policy.
 * ```
 *
 * Order: (1) the certificate for the fixed aggregation partition ({@link AGGREGATION_PARTITION_ID}) and the expected
 * shard (the empty shard unless `options.shard`; exactly one shard path sibling per shard id bit), 32-byte technical
 * record hash, optional pinned configuration hash, a structurally valid input record, no nil path entries or step keys
 * beyond 32 bits, and the shard and partition path to the seal hash; (2) the seal against the context's trust base
 * with the strict authenticator (network, exact epoch, not before the epoch start, quorum), and an authenticated epoch
 * end if given; (3) for a sharded certificate the membership of the state and of the terminal leaf in the shard; (4)
 * the state tree relation: every junction chosen like the terminal, the path reaching the certified root. No snapshot is
 * built before all of it holds. There is no freshness option: that is the caller's decision on the snapshot.
 *
 * @param {NonInclusionProof} proof Decoded proof, bound to its state id.
 * @param {Pick<IVerificationContext, 'trustBase' | 'unicityCertificateVerifier'>} context Trusted authority.
 * @param {INonInclusionVerificationOptions} [options] What the application expects.
 * @returns {Promise<NonInclusionVerification>} The snapshot outcome, or the first failing check.
 * @throws {TypeError} If `options.session` is anchored to another trust base.
 */
export declare function verifyNonInclusion(proof: NonInclusionProof, context: Pick<IVerificationContext, 'trustBase' | 'unicityCertificateVerifier'>, options?: INonInclusionVerificationOptions): Promise<NonInclusionVerification>;
