/**
 * Read a response body as bytes, rejecting bodies larger than `maxBytes`.
 *
 * @param {Response} response Fetch response.
 * @param {number} maxBytes Maximum allowed body size in bytes.
 * @returns {Promise<Uint8Array>} The body, empty when the response has none.
 * @throws {JsonRpcResponseError} If the body exceeds `maxBytes`.
 */
export declare function readBoundedBytes(response: Response, maxBytes: number): Promise<Uint8Array>;
