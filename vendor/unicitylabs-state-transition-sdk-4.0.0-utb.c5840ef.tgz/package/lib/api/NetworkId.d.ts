/**
 * Unicity network identifier (α). Used to scope token ids and other
 * network-bound values so they cannot be replayed across networks.
 *
 * The named networks are the live ones: MAINNET 1, TESTNET2 4 and the LOCAL development network 3. Network 2, the old testnet, was removed and has no
 * constant, so no one can pick it by name; `fromId` still accepts any valid id.
 */
export declare class NetworkId {
    readonly id: number;
    private readonly name?;
    static readonly LOCAL: NetworkId;
    static readonly MAINNET: NetworkId;
    static readonly TESTNET2: NetworkId;
    private constructor();
    /**
     * Resolve a NetworkId from its numeric identifier. Returns the registered
     * singleton for known ids; constructs a new (unnamed) instance for any
     * other value in the 16-bit unsigned range.
     *
     * @param {number|bigint} id Numeric network identifier.
     * @returns {NetworkId} NetworkId for the given identifier.
     * @throws {Error} If `id` is outside the 16-bit unsigned range.
     */
    static fromId(id: number | bigint): NetworkId;
    /**
     * Equality check against another NetworkId.
     *
     * @param {NetworkId} other Other network identifier.
     * @returns {boolean} True if both share the same numeric id.
     */
    equals(other: NetworkId): boolean;
    /**
     * @returns {string} `NetworkId[<name>]` for registered networks, `NetworkId[<id>]` otherwise.
     */
    toString(): string;
}
