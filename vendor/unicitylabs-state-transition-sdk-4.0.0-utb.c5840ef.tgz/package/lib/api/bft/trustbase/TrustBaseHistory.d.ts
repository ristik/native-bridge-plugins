import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
import { TrustBaseBundle } from './TrustBaseBundle.js';
import { NetworkId } from '../../NetworkId.js';
/**
 * What {@link TrustBaseHistory.append} did with an entry that passed: it was added, or it was already held (nothing changed).
 */
export type TrustBaseAppendOutcome = 'appended' | 'noop';
/**
 * The append-only Unicity Trust Base history a verifier holds: consecutive entries from a genesis entry pinned out of band by its entry id, each
 * authenticated by a strict quorum of its predecessor's members. The reference is the shared vectors' history model (bft-go-base
 * `types/root_trust_base_v2_vectors_test.go`) and bft-core `utbstore`.
 *
 * `append` is the only way in, for the genesis and for every later entry, including those of a loaded bundle. An entry of a held epoch changes
 * nothing: the same entry id is a `noop` (its signature set must still verify, so a bad witness is an error), a different one is a conflict. An
 * entry more than one epoch ahead is a gap. Appends are serialised, so concurrent callers see one consistent chain.
 */
export declare class TrustBaseHistory {
    private readonly _genesisPin;
    private readonly _entries;
    private _queue;
    private constructor();
    /** @returns {RootTrustBaseV2[]} The held entries, ascending from the genesis. */
    get entries(): RootTrustBaseV2[];
    /** @returns {Uint8Array} Copy of the pinned entry id of the genesis. */
    get genesisPin(): Uint8Array;
    /** @returns {boolean} Whether no entry is held yet. */
    get isEmpty(): boolean;
    /** @returns {NetworkId|null} The network of the held entries, or null when empty. */
    get networkId(): NetworkId | null;
    /** @returns {RootTrustBaseV2|null} The latest held entry, or null when empty. */
    get tip(): RootTrustBaseV2 | null;
    /**
     * An empty history bound to the genesis it will accept.
     *
     * @param {Uint8Array} genesisPin Entry id of the genesis entry, from outside the history (a release pin).
     * @returns {TrustBaseHistory} Empty history.
     * @throws {TrustBaseInvalidError} If the pin is not a 32-byte entry id.
     */
    static create(genesisPin: Uint8Array): TrustBaseHistory;
    /**
     * Load a complete bundle through {@link append}, like every later entry.
     *
     * @param {TrustBaseBundle} bundle Decoded bundle.
     * @param {Uint8Array} genesisPin Entry id of the genesis entry.
     * @returns {Promise<TrustBaseHistory>} History holding every entry of the bundle.
     * @throws {TrustBaseChainError} If the genesis is not the pinned one or an entry does not extend its predecessor.
     * @throws {TrustBaseSignatureError} If an entry is not signed by a quorum of its predecessor.
     */
    static fromBundle(bundle: TrustBaseBundle, genesisPin: Uint8Array): Promise<TrustBaseHistory>;
    /**
     * Add an entry.
     *
     * @param {RootTrustBaseV2} entry Decoded entry.
     * @returns {Promise<TrustBaseAppendOutcome>} `appended`, or `noop` when the entry is already held.
     * @throws {TrustBaseInvalidError} If the first entry is not a genesis entry.
     * @throws {TrustBaseChainError} If the first entry is not the pinned genesis, or the entry does not extend the tip (or its held predecessor).
     * @throws {TrustBaseSignatureError} If the predecessor's members did not sign it with a quorum.
     * @throws {TrustBaseConflictError} If a different entry is held for the epoch.
     * @throws {TrustBaseGapError} If the entry is more than one epoch ahead of the tip.
     */
    append(entry: RootTrustBaseV2): Promise<TrustBaseAppendOutcome>;
    /**
     * The held entry of an epoch.
     *
     * @param {bigint} epoch Epoch.
     * @returns {RootTrustBaseV2|null} The entry, or null when the epoch is before the genesis or after the tip (the caller may fetch and append).
     */
    entryForEpoch(epoch: bigint): RootTrustBaseV2 | null;
    /**
     * The round at which the held successor of an epoch starts, which ends the epoch's interval.
     *
     * @param {bigint} epoch Epoch.
     * @returns {bigint|null} Start round of the entry for `epoch + 1`, or null when none is held (the epoch is open-ended as far as this history knows).
     */
    epochEndRound(epoch: bigint): bigint | null;
    /**
     * The held entries as one complete bundle (tag 39015), the form a cache stores. Round-trips through {@link TrustBaseBundle.decode}.
     *
     * @returns {Promise<Uint8Array>} Tagged bundle.
     * @throws {TrustBaseBundleError} If the history is empty.
     */
    toBundle(): Promise<Uint8Array>;
    private appendNow;
}
