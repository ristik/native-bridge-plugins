/**
 * Base class of the errors the Unicity Trust Base (UTB) codec raises. The subclasses are the error CLASSES a caller (and the shared
 * vectors) distinguish; the message carries the detail.
 */
export declare abstract class TrustBaseError extends Error {
    readonly errorClass: string;
    protected constructor(errorClass: string, message: string);
}
/**
 * The bytes are not a well-formed deterministic UTB record: wrong tag, version or arity, truncated, trailing bytes, out-of-bounds sizes,
 * a second byte form of the same value.
 */
export declare class TrustBaseEncodingError extends TrustBaseError {
    constructor(message: string);
}
/**
 * The record is well formed but a structure rule fails: epoch zero, member list, weights, keys, quorum threshold, hash lengths, genesis versus
 * non-genesis shape.
 */
export declare class TrustBaseInvalidError extends TrustBaseError {
    constructor(message: string);
}
/**
 * The bytes are a well-formed trust-base response but not a complete bundle: a status other than OK, a continuation cursor, a partial range
 * (not starting at a genesis entry), a gap or a broken predecessor link, a header that disagrees with its entries.
 */
export declare class TrustBaseBundleError extends TrustBaseError {
    constructor(message: string);
}
/**
 * A well-formed entry that does not extend its predecessor: a genesis entry where a successor is expected, another network, an epoch that is not
 * the predecessor's plus one, a start round that does not advance, a predecessor id that does not match, or a genesis that is not the pinned one.
 */
export declare class TrustBaseChainError extends TrustBaseError {
    constructor(message: string);
}
/** The entry is of another network than the history. */
export declare class TrustBaseNetworkError extends TrustBaseChainError {
    constructor(message: string);
}
/** The entry's epoch is before the genesis epoch of the history, so no later fetch can supply it. */
export declare class TrustBaseBeforeGenesisError extends TrustBaseChainError {
    constructor(message: string);
}
/**
 * A signature check failed: a signer that is not a member, a malformed or invalid signature (even among enough valid ones), or a signed weight
 * below the quorum threshold.
 */
export declare class TrustBaseSignatureError extends TrustBaseError {
    constructor(message: string);
}
/**
 * The history already holds a different entry for this epoch. Not retryable: one of the two histories is not the network's.
 */
export declare class TrustBaseConflictError extends TrustBaseError {
    readonly epoch: bigint;
    readonly details: ITrustBaseConflictDetails | null;
    constructor(epoch: bigint, message: string, details?: ITrustBaseConflictDetails | null);
    /** @returns {boolean} Whether the competing entry was verified against the held predecessor (a real fork, not just a different entry). */
    get authenticated(): boolean;
}
/**
 * Evidence of a conflict: the two entry ids and, for an authenticated fork, the bytes of both entries (bounded by the entry size limit).
 */
export interface ITrustBaseConflictDetails {
    readonly authenticated: boolean;
    readonly epoch: bigint;
    readonly heldEntry: Uint8Array | null;
    readonly heldEntryId: Uint8Array;
    readonly network: number;
    readonly offeredEntry: Uint8Array | null;
    readonly offeredEntryId: Uint8Array;
}
/**
 * The session saw an authenticated fork after its release checkpoint and is closed to appends and verification until the application reopens it
 * with a checkpoint that selects a branch. The evidence stays readable on the session.
 */
export declare class HistoryConflictedError extends TrustBaseError {
    readonly conflict: TrustBaseConflictError;
    constructor(conflict: TrustBaseConflictError);
}
/**
 * An entry or cache disagrees with the release checkpoint (epoch at or before the pinned tip). The checkpoint selects the authority; this is a
 * refusal, not a conflict, and it does not close the session.
 */
export declare class TrustBasePinMismatchError extends TrustBaseError {
    constructor(message: string);
}
/**
 * An embedded release pin or explicit pin is not what it claims (digest, structure, signature, id or epoch). Fatal, never rescued by a cache or a
 * remote source.
 */
export declare class ReleasePinInvalidError extends TrustBaseError {
    constructor(message: string, options?: ErrorOptions);
}
/** No release pin for the network and no explicit one. */
export declare class UnknownNetworkError extends TrustBaseError {
    constructor(message: string);
}
/** The store could not be read or written. `reason` says which kind of failure. */
export declare class TrustBaseStoreError extends TrustBaseError {
    readonly reason: 'io' | 'oversize' | 'permission' | 'quota';
    constructor(reason: 'io' | 'oversize' | 'permission' | 'quota', message: string, options?: ErrorOptions);
}
/** A save lost its compare-and-swap race too often. Retryable by the application. */
export declare class CacheContendedError extends TrustBaseError {
    constructor(message: string);
}
/**
 * The entry is more than one epoch ahead of the history's tip. Retryable once the missing entries are fetched.
 */
export declare class TrustBaseGapError extends TrustBaseError {
    readonly epoch: bigint;
    readonly tipEpoch: bigint;
    constructor(epoch: bigint, tipEpoch: bigint, message: string);
}
/**
 * No source served the entries that were wanted: every source failed, answered with a refusal status, or served an entry the history refuses. The
 * causes are kept, in the order they happened. Not the same as "nothing newer": that is a result (no entries appended), not an error.
 */
export declare class TrustBaseUpdateError extends TrustBaseError {
    readonly causes: readonly unknown[];
    /** Entries appended before the call failed: a valid prefix stays held, and may be all the caller needed. */
    readonly appended: number;
    constructor(message: string, causes: readonly unknown[], 
    /** Entries appended before the call failed: a valid prefix stays held, and may be all the caller needed. */
    appended?: number);
}
/** Another writer holds the cache lock. Immediate, never waited on and never stolen: a lock left by a crash is for the application to clear. */
export declare class CacheBusyError extends TrustBaseError {
    constructor(message: string);
}
