import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
import { NetworkId } from '../../NetworkId.js';
/**
 * Budget of a bundle decode; a release supplies it, there is no fixed history length. `maxBytes` is checked before anything is read. `maxEntries`
 * is checked after the entry list has been split (the CBOR reader walks the array before the count is known), so what bounds that allocation is
 * the input size, `maxBytes`, not `maxEntries`.
 */
export interface ITrustBaseBundleLimits {
    readonly maxBytes: number;
    readonly maxEntries: number;
    /** Bytes of one entry. Default {@link TrustBaseBundle.MAX_ENTRY_BYTES}. */
    readonly maxEntryBytes?: number;
}
/**
 * A complete Unicity Trust Base release bundle: the GetTrustBase response (CBOR tag 39015) with status OK, starting at the genesis entry, ending
 * at the release tip, with no continuation cursor. The reference is bft-core `gettrustbase.DecodeBundle`.
 *
 * Wire form: tag 39015 over `[1, networkId, 0, fromEpoch, effectiveEnd, endEntryId, [entry...], null]`, each entry a complete tag-39000
 * {@link RootTrustBaseV2}, consecutive and ascending from the genesis, each linked to its predecessor by entry id. A one-entry bundle holds a
 * genesis entry only.
 *
 * Decoding checks the structure and the links, not the signatures: the history that installs the bundle authenticates every entry after the
 * genesis, and the genesis against a pinned entry id.
 */
export declare class TrustBaseBundle {
    readonly networkId: NetworkId;
    private readonly _entries;
    private readonly _raw;
    static readonly CBOR_TAG = 39015n;
    /**
     * Bound of one embedded entry in bytes: 128 KiB. A full entry (256 members, 128-byte node ids, 256 predecessor signatures) is about 95,400 bytes;
     * sixteen members need at most about 6 KiB.
     */
    static readonly MAX_ENTRY_BYTES: number;
    static readonly VERSION = 1n;
    private static readonly STATUS_OK;
    private constructor();
    /** @returns {RootTrustBaseV2[]} The entries, ascending from the genesis. */
    get entries(): RootTrustBaseV2[];
    /** @returns {Uint8Array[]} Copies of the canonical bytes of each entry, ascending from the genesis. */
    get raw(): Uint8Array[];
    /** @returns {RootTrustBaseV2} The release tip, the last entry. */
    get tip(): RootTrustBaseV2;
    /**
     * Strictly decode a complete bundle.
     *
     * @param {Uint8Array} bytes Tagged bundle.
     * @param {ITrustBaseBundleLimits} limits Size budget, checked before allocation.
     * @returns {Promise<TrustBaseBundle>} Decoded bundle.
     * @throws {TrustBaseEncodingError} If the bytes (or an entry) are not the deterministic encoding, or exceed the budget.
     * @throws {TrustBaseInvalidError} If an embedded entry fails a structure rule.
     * @throws {TrustBaseBundleError} If the response is not a complete, linked history from a genesis entry.
     */
    static decode(bytes: Uint8Array, limits: ITrustBaseBundleLimits): Promise<TrustBaseBundle>;
    /**
     * Encode entries as a complete bundle (status OK, no cursor, end entry id of the last entry). The inverse of {@link decode}: a decoded bundle
     * re-encodes to the same bytes. The entries are not authenticated here; a bundle that does not link is not produced.
     *
     * @param {RootTrustBaseV2[]} entries Consecutive entries ascending from the genesis, at least one.
     * @returns {Promise<Uint8Array>} Tagged bundle.
     * @throws {TrustBaseBundleError} If the list is empty or the entries do not form one linked chain of one network.
     */
    static encode(entries: readonly RootTrustBaseV2[]): Promise<Uint8Array>;
}
