/** CBOR tag of the GetTrustBase response (and of a release bundle, which is the same object). */
export declare const RESPONSE_TAG = 39015n;
/** Version of the GetTrustBase response. */
export declare const RESPONSE_VERSION = 1n;
/** Number of defined response statuses. */
export declare const STATUS_COUNT = 8n;
/**
 * The fields of a GetTrustBase response, the entries still embedded verbatim: `[1, network, status, fromEpoch, effectiveEnd, endEntryId|null,
 * [entry...], nextEpoch|null]`. Only the envelope is checked here; each user of the response applies its own rules to the contents.
 */
export interface ITrustBaseResponseFields {
    effectiveEnd: bigint;
    endEntryId: Uint8Array | null;
    entries: Uint8Array[];
    fromEpoch: bigint;
    network: number;
    nextEpoch: bigint | null;
    status: bigint;
}
/**
 * Parse the envelope of a tagged GetTrustBase response.
 *
 * @param {Uint8Array} bytes Tagged response.
 * @param {number} maxEntries Most entries accepted.
 * @returns {ITrustBaseResponseFields} The fields.
 * @throws {TrustBaseEncodingError} If the bytes are not the deterministic envelope or exceed the entry budget.
 */
export declare function parseTrustBaseResponse(bytes: Uint8Array, maxEntries: number): ITrustBaseResponseFields;
/**
 * Encode a GetTrustBase response, the entries embedded verbatim: the inverse of {@link parseTrustBaseResponse}.
 *
 * @param {ITrustBaseResponseFields} fields The fields; `entries` are complete tagged entries.
 * @returns {Uint8Array} Tagged response.
 */
export declare function encodeTrustBaseResponse(fields: ITrustBaseResponseFields): Uint8Array;
