import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
import { NetworkId } from '../../NetworkId.js';
/** Status of a GetTrustBase response. The numbers are the wire values (bft-core `gettrustbase.Status`). */
export declare enum TrustBaseStatus {
    OK = 0,
    INVALID_REQUEST = 1,
    WRONG_NETWORK = 2,
    NOT_YET_AVAILABLE = 3,
    HISTORY_MISMATCH = 4,
    LIMIT_TOO_SMALL = 5,
    BUSY = 6,
    UNAVAILABLE = 7
}
/** Budget of a range decode; `maxBytes` is checked before anything is read. */
export interface ITrustBaseRangeLimits {
    readonly maxBytes: number;
    readonly maxEntries: number;
}
/** The page caps of the GetTrustBase protocol (bft-core `gettrustbase.PageLimits`). */
export declare const TRUST_BASE_PAGE_LIMITS: ITrustBaseRangeLimits;
/**
 * One page of the GetTrustBase protocol: the response (tag 39015) to a request for the entries from an epoch on. A status other than OK carries no
 * entries and no cursor; an OK page is a contiguous ascending run of entries of the response's network starting at `fromEpoch`, linked by entry id,
 * ending at `effectiveEnd` when no cursor remains, or at the epoch before the cursor otherwise. The reference is bft-core `gettrustbase.DecodeResponse`.
 *
 * Decoding checks structure and links only. Nothing here is authenticated: `effectiveEnd` and `endEntryId` are the source's claim, and every entry
 * is authenticated by `TrustBaseHistory.append` from the latest held entry.
 */
export declare class TrustBaseRange {
    readonly status: TrustBaseStatus;
    readonly networkId: NetworkId;
    readonly fromEpoch: bigint;
    readonly effectiveEnd: bigint;
    readonly endEntryId: Uint8Array | null;
    readonly entries: readonly RootTrustBaseV2[];
    readonly nextEpoch: bigint | null;
    private constructor();
    /**
     * Strictly decode one page.
     *
     * @param {Uint8Array} bytes Tagged response.
     * @param {ITrustBaseRangeLimits} limits Size budget, checked before allocation.
     * @param {NetworkId} expectedNetwork The network that was asked for; a response for another one is refused.
     * @returns {Promise<TrustBaseRange>} The page.
     * @throws {TrustBaseEncodingError} If the bytes (or an entry) are not the deterministic encoding, or exceed the budget.
     * @throws {TrustBaseInvalidError} If an embedded entry fails a structure rule.
     * @throws {TrustBaseBundleError} If the page is inconsistent: status and cursor rules, network, start, order, links, end.
     */
    static decode(bytes: Uint8Array, limits: ITrustBaseRangeLimits, expectedNetwork: NetworkId): Promise<TrustBaseRange>;
}
