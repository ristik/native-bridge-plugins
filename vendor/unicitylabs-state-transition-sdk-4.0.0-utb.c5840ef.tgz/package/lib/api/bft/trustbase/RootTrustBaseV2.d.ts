import { NetworkId } from '../../NetworkId.js';
/**
 * One member of a trust-base epoch: its node id, compressed secp256k1 signing key and voting weight.
 */
export declare class TrustBaseMember {
    readonly nodeId: string;
    readonly weight: bigint;
    private readonly _sigKey;
    constructor(nodeId: string, sigKey: Uint8Array, weight: bigint);
    /** @returns {Uint8Array} Copy of the 33-byte compressed signing key. */
    get sigKey(): Uint8Array;
}
/**
 * Signed Unicity Trust Base entry, record version 2 (CBOR tag 39000), the reference being bft-go-base `types.RootTrustBaseV2`.
 *
 * Wire form: tag 39000 over the 10-element array
 * `[2, networkId, epoch, epochStartRound, [[nodeId, sigKey, weight]...], quorumThreshold, stateHash|null, changeRecordHash|null,
 * previousEntryId, {nodeId: signature}|null]`.
 *
 * Decoding is strict and has exactly one byte form per entry: exact tag, version and arity, bounded sizes, no trailing bytes, an absent hash is
 * null (never an empty byte string), and the input must equal the deterministic encoding of what was decoded. The entry's identity is
 * `entryId = SHA-256(sigBytes)` where sigBytes is the entry with the signature field encoded as CBOR null, so two valid signature sets over
 * the same entry give the same identity. This class checks structure only; signatures are verified by the history that appends the entry.
 */
export declare class RootTrustBaseV2 {
    private readonly _network;
    readonly epoch: bigint;
    readonly epochStartRound: bigint;
    private readonly _members;
    readonly quorumThreshold: bigint;
    private readonly _stateHash;
    private readonly _changeRecordHash;
    private readonly _previousEntryId;
    private readonly _signatures;
    static readonly CBOR_TAG = 39000n;
    /** Length of an entry id and of the hashes when present. */
    static readonly ID_LENGTH = 32;
    /** Slack over the member bound for array and map element counts, as in the reference decoder (MAX_MEMBERS + 16). */
    static readonly MAX_ELEMENTS = 272;
    /** Allocation bound while decoding; deployments admit far fewer. */
    static readonly MAX_MEMBERS = 256;
    static readonly MAX_NODE_ID_BYTES = 128;
    /** One member's weight bound, so that the sum over MAX_MEMBERS cannot overflow 64 bits. */
    static readonly MAX_WEIGHT: bigint;
    /** Length of a compressed secp256k1 signing key. */
    static readonly SIGNING_KEY_LENGTH = 33;
    static readonly VERSION = 2n;
    private static readonly SIGNATURE_VERIFIER;
    private constructor();
    /** @returns {Uint8Array|null} Copy of the change record hash, or null when absent. */
    get changeRecordHash(): Uint8Array | null;
    /** @returns {TrustBaseMember[]} The members, sorted by node id bytes. */
    get members(): TrustBaseMember[];
    /** @returns {NetworkId} The network of the entry (1..65535 on any entry that passed {@link validate}). */
    get networkId(): NetworkId;
    /** @returns {Uint8Array} Copy of the predecessor's entry id; 32 zero bytes for the genesis entry. */
    get previousEntryId(): Uint8Array;
    /** @returns {Map<string, Uint8Array>|null} Copy of the predecessor members' signatures over sigBytes, null for the genesis entry. */
    get signatures(): Map<string, Uint8Array> | null;
    /** @returns {Uint8Array|null} Copy of the state hash, or null when absent. */
    get stateHash(): Uint8Array | null;
    /** @returns {bigint} Total voting weight of the members. */
    get totalWeight(): bigint;
    /**
     * Decode and structurally validate a tagged version-2 entry.
     *
     * @param {Uint8Array} bytes Tagged entry.
     * @returns {RootTrustBaseV2} Decoded entry.
     * @throws {TrustBaseEncodingError} If the bytes are not the deterministic encoding of a version-2 entry.
     * @throws {TrustBaseInvalidError} If a structure rule fails.
     */
    static decode(bytes: Uint8Array): RootTrustBaseV2;
    private static parse;
    /**
     * @returns {Uint8Array} The tagged deterministic encoding.
     */
    encode(): Uint8Array;
    /**
     * @returns {Promise<Uint8Array>} The entry id, SHA-256 of sigBytes: independent of the signatures, what a successor links to and a pin names.
     */
    entryId(): Promise<Uint8Array>;
    /** @returns {boolean} Whether the entry has no predecessor (32 zero bytes). */
    isGenesis(): boolean;
    /**
     * @returns {Uint8Array} The bytes the predecessor's members sign: the entry with the signature field encoded as CBOR null.
     */
    sigBytes(): Uint8Array;
    /**
     * Check the entry's structure, not its signatures: epoch at least 1, the member list (sorted by node id bytes, unique, valid compressed
     * keys, positive bounded weights, bounded count), the exact quorum threshold, hash lengths, and the genesis (zero predecessor, null
     * signatures) versus non-genesis (32-byte predecessor, non-empty signature map) shape.
     *
     * @throws {TrustBaseInvalidError} If a rule fails.
     */
    validate(): void;
    /**
     * Check that this entry is a structurally valid genesis entry (zero predecessor, null signatures). A genesis is authenticated by a pin on its
     * entry id, never by signatures; the history compares the pin.
     *
     * @throws {TrustBaseInvalidError} If the entry is not a genesis entry.
     */
    verifyGenesis(): void;
    /**
     * Check the signatures of this entry's members over `data`, strictly: every supplied signature must be from a member and valid (a supplied extra
     * that is unknown or invalid fails the whole check even if the rest reach quorum), and the weight of the signers must reach the threshold.
     *
     * @param {Uint8Array} data Signed bytes.
     * @param {Map<string, Uint8Array>} signatures Signatures by node id.
     * @throws {TrustBaseSignatureError} If a signature fails or the quorum is not reached.
     */
    verifyQuorumSignatures(data: Uint8Array, signatures: Map<string, Uint8Array>): Promise<void>;
    /**
     * Verify one member's signature and return the member's weight. The signature must be a canonical recoverable signature over SHA-256 of
     * `data`: exactly 65 bytes (`r || s || recovery`), recovery id 0..3, low-S, recovering to the member's key. The 64-byte compact form is not
     * accepted. This is the rule of the seal verifier, applied to entries.
     *
     * @param {Uint8Array} data Signed bytes.
     * @param {Uint8Array} signature 65-byte signature.
     * @param {string} nodeId Signer.
     * @returns {Promise<bigint>} The signer's weight.
     * @throws {TrustBaseSignatureError} If the signer is not a member or the signature is not valid.
     */
    verifySignature(data: Uint8Array, signature: Uint8Array, nodeId: string): Promise<bigint>;
    /**
     * Check that this entry extends `previous`: not a genesis, same network, epoch previous + 1, a later start round, the predecessor id equal to
     * the entry id of `previous`, and a strict quorum of `previous`' members signing {@link sigBytes}.
     *
     * @param {RootTrustBaseV2} previous The predecessor.
     * @throws {TrustBaseChainError} If the entry does not extend the predecessor.
     * @throws {TrustBaseSignatureError} If the predecessor's members did not sign it.
     */
    verifySuccessor(previous: RootTrustBaseV2): Promise<void>;
    private encodeWithSignatures;
}
