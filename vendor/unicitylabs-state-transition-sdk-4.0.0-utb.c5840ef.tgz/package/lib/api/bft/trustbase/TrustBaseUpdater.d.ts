import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
import { TrustBaseAppendOutcome } from './TrustBaseHistory.js';
import { ITrustBaseRangeLimits } from './TrustBaseRange.js';
import { ITrustBaseSource } from '../../ITrustBaseSource.js';
import { NetworkId } from '../../NetworkId.js';
/**
 * What the updater extends: a {@link TrustBaseHistory}, or a session that adds its own rules (an authenticated fork closes it).
 */
export interface ITrustBaseUpdateTarget {
    readonly networkId: NetworkId | null;
    readonly tip: RootTrustBaseV2 | null;
    append(entry: RootTrustBaseV2): Promise<TrustBaseAppendOutcome>;
}
/** Options of {@link TrustBaseUpdater.update}. */
export interface ITrustBaseUpdateOptions {
    /** Pause between passes over the sources, in milliseconds. Default 200. */
    readonly backoffMs?: number;
    /** First epoch of the network, used only while the history is still empty. Default 1. */
    readonly genesisEpoch?: bigint;
    /** Page budget of the response decode. Default {@link TRUST_BASE_PAGE_LIMITS}. */
    readonly limits?: ITrustBaseRangeLimits;
    /** The network, required while the history is empty (it is the history's own network otherwise). */
    readonly network?: NetworkId;
    /** Passes over the sources before giving up. Default 2. */
    readonly rounds?: number;
    /** Cancels the update. */
    readonly signal?: AbortSignal;
}
/**
 * Catches a {@link TrustBaseHistory} up from untrusted sources. It follows bft-core `gettrustbase.Sync`: the entries after the held tip are fetched
 * page by page and each is appended through `TrustBaseHistory.append`, which authenticates it from the entry before it. The first page freezes the
 * end epoch and its entry id and every later page echoes them, so a source that lags or is on another history is skipped and the next continues from
 * the same cursor. An authenticated prefix is kept even when a later page fails.
 */
export declare class TrustBaseUpdater {
    /** Updates in flight, so concurrent callers of one history share one fetch. */
    private static readonly IN_FLIGHT;
    /**
     * Fetch and append the entries after the held tip.
     *
     * @param {TrustBaseHistory} history History to extend.
     * @param {ITrustBaseSource[]} sources Sources, tried in order.
     * @param {ITrustBaseUpdateOptions} [options] Options.
     * @returns {Promise<number>} The number of entries appended. 0 means the history is current as far as every source says (all answered "nothing
     *   newer"); that is a result, not an error, and nothing in it is authenticated.
     * @throws {TrustBaseUpdateError} If no source served the range: every source failed, refused, or served an entry the history refuses.
     */
    static update(history: ITrustBaseUpdateTarget, sources: readonly ITrustBaseSource[], options?: ITrustBaseUpdateOptions): Promise<number>;
    private static run;
    private static sleep;
}
