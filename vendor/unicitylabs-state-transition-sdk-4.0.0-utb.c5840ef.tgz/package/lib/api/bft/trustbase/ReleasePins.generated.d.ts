/** One row of the release table as plain data; ReleasePin.ts turns it into {@link IReleasePin}. */
export interface IReleasePinRow {
    readonly bundleHex: string;
    readonly bundleSha256: string;
    readonly genesisEntryId: string;
    readonly genesisEpoch: string;
    readonly name: string;
    readonly networkId: number;
    readonly pinnedEntryId: string;
    readonly pinnedEpoch: string;
}
export declare const RELEASE_PIN_ROWS: readonly IReleasePinRow[];
