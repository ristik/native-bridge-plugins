import { ITrustBaseHistory } from './ITrustBaseHistory.js';
import { IReleasePin } from './ReleasePin.js';
import { RootTrustBaseV2 } from './RootTrustBaseV2.js';
import { ITrustBaseBundleLimits } from './TrustBaseBundle.js';
import { TrustBaseConflictError } from './TrustBaseError.js';
import { TrustBaseAppendOutcome } from './TrustBaseHistory.js';
import { ITrustBaseStore } from './TrustBaseStore.js';
import { ITrustBaseUpdateOptions, ITrustBaseUpdateTarget } from './TrustBaseUpdater.js';
import { ITrustBaseSource } from '../../ITrustBaseSource.js';
import { NetworkId } from '../../NetworkId.js';
/** Why a cache was refused. */
export type CacheRejection = 'malformed' | 'oversize' | 'pinMismatch' | 'wrongGenesis' | 'wrongNetwork';
/**
 * What `open` reports about the cache. The session works either way: a cache that is refused or unreadable leaves the embedded history in place.
 */
export type CacheDiagnostic = {
    readonly cause: unknown;
    readonly code: 'CacheRejected';
    readonly reason: CacheRejection;
} | {
    readonly cause: unknown;
    readonly code: 'CacheUnavailable';
};
/** The outcome of {@link TrustBaseSession.flush}. A failed save does not undo the verified in-memory history. */
export type FlushResult = {
    /** A damaged cache the flush found and replaced, reported as `open` reports it. */
    readonly diagnostics: readonly CacheDiagnostic[];
    readonly status: 'saved';
    /** Whether the store was written; false when it already had everything or nothing here was unsaved. */
    readonly wrote: boolean;
} | {
    readonly error: unknown;
    readonly status: 'pending';
};
export interface ITrustBaseSessionOptions {
    /** Budget of every bundle the session loads or saves. Default {@link TRUST_BASE_BUNDLE_LIMITS}. */
    readonly limits?: ITrustBaseBundleLimits;
    /** Cancels the open. Nothing is published from a cancelled open. */
    readonly signal?: AbortSignal;
}
export interface IOpenPublicOptions extends ITrustBaseSessionOptions {
    /** An explicit pin that extends the built-in one (a newer checkpoint). Older or conflicting ones are refused. */
    readonly override?: IReleasePin;
    /** The release table. Default {@link RELEASE_PINS}; replacing it is for the release build and its tests, not for applications. */
    readonly table?: readonly IReleasePin[];
}
/**
 * A trust-base history together with its release pin and its cache. It starts from the pinned release history, merges whatever compatible cache the
 * store holds (strictly re-verified: nothing in a store is trusted for its name, age or revision), takes later entries through {@link append} and
 * {@link refresh}, and saves one complete bundle by compare-and-swap.
 *
 * Verification reads {@link history}, a read-only view. An authenticated fork after the release checkpoint closes the session: every later append,
 * refresh and read of the view fails with {@link HistoryConflictedError} (the live session only; an untrusted store cannot make this survive
 * deletion or a fresh process, so the application records the incident). A mismatch in the pinned prefix is refused without closing it.
 */
export declare class TrustBaseSession implements ITrustBaseUpdateTarget {
    private readonly _history;
    private readonly _pin;
    private readonly _store;
    private readonly _key;
    private readonly _limits;
    readonly diagnostics: readonly CacheDiagnostic[];
    private _blocked;
    private _conflict;
    private _dirty;
    private _queue;
    private _repair;
    private readonly _view;
    private constructor();
    /** @returns {TrustBaseConflictError|null} The authenticated fork that closed the session, with its evidence, or null. */
    get conflict(): TrustBaseConflictError | null;
    /** @returns {boolean} Whether entries are held that the store does not have yet (a failed or not yet attempted save). */
    get dirty(): boolean;
    /** @returns {ITrustBaseHistory} The read-only view verification uses. */
    get history(): ITrustBaseHistory;
    /** @returns {string} The store key. */
    get key(): string;
    /** @returns {NetworkId|null} The network. */
    get networkId(): NetworkId | null;
    /** @returns {RootTrustBaseV2|null} The latest held entry. */
    get tip(): RootTrustBaseV2 | null;
    /**
     * Open the session of a local or test network from that deployment's own GetTrustBase bundle (genesis to tip) alone: the pin is derived from the
     * bundle ({@link releasePinFromBundle}), the namespace is the fixed `local` (never `public`), and there is no release lineage check. Everything
     * else is as {@link TrustBaseSession.openPrivate}: the bundle and every cached or fetched entry are verified strictly.
     *
     * @param {Uint8Array} bundle Bundle bytes from your deployment (tag 39015, complete, from the genesis entry).
     * @param {ITrustBaseStore} store Store.
     * @param {ITrustBaseSessionOptions} [options] Options.
     * @returns {Promise<{session: TrustBaseSession, diagnostics: CacheDiagnostic[]}>} The session and what was found in the cache.
     * @throws {ReleasePinInvalidError} If the bundle is not a complete valid history.
     */
    static openLocal(bundle: Uint8Array, store: ITrustBaseStore, options?: ITrustBaseSessionOptions): Promise<{
        diagnostics: CacheDiagnostic[];
        session: TrustBaseSession;
    }>;
    /**
     * Open the session of a private or test network under an explicit authority: its own pin and a namespace of its own. This chooses another
     * authority; it does not switch any check off.
     *
     * @param {string} namespace Trust namespace, 1..64 bytes, no `/`, and not `public`.
     * @param {IReleasePin} pin The pin, with the full embedded bundle.
     * @param {ITrustBaseStore} store Store.
     * @param {ITrustBaseSessionOptions} [options] Options.
     * @returns {Promise<{session: TrustBaseSession, diagnostics: CacheDiagnostic[]}>} The session and what was found in the cache.
     * @throws {ReleasePinInvalidError} If the pin is invalid.
     */
    static openPrivate(namespace: string, pin: IReleasePin, store: ITrustBaseStore, options?: ITrustBaseSessionOptions): Promise<{
        diagnostics: CacheDiagnostic[];
        session: TrustBaseSession;
    }>;
    /**
     * Open the session of a public network: the release table row, or an override that extends it.
     *
     * @param {NetworkId} network Network.
     * @param {ITrustBaseStore} store Store.
     * @param {IOpenPublicOptions} [options] Options.
     * @returns {Promise<{session: TrustBaseSession, diagnostics: CacheDiagnostic[]}>} The session and what was found in the cache.
     * @throws {UnknownNetworkError} If the network has no pin.
     * @throws {ReleasePinInvalidError} If the pin (or the override) is invalid. Never rescued by the cache.
     */
    static openPublic(network: NetworkId, store: ITrustBaseStore, options?: IOpenPublicOptions): Promise<{
        diagnostics: CacheDiagnostic[];
        session: TrustBaseSession;
    }>;
    private static open;
    /**
     * Add one entry, authenticated from the held entry before it.
     *
     * @param {RootTrustBaseV2} entry Entry.
     * @returns {Promise<TrustBaseAppendOutcome>} `appended` or `noop`.
     * @throws {HistoryConflictedError} If the session is closed by a fork.
     * @throws {TrustBaseConflictError} If this entry is an authenticated fork after the checkpoint; the session is closed.
     * @throws {TrustBasePinMismatchError} If it differs from the pinned prefix.
     * @throws {TrustBaseError} Any other refusal of {@link TrustBaseHistory.append}.
     */
    append(entry: RootTrustBaseV2): Promise<TrustBaseAppendOutcome>;
    /** @returns {Promise<Uint8Array>} The held history as one complete bundle. Available on a conflicted session too. */
    exportBundle(): Promise<Uint8Array>;
    /**
     * Save the held history if it is not saved yet. Writes one complete bundle by compare-and-swap: the stored bytes are reread and fully validated,
     * a compatible longer suffix is imported, and a changed revision is retried up to three times.
     *
     * A clean session (nothing unsaved, no damaged or blocked cache to deal with) flushes without reading the store: `saved` then means nothing
     * held here is unsaved, not that the store matches. A suffix another writer saved, or a fork in the store, is found when the session is opened
     * again or when something here is saved.
     *
     * @returns {Promise<FlushResult>} `saved` (with the damaged cache it replaced, if any, and whether it wrote), or `pending` with the reason (the
     *   history stays dirty; the application may retry).
     */
    flush(): Promise<FlushResult>;
    /**
     * Fetch the entries after the held tip from the sources (see {@link TrustBaseUpdater}) and save the result.
     *
     * @param {ITrustBaseSource[]} sources Sources, tried in order.
     * @param {ITrustBaseUpdateOptions} [options] Update options.
     * @returns {Promise<{appended: number, flush: FlushResult}>} Entries appended and the save outcome.
     * @throws {HistoryConflictedError} If the session is closed by a fork.
     * @throws {TrustBaseConflictError} If a source served an authenticated fork.
     * @throws {TrustBaseUpdateError} If no source served the range.
     */
    refresh(sources: readonly ITrustBaseSource[], options?: ITrustBaseUpdateOptions): Promise<{
        appended: number;
        flush: FlushResult;
    }>;
    private appendNow;
    /**
     * A different entry for a held epoch is not yet a fork: the pinned prefix is settled by the checkpoint, and after it the offered entry has to
     * verify against the held predecessor before it counts as evidence. Only then the session closes.
     */
    private classifyConflict;
    private enqueue;
    private flushNow;
    /**
     * Give entries that were authenticated in a chain of their own to this session through {@link appendNow}: those it holds are no-ops (the first
     * held witness stays), those after its tip are appended, a different one is a pin mismatch or an authenticated fork.
     */
    private integrate;
    /** @returns {Promise<boolean>} False when the entries differ from the pinned prefix (a cache the checkpoint has superseded), true when integrated. */
    private integrateCompatible;
    /**
     * Decode stored bytes and authenticate them from the pinned genesis, in a history of their own: nothing reaches the session unless all of it
     * is valid.
     */
    private parseCache;
    private throwIfConflicted;
}
