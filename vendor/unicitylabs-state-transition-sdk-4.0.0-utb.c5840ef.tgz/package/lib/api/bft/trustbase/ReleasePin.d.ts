import { ITrustBaseBundleLimits } from './TrustBaseBundle.js';
import { TrustBaseHistory } from './TrustBaseHistory.js';
import { NetworkId } from '../../NetworkId.js';
/**
 * Initial load budget of a bundle (a release's, a cache's): 16 MiB, 4,096 entries, and the 128 KiB per entry of {@link TrustBaseBundle}. It is
 * resource policy, not a trust rule: an application may configure more or less, and nothing is pruned to fit.
 */
export declare const TRUST_BASE_BUNDLE_LIMITS: ITrustBaseBundleLimits;
/**
 * A release pin: the complete trust-base history of a network from its genesis to exactly the pinned release tip, and the identities that bind it.
 * It comes from the authenticated software release (or, for a private network, from the application's own configuration), never from a digest
 * shipped beside an untrusted download.
 */
export interface IReleasePin {
    /** SHA-256 of {@link embeddedBundle}. Not the entry id. */
    readonly bundleSha256: Uint8Array;
    /** The complete bundle, genesis to the pinned tip. */
    readonly embeddedBundle: Uint8Array;
    /** Entry id of the genesis entry. */
    readonly genesisEntryId: Uint8Array;
    readonly genesisEpoch: bigint;
    readonly networkId: NetworkId;
    /** Entry id of the release tip. */
    readonly pinnedEntryId: Uint8Array;
    readonly pinnedEpoch: bigint;
}
/**
 * A pin that has been verified: structure, every predecessor signature, both ids, epochs and digest. Holds copies, so the pin the caller passed can
 * change afterwards without effect.
 */
export declare class VerifiedReleasePin {
    readonly pin: IReleasePin;
    private readonly _ids;
    private constructor();
    /** @returns {bigint} The pinned epoch. */
    get pinnedEpoch(): bigint;
    /**
     * Verify a pin and build the history it embeds.
     *
     * @param {IReleasePin} pin The pin.
     * @param {ITrustBaseBundleLimits} [limits] Budget of the embedded bundle.
     * @returns {Promise<{verified: VerifiedReleasePin, history: TrustBaseHistory}>} The verified pin and a fresh history holding its entries.
     * @throws {ReleasePinInvalidError} If anything about the pin does not hold.
     */
    static verify(pin: IReleasePin, limits?: ITrustBaseBundleLimits): Promise<{
        history: TrustBaseHistory;
        verified: VerifiedReleasePin;
    }>;
    /** @returns {Uint8Array|null} Copy of the entry id of the checkpoint at `epoch`, or null outside the pinned history. */
    idAt(epoch: bigint): Uint8Array | null;
    /**
     * Whether `candidate` is a continuation of this pin: the same network and genesis, containing this checkpoint at this epoch, at an equal or later
     * pinned epoch.
     *
     * @param {VerifiedReleasePin} candidate Verified candidate.
     * @returns {boolean} True if the candidate extends this pin.
     */
    isExtendedBy(candidate: VerifiedReleasePin): boolean;
}
/**
 * The release table of this SDK build, one row per public network: mainnet (1) and testnet2 (4), each the complete history from its genesis to the
 * pinned release tip. The rows are generated (`scripts/release-pins/generate.mjs`, from `release-pins/manifest.json` and the bundles it names, with
 * a CI check that regeneration leaves no diff) and are verified again, strictly, when a session opens. The network of the old testnet 2 has no row.
 */
export declare const RELEASE_PINS: readonly IReleasePin[];
/**
 * The pin of a local or test network, derived from that deployment's own GetTrustBase bundle (genesis to tip): the network, the genesis and tip
 * epochs and entry ids and the digest all come from the bundle. This trusts the bundle you pass (you got it from your own deployment); it checks
 * it strictly all the same, and it is not a release lineage check. Use it with {@link TrustBaseSession.openLocal}, which keeps the cache of a
 * local network apart from every public one.
 *
 * @param {Uint8Array} bundle Complete bundle bytes (tag 39015, status OK, from the genesis entry, no continuation cursor).
 * @param {ITrustBaseBundleLimits} [limits] Budget of the bundle.
 * @returns {Promise<IReleasePin>} The pin.
 * @throws {ReleasePinInvalidError} If the bundle is not a complete, internally valid history.
 */
export declare function releasePinFromBundle(bundle: Uint8Array, limits?: ITrustBaseBundleLimits): Promise<IReleasePin>;
/**
 * Select and verify the pin of a public network: the table row, optionally replaced by an override that extends it.
 *
 * @param {NetworkId} network Network.
 * @param {readonly IReleasePin[]} table Release table.
 * @param {IReleasePin|undefined} override Explicit pin that must extend the built-in row.
 * @param {ITrustBaseBundleLimits} limits Budget.
 * @returns {Promise<{verified: VerifiedReleasePin, history: TrustBaseHistory}>} The pin to use and a history holding it.
 * @throws {UnknownNetworkError} If the network has no row.
 * @throws {ReleasePinInvalidError} If the row or the override is invalid.
 * @throws {TrustBasePinMismatchError} If the override does not extend the row.
 */
export declare function selectPublicPin(network: NetworkId, table: readonly IReleasePin[], override: IReleasePin | undefined, limits: ITrustBaseBundleLimits): Promise<{
    history: TrustBaseHistory;
    verified: VerifiedReleasePin;
}>;
