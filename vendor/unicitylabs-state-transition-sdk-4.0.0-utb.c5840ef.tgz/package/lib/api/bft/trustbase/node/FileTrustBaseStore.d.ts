import { IStoredTrustBase, ITrustBaseStore } from '../TrustBaseStore.js';
/**
 * A directory of cache files for Node, shared by processes (and by the Rust file store: the names and the protocol are the same). Import it from
 * its own module; nothing in the core imports it, so browser builds stay clean.
 *
 * One file per key, `utb-<hex sha256(key)>.cbor`. Readers take no lock: a replacement is an atomic rename, so a read sees the old or the new
 * bytes whole. A compare-and-swap takes the lock `<stem>.lock`, a directory made with `mkdir` (it exists, or it does not: `EEXIST` is
 * {@link CacheBusyError} at once, never waited on and never stolen, and a lock a crash left behind stays until the application removes it),
 * rereads the file, compares its SHA-256 with the expected revision, writes a temporary file `<stem>.tmp-<pid>-<n>` created exclusively in the same
 * directory, syncs it, renames it over the file, syncs the directory where the platform allows, and removes the lock in `finally`. A crash before
 * the rename leaves the old bytes; after it, the complete new ones.
 */
export declare class FileTrustBaseStore implements ITrustBaseStore {
    private readonly _directory;
    private readonly _casMaxBytes;
    constructor(_directory: string, _casMaxBytes?: number);
    /**
     * @param {string} key Cache key.
     * @returns {string} File stem shared with the Rust store.
     */
    static stem(key: string): string;
    /** @inheritDoc */
    compareAndSwap(key: string, expectedRevision: string | null, bytes: Uint8Array): Promise<'changed' | 'written'>;
    /** @inheritDoc */
    read(key: string, maxBytes: number): Promise<IStoredTrustBase | null>;
    /** Under the lock no other writer has a temporary file in flight, so what a crashed one left is garbage. */
    private removeStaleTemporaries;
    /** The new name is only durable once the directory is; platforms that cannot sync a directory (Windows) go without. */
    private syncDirectory;
}
