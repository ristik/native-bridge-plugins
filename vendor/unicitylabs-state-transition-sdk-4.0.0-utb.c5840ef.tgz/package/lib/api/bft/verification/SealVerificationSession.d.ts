import { ISealAuthenticator } from './ISealAuthenticator.js';
import { UnicitySealQuorumSignaturesVerificationRule } from './rule/UnicitySealQuorumSignaturesVerificationRule.js';
import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import { NetworkId } from '../../NetworkId.js';
import { SdkError } from '../../SdkError.js';
import { ITrustBaseHistory } from '../trustbase/ITrustBaseHistory.js';
import { UnicitySeal } from '../UnicitySeal.js';
/**
 * The session has as many distinct seal checks running as it allows. A resource limit of the operation, not a
 * verification result: nothing about the seal is known. Retry later or verify with a larger `maxInFlight`.
 */
export declare class SealVerificationBusyError extends SdkError<'SealVerificationBusyError'> {
    readonly maxInFlight: number;
    readonly name: "SealVerificationBusyError";
    /**
     * @param {number} maxInFlight The session's bound.
     */
    constructor(maxInFlight: number);
}
/**
 * Counters of a {@link SealVerificationSession}.
 */
export interface ISealVerificationSessionStats {
    /** Requests that joined a check already in flight. */
    readonly inFlightJoins: number;
    /** Requests served from a completed successful check. */
    readonly memoHits: number;
    /** Distinct quorum signature verifications executed (cache and in-flight misses). */
    readonly quorumChecks: number;
}
/**
 * Seal authentication scoped to one operation (e.g. verification of one token or one consolidation attempt).
 *
 * Every shard certificate and transaction proof of a consolidated token carries the same master seal, so each leaf
 * check would repeat the same quorum signature work. The session authenticates a complete seal once per
 * (policy, authority, seal) and serves repeats from a bounded memo of *successes*; checks that are still running are
 * shared too, so concurrent leaf checks do not all miss and each repeat the signatures. Failures are never memoized
 * and a failed or throwing check is dropped from the in-flight set.
 *
 * The authority is a trust-base history: each seal is checked against the entry of its own epoch. The memo key commits
 * to the length-delimited complete seal encoding (signatures included, so altered signature witnesses cannot hit an
 * entry), the complete encoding of that entry (network, epoch, start round, members, weights, quorum) and the verifier
 * policy id. Network, epoch and round of the seal are always placed in the history, independently of the memo.
 *
 * The session owns exactly one quorum rule (and so one signature verifier); it is not shared between workers or
 * operations and no verified flag can be supplied from outside.
 */
export declare class SealVerificationSession implements ISealAuthenticator {
    private readonly quorumRule;
    private readonly options;
    /** Minimum seal timestamp: Thursday, April 20, 2023 6:11:24 AM GMT+00:00. */
    static readonly GENESIS_TIME = 1681971084n;
    private readonly authorityIds;
    private readonly completed;
    private readonly counters;
    private readonly customRule;
    private readonly history;
    private readonly inFlight;
    private readonly policy;
    /**
     * @param {ITrustBaseHistory} history Trusted authority the seals are authenticated against: the held trust-base history.
     * @param {UnicitySealQuorumSignaturesVerificationRule} quorumRule Quorum rule, runs on every distinct miss.
     * @param {object} [options] Options.
     * @param {number} [options.maxEntries] Upper bound on retained successful checks, the oldest is evicted first.
     * @param {number} [options.maxInFlight] Upper bound on distinct checks running at once, further ones throw.
     * @param {string} [options.policy] Identifier of the verifier policy, part of the memo key.
     * @throws {Error} If `maxEntries` is not a positive integer.
     */
    constructor(history: ITrustBaseHistory, quorumRule: UnicitySealQuorumSignaturesVerificationRule, options?: {
        readonly maxEntries?: number;
        readonly maxInFlight?: number;
        readonly policy?: string;
    });
    /**
     * @returns {number} Number of distinct entries whose identity this session built (once each).
     */
    get authorityBuilds(): number;
    /**
     * @returns {string} Identity of the anchored authority (the genesis pin and the held tip) and the verifier policy. It changes when the
     *   history grows, which only costs a cache miss.
     */
    get identity(): string;
    /**
     * @returns {ITrustBaseHistory} The trust-base history this session was created for.
     */
    get sourceTrustBase(): ITrustBaseHistory;
    /**
     * @returns {ISealVerificationSessionStats} Snapshot of the counters.
     */
    get stats(): ISealVerificationSessionStats;
    /**
     * @returns {NetworkId|null} Network of the trusted authority, or null while the history is empty.
     */
    get trustBaseNetwork(): NetworkId | null;
    /**
     * Native seal structural validation (bft-go-base `UnicitySeal.IsValid`): hash present, root round at least 1,
     * timestamp not before the genesis time, signatures present with a signer id and bytes each. Independent of any
     * trust base; signer map entries are outside the signed payload, so this must hold before a success is returned or
     * remembered.
     *
     * @param {UnicitySeal} seal Seal.
     * @returns {string|null} Failure description or null if the seal is structurally valid.
     */
    static checkSealStructure(seal: UnicitySeal): string | null;
    /**
     * Authenticate the seal: structure, then its place in the history (network, the entry of its epoch, the round inside that epoch), then the
     * quorum signatures of that entry, once per distinct seal. A seal of an epoch the history does not hold fails with the typed no-entry result.
     *
     * @param {UnicitySeal} seal Seal.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Outcome.
     */
    authenticate(seal: UnicitySeal): Promise<VerificationResult<VerificationStatus>>;
    private keyFor;
    private remember;
}
