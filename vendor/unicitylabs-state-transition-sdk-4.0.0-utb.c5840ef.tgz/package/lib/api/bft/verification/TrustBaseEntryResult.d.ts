import { VerificationResult } from '../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../verification/VerificationStatus.js';
import { RootTrustBaseV2 } from '../trustbase/RootTrustBaseV2.js';
/**
 * Result of picking the trust-base entry a seal is checked against. On success it carries the entry.
 */
export declare class TrustBaseEntryResult extends VerificationResult<VerificationStatus> {
    readonly entry: RootTrustBaseV2 | null;
    constructor(status: VerificationStatus, message: string, entry: RootTrustBaseV2 | null);
}
/**
 * The typed "no entry for this epoch" failure: the held history has no entry for the epoch of a seal. The caller can obtain the missing entries
 * (the update step of a later release), append them to the history, and verify again. It is a different failure from a bad signature or a seal
 * outside its epoch: nothing is wrong with the proof as far as is known.
 */
export declare class NoTrustBaseEntryResult extends TrustBaseEntryResult {
    readonly epoch: bigint;
    readonly tipEpoch: bigint | null;
    constructor(epoch: bigint, tipEpoch: bigint | null);
}
/**
 * Find the typed no-entry failure anywhere in a verification trace.
 *
 * @param {VerificationResult<unknown>} result Any verification result.
 * @returns {NoTrustBaseEntryResult|null} The first no-entry failure in the trace, or null when the failure (if any) is of another kind.
 */
export declare function findNoTrustBaseEntry(result: VerificationResult<unknown>): NoTrustBaseEntryResult | null;
