import { ITrustBaseHistory } from '../../trustbase/ITrustBaseHistory.js';
import { UnicitySeal } from '../../UnicitySeal.js';
import { TrustBaseEntryResult } from '../TrustBaseEntryResult.js';
/**
 * Rule that picks the trust-base entry of the seal's epoch and checks the seal belongs to it: the same network, and a root chain round inside
 * the epoch's interval (from the entry's start round, up to the start round of the held successor, if there is one).
 */
export declare class UnicitySealTrustBaseEntryRule {
    /**
     * @param {ITrustBaseHistory} history Held trust-base history.
     * @param {UnicitySeal} seal Seal to place.
     * @returns {TrustBaseEntryResult} The entry on success; a {@link NoTrustBaseEntryResult} when the epoch is above the held tip or the history is empty; an ordinary failure for another network or an epoch before the genesis.
     */
    static verify(history: ITrustBaseHistory, seal: UnicitySeal): TrustBaseEntryResult;
}
