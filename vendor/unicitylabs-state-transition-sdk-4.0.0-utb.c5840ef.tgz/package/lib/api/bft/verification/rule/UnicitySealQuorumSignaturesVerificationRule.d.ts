import { ISignatureVerifier } from '../../../../crypto/ISignatureVerifier.js';
import { Signature } from '../../../../crypto/secp256k1/Signature.js';
import { VerificationResult } from '../../../../verification/VerificationResult.js';
import { VerificationStatus } from '../../../../verification/VerificationStatus.js';
import { RootTrustBaseV2 } from '../../trustbase/RootTrustBaseV2.js';
import { UnicitySeal } from '../../UnicitySeal.js';
import { VerifiedSealCache } from '../VerifiedSealCache.js';
/**
 * Rule to verify that the UnicitySeal contains valid quorum signatures.
 *
 * Signature verification dominates inclusion-proof verification, and every proof
 * certified in the same aggregator round carries the same seal, so the rule can
 * memoise verified seals in a caller-supplied {@link VerifiedSealCache}.
 */
export declare class UnicitySealQuorumSignaturesVerificationRule {
    private readonly signatureVerifier;
    private readonly cache?;
    /** Longest signer identifier of a seal's signature map. */
    static readonly MAX_NODE_ID_BYTES = 128;
    /** Supplied signatures of one seal, counted whoever signed (unknown signers and bad values included): a resource bound, 256 as the committee ceiling (§49). */
    static readonly MAX_SIGNATURES = 256;
    /** The signature count this rule refuses above ({@link MAX_SIGNATURES} unless configured). */
    readonly maxSignatures: number;
    /**
     * @param {ISignatureVerifier<Signature>} signatureVerifier Verifier for the root-node signatures.
     * @param {VerifiedSealCache} [cache] Memo for verified seals; omit to verify every seal afresh.
     * @param {object} [options] Options.
     * @param {number} [options.maxSignatures] Most supplied signatures per seal, default {@link MAX_SIGNATURES} (256). The B1 bridge profile keeps 16,
     *   a gas bound of its registry; a verifier that must refuse exactly what B1 refuses passes 16.
     */
    constructor(signatureVerifier: ISignatureVerifier<Signature>, cache?: VerifiedSealCache | undefined, options?: {
        readonly maxSignatures?: number;
    });
    /**
     * The format checks of a seal's signature map (count and identifier length), independent of any authority.
     *
     * @param {UnicitySeal} seal Seal.
     * @param {number} [maxSignatures] Signature ceiling, default {@link MAX_SIGNATURES}.
     * @returns {string|null} Why the seal is malformed, or null.
     */
    static checkSignatureFormat(seal: UnicitySeal, maxSignatures?: number): string | null;
    /**
     * Build the cache key for a (trust-base entry, seal) pair.
     *
     * Both halves are addressed by content, and both are load-bearing:
     *
     * 1. The seal is keyed on its **complete** encoding.
     *    {@link UnicitySeal.calculateHash} hashes it *without* the signatures — it
     *    is the digest the root nodes sign — so keying on that would let a seal's
     *    valid signatures be swapped for garbage and still hit a cached OK.
     *    `toCBOR()` encodes the signatures too, so a hit means identical bytes.
     * 2. The entry decides the outcome through its members, their weights and
     *    the quorum threshold, and is keyed by content: its complete tagged
     *    encoding (signatures included), not its identity.
     *
     * The signature verifier needs no representation here: a cache is reachable
     * only through the rule that owns it, and a rule owns exactly one verifier.
     *
     * Both are folded into a single digest through a CBOR array: the framing is
     * what makes one hash safe, since concatenating two variable-length encodings
     * raw would let a different (trust base, seal) split produce the same bytes.
     *
     * @param {RootTrustBaseV2} entry Trust-base entry the seal is verified against.
     * @param {UnicitySeal} unicitySeal Seal being verified.
     * @returns {Promise<string>} Cache key.
     */
    private static cacheKeyFor;
    /**
     * Verify the unicity seal carries valid signatures of members whose weight reaches the entry's quorum threshold. A signer that is not a
     * member, or a signature that does not verify, counts zero (the upstream seal rule); each member counts once, as the signatures are a map.
     *
     * @param {RootTrustBaseV2} entry Trust-base entry of the seal's epoch.
     * @param {UnicitySeal} unicitySeal Seal to verify.
     * @returns {Promise<VerificationResult<VerificationStatus>>} Verification outcome.
     */
    verify(entry: RootTrustBaseV2, unicitySeal: UnicitySeal): Promise<VerificationResult<VerificationStatus>>;
    private verifySignature;
}
