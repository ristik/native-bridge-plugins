import { ProofUnavailableReason } from './ConsolidationResult.js';
import { ShardRouting } from './ShardRouting.js';
import { ShardId } from '../api/bft/ShardId.js';
import { SealVerificationSession } from '../api/bft/verification/SealVerificationSession.js';
import { CertificationData } from '../api/CertificationData.js';
import { ILongPollOptions } from '../api/ILongPollOptions.js';
import { InclusionProof } from '../api/InclusionProof.js';
import { InclusionProofResponse } from '../api/InclusionProofResponse.js';
/**
 * One original outer-history proof: the signed certification data and the proof that certified it.
 */
export interface IConsolidationItem {
    readonly certificationData: CertificationData;
    readonly proof: InclusionProof;
}
/**
 * Options of one consolidation attempt.
 */
export interface IConsolidationOptions {
    /** Master shard to use instead of the shard of the newest original proof; it must take part. */
    readonly master?: ShardId;
    /**
     * Opt in to one long poll on the master shard's **latest** request, off by default. `true` asks for the preferred 20s
     * window, an object tunes it (`windowMs`, `marginMs`, the same shape as `waitInclusionProof`'s `longPoll`); either way
     * the wait is clamped to what the total deadline leaves minus the margin, and omitted when nothing fits. It applies to
     * that one request only: exact-root requests to the other shards never wait, and nothing is polled again, so an attempt
     * is still one request per shard. The one exception is the aggregator's generic `malformed_params` answer to a wait it
     * does not know: the request is repeated once without it and both requests are counted in the summary.
     */
    readonly masterLongPoll?: boolean | ILongPollOptions;
    /** Upper bound on concurrent exact-root requests of the second wave. Default 4. */
    readonly maxParallel?: number;
    /** Aborts the attempt and every outstanding request. */
    readonly signal?: AbortSignal;
    /** Total deadline of the attempt in milliseconds. Default 10 000. */
    readonly timeoutMs?: number;
}
/**
 * Work counters of an attempt. `quorumChecks` is the master seal's quorum check (the seal checks of the original
 * proofs are reported separately).
 */
export interface IConsolidationCounters {
    readonly bodyChecks: number;
    readonly evidenceQuorumChecks: number;
    readonly leafChecks: number;
    readonly quorumChecks: number;
}
/**
 * Proofs rebuilt under one master seal.
 */
export interface IConsolidatedProofs {
    readonly counters: IConsolidationCounters;
    /** Root chain round of the master seal. */
    readonly masterRound: bigint;
    readonly masterShard: ShardId;
    /** Requests made and request waves (one wave when a single shard takes part, otherwise two). */
    readonly requests: number;
    /** Highest root chain round among the original proofs (R_min). */
    readonly requiredRound: bigint;
    /** Replacement proofs in input order: original certification data and reference time, new unicity certificate. */
    readonly responses: readonly InclusionProofResponse[];
    readonly shards: number;
    readonly waves: number;
}
/**
 * Result of one attempt: rebuilt proofs, or an explicit unavailable outcome of the service.
 */
export type ConsolidationAttempt = ({
    readonly status: 'consolidated';
} & IConsolidatedProofs) | {
    readonly detail?: string;
    readonly proofIndexes?: readonly number[];
    readonly reason: ProofUnavailableReason;
    readonly retryable: boolean;
    readonly status: 'unavailable';
};
/**
 * Master-first consolidation of original outer-history proofs into proofs under one master seal.
 *
 * One attempt: authenticate the original proofs and derive R_min (the highest root round among them); one `latest`
 * batch from the master shard, whose partition view is authenticated under the anchored authority (network, exact
 * epoch, round at least the epoch start, quorum) and must be at least R_min; then one exact-root batch per other
 * participating shard, bounded parallel, at the roots the authenticated view commits to. Every output certificate is
 * derived from the authenticated view and carries the identical master seal; every proof is checked against its
 * original input. One total deadline governs the attempt and the abort signal reaches every request. There is no
 * retry, no chunking, no chase of newer seals, and nothing is ever submitted.
 */
export declare class ProofConsolidator {
    private readonly routing;
    private readonly session;
    static readonly DEFAULT_MAX_PARALLEL = 4;
    static readonly DEFAULT_TIMEOUT_MS = 10000;
    private readonly pins;
    /**
     * @param {ShardRouting} routing Trusted routing of the partition.
     * @param {SealVerificationSession} session Operation scoped seal authentication, anchored to the trusted authority.
     */
    constructor(routing: ShardRouting, session: SealVerificationSession);
    /**
     * The wait that fits the attempt deadline, or none: `min(window, left - margin)`, with the transport timeout of the
     * call that carries it: `wait + margin`, never more than the attempt has left.
     */
    private static masterWait;
    private static requestFailure;
    /**
     * Run one attempt. Inputs are never modified.
     *
     * @param {IConsolidationItem[]} items Original outer-history proofs.
     * @param {IConsolidationOptions} [options] Attempt options.
     * @returns {Promise<ConsolidationAttempt>} Rebuilt proofs or an unavailable outcome.
     * @throws {ConsolidationError} Typed failure: cancellation, deadline, transport, server, response or integrity.
     */
    consolidate(items: readonly IConsolidationItem[], options?: IConsolidationOptions): Promise<ConsolidationAttempt>;
    /**
     * The master target of an unsharded partition: the ordinary certificate itself. With the empty shard id and no
     * shard tree siblings the shard tree is the one leaf, so the certificate already commits to everything a one-leaf
     * partition view would repeat; no view is received, decoded, authenticated or derived. This is not an optional
     * view: it holds only for a certificate that is for the configured partition, the empty shard (one routed group,
     * no peers, scheme empty) and an empty shard path, and it passes the same pins, structure, seal-hash path and strict
     * seal authentication (network, epoch interval, quorum) as any other target. Anything else is an integrity error,
     * never a fallback.
     */
    private authenticateDirect;
    /**
     * Authenticate every original proof (shard and partition path to its seal hash, leaf rules, seal structure, then the seal
     * placed in the trusted history: its network, the entry of its epoch, the round inside that epoch, and the quorum of that
     * entry) and derive R_min: the highest root round among them. All seals must be of one network.
     */
    private authenticateEvidence;
    /** The master target from its authenticated partition view: one leaf per shard, every certificate derived from it. */
    private authenticateView;
    /** The source proofs are rooted at the state the master view commits to, for this very shard and partition. */
    private checkExactRoot;
    /** Structure of a certificate for the configured partition and shard (the native `IsValid` checks). */
    private checkUcShape;
    /** The batch's elements as certified proofs carrying byte-identical local certificates. */
    private commonUc;
    private fetch;
    /** Exact-root requests with bounded parallelism; the first failure aborts the rest, reported deterministically. */
    private fetchAll;
    /** Route every state to its endpoint, groups in canonical shard order, indexes in input order. */
    private group;
    /**
     * The per input rules, shared by the original proofs and the replacements: expiry, reference time not after the
     * certificate's timestamp, shard membership and the path to the target state root.
     */
    private leafRules;
    private pickMaster;
    /** One replacement proof: original certification data and reference time, proof path of the response, target UC. */
    private replace;
    private run;
}
