import { ISignatureVerifier } from '../../../../crypto/ISignatureVerifier.js';
import { Signature } from '../../../../crypto/secp256k1/Signature.js';
import { IEpochCommittee, ITrustBaseAuthority } from '../../trustbase/TrustBaseAuthority.js';
import { UnicitySeal } from '../../UnicitySeal.js';
import { CertificateVerificationResult } from '../CertificateVerdict.js';
import { VerifiedSealCache } from '../VerifiedSealCache.js';
/**
 * Rule to verify that a unicity seal is authenticated by the trust-base committee of its own epoch, with upstream's seal rule (also the rule of
 * bft-core `b1ref`, the any-age bridge verifier and the native shard path), so that a wallet accepts exactly the seals the chain accepts:
 *
 * 1. **Format** (the input is refused, `malformed`): at most {@link MAX_SIGNATURES} signatures and signer identifiers of at most
 *    {@link MAX_NODE_ID_BYTES} bytes. A signature value of any other width is a well-formed witness, not a format failure.
 * 2. **Authority**: signatures present; the seal's network; the committee of `seal.epoch` (an epoch after the latest held one is
 *    `no_entry_for_epoch`, retryable; one before the first held epoch is invalid); the root round inside the epoch's interval, `start ≤ r` and `r < end`
 *    once the next epoch is held. An empty signature value or an empty signer identifier is `invalid`: upstream's seal validation refuses it.
 * 3. **Signatures**: each supplied signature is judged alone. An unknown signer, and a signature that is not exactly 65 bytes `r‖s‖v` with
 *    `1 ≤ r < n`, `1 ≤ s ≤ n/2`, `v` in 0..3 and recovering (over the seal hash) to the member's listed key, contribute zero and never fail the
 *    seal. The supplied recovery byte is binding: it is never discarded, normalized or replaced by the other parity. The weights of the valid
 *    signatures must reach the committee threshold.
 *
 * A trust-base ENTRY's witnesses are a different object and stay strict (a bad extra refuses a successor entry). Signature work dominates proof
 * verification and every proof of an aggregator round carries the same seal, so successes can be memoised in a caller-supplied
 * {@link VerifiedSealCache}; its key covers the complete seal encoding, witnesses included.
 */
export declare class UnicitySealQuorumSignaturesVerificationRule {
    private readonly signatureVerifier;
    private readonly cache?;
    static readonly MAX_NODE_ID_BYTES = 128;
    static readonly MAX_SIGNATURES = 16;
    /**
     * @param {ISignatureVerifier<Signature>} signatureVerifier Recovering secp256k1 verifier for the root-node signatures.
     * @param {VerifiedSealCache} [cache] Memo for verified seals; omit to verify every seal afresh.
     */
    constructor(signatureVerifier: ISignatureVerifier<Signature>, cache?: VerifiedSealCache | undefined);
    /**
     * The format checks of a seal's signature map (count and identifier length), independent of any authority.
     *
     * @param {UnicitySeal} seal Seal.
     * @returns {string|null} Why the seal is malformed, or null.
     */
    static checkSignatureFormat(seal: UnicitySeal): string | null;
    /**
     * Select the committee of the seal's epoch and check the seal's network and root round against it.
     *
     * @param {ITrustBaseAuthority} authority Held trust-base history.
     * @param {UnicitySeal} seal Seal.
     * @returns {IEpochCommittee|CertificateVerificationResult} The committee, or the failed check.
     */
    static selectCommittee(authority: ITrustBaseAuthority, seal: UnicitySeal): IEpochCommittee | CertificateVerificationResult;
    /**
     * The memo key commits to the committee record and its interval (a later held epoch closes an interval) and to the complete seal encoding,
     * signatures included (`calculateHash` excludes them, so it cannot be the key).
     *
     * @param {IEpochCommittee} committee Committee of the seal's epoch.
     * @param {UnicitySeal} unicitySeal Seal.
     * @returns {Promise<string>} Cache key.
     */
    private static cacheKeyFor;
    /**
     * Verify the seal against the committee of its epoch in the held history.
     *
     * @param {ITrustBaseAuthority} authority Held trust-base history.
     * @param {UnicitySeal} unicitySeal Seal to verify.
     * @returns {Promise<CertificateVerificationResult>} Verification outcome with its class.
     */
    verify(authority: ITrustBaseAuthority, unicitySeal: UnicitySeal): Promise<CertificateVerificationResult>;
    private verifySignature;
}
